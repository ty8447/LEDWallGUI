#pragma once
// Controller V8.1 shared configuration structs.
// These live in a header because the Arduino .ino preprocessor may generate
// prototypes before type definitions written in the .ino itself.
#include <stdint.h>

static const uint8_t MAX_ROOM_CORNERS = 16;

struct StoredPin {
  uint32_t magic;
  uint8_t digits[4];
  uint32_t checksum;
};

struct RoomCorner {
  uint16_t led;
  uint8_t inside;
  uint8_t reserved;
};

struct ClockWall {
  uint16_t start;
  uint16_t count;
  uint8_t reverse;
  uint8_t reserved;
};

struct StoredClockConfig {
  uint32_t magic;
  uint16_t version;
  uint8_t dst;
  uint8_t wallEnabled;
  ClockWall walls[4];
  uint32_t checksum;
};

struct StoredRoomConfig {
  uint32_t magic;
  uint16_t version;
  uint16_t ledCount;
  uint16_t density;
  uint16_t firstLed;
  uint8_t north;
  uint8_t cornerCount;
  RoomCorner corners[MAX_ROOM_CORNERS];
  uint32_t checksum;
};

// Independent V8.9 correction profile. Keep the existing room/clock flash records
// unchanged so a firmware update cannot invalidate an installed room layout.
static const uint8_t MAX_LED_CORRECTIONS = 12;
struct LedCorrectionRange {
  uint16_t start;            // inclusive physical LED indexes
  uint16_t end;
  uint8_t brightnessPercent; // 50..150, 100 neutral
  uint8_t lowLift;           // 0..16 extra PWM units on nonzero channels
  uint8_t redPercent;        // 50..150
  uint8_t greenPercent;
  uint8_t bluePercent;
  uint8_t reserved;
};
struct StoredLedCorrections {
  uint32_t magic;
  uint8_t version;
  uint8_t count;
  uint16_t reserved;
  LedCorrectionRange ranges[MAX_LED_CORRECTIONS];
  uint32_t checksum;
};
