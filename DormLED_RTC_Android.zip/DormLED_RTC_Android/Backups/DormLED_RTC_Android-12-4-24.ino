//DormLED Controller V5 by Cole Rabe
#include <Adafruit_NeoPixel.h>
#include <EasyColor.h>
#include <Adafruit_TinyUSB.h>
#include "RTClib.h"
#include <bluefruit.h>
#include <Adafruit_LittleFS.h>
#include <InternalFileSystem.h>

//HSV to RGB Setup
EasyColor::HSVRGB HSVConverter;
RTC_DS3231 rtc;
//End HSV to RGB Setup
#define PIN 5
#define SQWV 10
#define LEDCOUNT 1165
#define SERIAL_SIZE 32
#define MAX_BUFFER_SIZE 256

//LED Status + Modes Variables
int ledMode = 1;
int specialMode = 0;
bool cConnected = false;
uint16_t buffStripBright = 255;
uint16_t stripBright = 255;
uint16_t prevStripBright = 255;

struct LEDMode {
  String name;         // Name of the LED mode
  String description;  // Description of the mode (optional)
  int numParams;       // Number of parameters the mode accepts
  String params[5];    // Array to hold parameter names
  String paramValues[5]; // Array to hold parameter values
};

// Array of LED Modes
LEDMode ledModes[] = {
  { "Color", "Solid color mode", 1, { "Color" }, { "255,0,0" } }, // Red
  { "Rainbow", "Rainbow pattern", 1, { "Speed" }, { String(20) } },
  { "Alternating colors", "Alternating Colors", 3, { "Color", "SColor", "Speed" }, { "0,0,255", "0,255,0", String(20) } }, // Blue, Green
  { "Fade", "Color fade", 1, { "Speed" }, { String(20) } },
  { "Pulse", "Pulse colors", 3, { "Color", "SColor", "Speed" }, { "0,0,255", "0,255,0", String(20) } }, // Blue, Green
  { "Breathe", "Breathe solid color", 2, { "Color", "Speed" }, { "255,0,0", String(20) } }, // Red
  { "Paint", "Randomly paint lights a random color", 1, { "Speed" }, { String(20) } },
  { "Strobe", "Strobe single color", 2, { "Color", "Speed" }, { "255,0,0", String(30) } }, // Red
  { "Time", "Analog clock", 1, { "Color" }, { "255,0,0" } }, // Red
  { "Cylon", "Single bouncing bar", 3, { "Color", "SColor", "Speed" }, { "255,0,0", "0,0,255", String(20) } }, // Red, Blue
  { "Phaser", "Single disposable bar", 2, { "Color", "Speed" }, { "255,0,0", String(20) } }, // Red
  { "Alternating Phaser", "Multiple disposable bars destroy each other", 2, { "Color", "SColor" }, { "255,0,0", "0,0,255" } }, // Red, Blue
  { "Weather", "Live Weather reactive lights", 1, { "Color" }, { "255,0,0" } }, // Red
  { "Police Lights", "Police lights", 1, { "Speed" }, { String(20) } },
  { "Fire", "Fire effect", 1, { "Speed" }, { String(20) } },
  { "Bouncing Ball", "Multi ball newtons cradle", 1, { "Color" }, { "255,0,0" } }, // Red
  { "Twinkle", "Starry night sky", 2, { "Color", "Frequency" }, { "255,0,0", String(60) } }, // Red
  { "Sparkle", "Glitter like", 2, { "Color", "Frequency" }, { "255,0,0", String(60) } }, // Red
  { "Running Lights", "Resizable running lights", 3, { "Color", "Speed", "Division" }, { "255,0,0", String(10), String(20) } }, // Red
  { "Theatre Chase", "Single pixel running lights", 2, { "Color", "Speed" }, { "255,0,0", String(10) } }, // Red
  { "Meteor", "Not used", 1, { "Color" }, { "255,0,0" } }, // Red
  { "Pop", "Firework like", 2, { "Color", "Speed" }, { "255,0,0", String(10) } }, // Red
};



int numModes = sizeof(ledModes) / sizeof(ledModes[0]);  // Get the number of LED modes

bool ledState = true;
bool timeoutlight = false;
bool hasSet = false;
int ddColor1 = 0;
int ddColor2 = 0;
int ch = 69;
int cs = 70;
int cv = 71;
float cr = 255;
float cg = 255;
float cb = 255;
int fh = 0;
float fr = 255;
float fg = 255;
float fb = 255;
String val;
//End LED Status + Modes Variables

//Parsing Serial Data Variables
const byte serialsize = 32;
char input[SERIAL_SIZE];
char tempInput[SERIAL_SIZE];
char intxt_1[SERIAL_SIZE] = { 0 };
int inNum_0 = 0;
float inNum_1 = 0.0;
float inNum_2 = 0.0;
float inNum_3 = 0.0;
bool newData = false;
int second = 0;
int minute = 18;
int hour = 3;
int dayOfWeek = 2;
int dayOfMonth = 1;
int month = 5;
int year = 23;
String currentModeName = "";
String previousModeName = "";
//End Parsing Serial Data Variables

//Global Animation Variables
int minuteMap[60] = { 707, 724, 741, 757, 774, 791, 807, 823, 840, 856, 872, 888, 905, 921, 938, 954, 972, 990, 1008, 1026, 1044, 1063, 1081, 8, 26, 45, 63, 81, 98, 116, 134, 156, 178, 199, 221, 243, 265, 286, 308, 329, 351, 373, 394, 416, 437, 459, 476, 492, 509, 525, 542, 558, 575, 591, 608, 624, 641, 657, 674, 690 };
int hourMap[12] = { 707, 791, 872, 954, 1044, 45, 134, 243, 351, 459, 542, 624 };
int beamSize = LEDCOUNT / 20;
bool ledON = false;
int ledNum = 0;
int beamPos[LEDCOUNT];
unsigned long cMillis = 0;
unsigned long pMillis = 0;
unsigned long rMillis = 0;
unsigned long sMillis = 0;
unsigned long tMillis = 0;
int DST = 0;  //If between March and November (DST) set to 1, else set to 0
int pSecond = 0;
bool aOn = false;
bool goingUp = true;
uint16_t brightness = 254;
uint16_t prevBrightness = 1;
int handBright = 0;
int mHandBright = 0;
int backBright = 0;
int aStep = 0;
bool strobeOn = false;
bool altState = false;
int ledDiv = 15;
bool color = false;
int modeSpeed = 60;
float rStates[LEDCOUNT];
float bStates[LEDCOUNT];
float gStates[LEDCOUNT];
float pulseBar1[8];  // Direction, Size, r, g, b
float pulseBar2[8];
float pulseBar3[8];
float pulseBar4[8];
float pulseBar5[8];
float popHang[LEDCOUNT];
float setPopHang[LEDCOUNT];
uint16_t nextrgb[] = { 255, 0, 0 };
float color1[] = { 255, 255, 255 };
float color2[] = { 0, 255, 0 };
int pixChosen = 0;
int pColorOption = 0;
int ledStatus[LEDCOUNT];
bool barDirection = false;
const int barSize = 30;
int setBarSize = 0;
int phaserNum = 0;
bool inRamp = false;
int rampStep = 0;
int aMBright = 255;
volatile long count = 0;
long pMinute = 0;
int sBarPos = hourMap[0];

#define CUSTOM_SERVICE_UUID "12345678-1234-5678-1234-56789abcdef0"

// Define the characteristic UUIDs
#define LED_BRIGHTNESS_CHARACTERISTIC_UUID "12345678-1234-5678-1234-56789abcdef1"
#define LED_MODE_LIST_UUID "12345678-1234-5678-1234-56789abcdef2"
#define PARAMETER_NOTIFY_UUID "12345678-1234-5678-1234-56789abcdef3"
#define PARAMETER_REQUEST_UUID "12345678-1234-5678-1234-56789abcdef4"
#define MODE_CONTROL_UUID "12345678-1234-5678-1234-56789abcdef5"



// Parameter 1 = number of pixels in strip
// Parameter 2 = Arduino pin number (most are valid)
// Parameter 3 = pixel type flags, add together as needed:
//   NEO_KHZ800  800 KHz bitstream (most NeoPixel products w/WS2812 LEDs)
//   NEO_KHZ400  400 KHz (classic 'v1' (not v2) FLORA pixels, WS2811 drivers)
//   NEO_GRB     Pixels are wired for GRB bitstream (most NeoPixel products)
//   NEO_RGB     Pixels are wired for RGB bitstream (v1 FLORA pixels, not v2)
//   NEO_RGBW    Pixels are wired for RGBW bitstream (NeoPixel RGBW products)
Adafruit_NeoPixel strip = Adafruit_NeoPixel(LEDCOUNT, PIN, NEO_GRB + NEO_KHZ800);

// IMPORTANT: To reduce NeoPixel burnout risk, add 1000 uF capacitor across
// pixel power leads, add 300 - 500 Ohm resistor on first pixel's data input
// and minimize distance between Arduino and first pixel.  Avoid connecting
// on a live circuit...if you must, connect GND first.

BLEDfu bledfu;    // OTA DFU service
BLEDis bledis;    // device information
BLEUart bleuart;  // uart over BLE
BLEBas blebas;    // battery

BLEService customService(CUSTOM_SERVICE_UUID);
BLECharacteristic ledBrightnessCharacteristic(LED_BRIGHTNESS_CHARACTERISTIC_UUID, BLEWrite, 32);
BLECharacteristic ledModesCharacteristic(LED_MODE_LIST_UUID, BLERead, 512);
BLECharacteristic parameterRequestNotify(PARAMETER_NOTIFY_UUID, BLEWrite | BLERead | BLENotify, 20);
BLECharacteristic parameterRequestCharacteristic(PARAMETER_REQUEST_UUID, BLEWrite | BLERead | BLENotify, 128);
BLECharacteristic modeControlCharacteristic(MODE_CONTROL_UUID, BLEWrite, 256);

uint16_t connHandle;

void setup() {
  Serial.begin(115200);
  strip.begin();
  rtc.begin();
  if (!rtc.begin()) {
    Serial.println("Couldn't find RTC");
    Serial.flush();
    while (1) delay(10);
  }

  strip.setBrightness(255);
  strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
  strip.show();
  if (rtc.lostPower()) {
    Serial.println("RTC lost power, let's set the time!");
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }
  ledState = false;
  ledMode = 0;
  DateTime now = rtc.now();
  //rtc.adjust(DateTime(now.year(), now.month(), now.day(), 10, 54, 0));
  tMillis = now.second() * 1000;

  // Initialize BLE
  Bluefruit.begin();
  Bluefruit.setTxPower(4);
  Bluefruit.Periph.setConnectCallback(connect_callback);
  Bluefruit.Periph.setDisconnectCallback(disconnect_callback);

  customService.begin();

  ledBrightnessCharacteristic.begin();  // Add characteristic to service
  ledBrightnessCharacteristic.setUserDescriptor("LED Brightness Control");
  ledBrightnessCharacteristic.setWriteCallback(ledBrightnessCharacteristicWritten);

  ledModesCharacteristic.begin();
  ledModesCharacteristic.setProperties(CHR_PROPS_READ | CHR_PROPS_NOTIFY);

  parameterRequestCharacteristic.begin();
  parameterRequestCharacteristic.setCccdWriteCallback(cccd_callback);
  parameterRequestCharacteristic.setUserDescriptor("Parameter Request");
  parameterRequestCharacteristic.setWriteCallback(parameterRequestCharacteristicWritten);


  parameterRequestNotify.begin();
  parameterRequestNotify.setUserDescriptor("Parameter Notify");

  modeControlCharacteristic.begin();
  modeControlCharacteristic.setWriteCallback(modeControlCharacteristicWritten);

  Serial.println("Starting Mode Push");

  Serial.println("Advertising BLE service");

  bledfu.begin();
  bledis.setManufacturer("Cole Rabe");
  bledis.setModel("DormLED Controller");
  bledis.begin();

  bleuart.begin();
  blebas.begin();
  blebas.write(100);

  Bluefruit.setName("Room LED Controller");  // Change Bluetooth device name here

  // Start advertising
  startAdv();

  pinMode(SQWV, INPUT);
  rtc.writeSqwPinMode(DS3231_SquareWave1kHz);
  cResync();
  attachInterrupt(digitalPinToInterrupt(SQWV), RTCMillis, CHANGE);
  // ledModes();
  timeout();
}

void loop() {
  cMillis = millis();
  cResync();
  executeCurrentMode();
  static uint8_t value[20] = { 0 };
  static uint8_t counter = 0;

  // Serial.println("Current Mode: " + currentModeName);
  // delay(1000); // Print every 1 second (adjust as needed)

  inpReceiving();
  if (newData == true) {
    strcpy(tempInput, input);
    parseData();
    inputHandling();
    // ledModes();
    clearInputs();
    newData = false;
  } else {
  }

  rampBright();
  if (stripBright != buffStripBright && inRamp == false) {
    stripBright = buffStripBright;
    prevStripBright = buffStripBright;
    hasSet = false;
  }
}

void modeControlCharacteristicWritten(uint16_t conn_hdl, BLECharacteristic* chr, uint8_t* data, uint16_t len) {
  Serial.println("Function Called!");
  if (len <= 0) {
    Serial.println("Error: Received data length is zero.");
    return;
  }

  // Safely null-terminate the data
  char cleanedData[MAX_BUFFER_SIZE] = { 0 };
  strncpy(cleanedData, (char*)data, len > MAX_BUFFER_SIZE ? MAX_BUFFER_SIZE - 1 : len);

  // Parse and clean command
  String command = String(cleanedData);
  command.trim();
  command.replace('$', '\0');
  command.replace('.', '\0');

  Serial.print("Cleaned Command1: ");
  Serial.println(command);

  // Process command
  currentModeName = command;
}


// Function to get the parameter value based on parameter name
String getParameterValue(String parameterName) {
  // Replace with your logic to get the actual parameter value
  if (parameterName == "Color") {
    return String(cr) + "," + String(cg) + "," + String(cb);  // Example: Return color as RGB values
    // return String("Tester!"); // Example: Return color as RGB values
  } else if (parameterName == "Speed") {
    return String(modeSpeed);  // Example: Return mode speed
  } else if (parameterName == "Intensity") {
    return String(stripBright);
  }
  // Default value if parameter not found
  else {
    return "0";
  }
}

void cccd_callback(uint16_t conn_handle, BLECharacteristic* chr, uint16_t cccd_value) {
  // Display the raw request packet
  Serial.print("CCCD Updated: ");
  Serial.println(cccd_value);
}

void executeCurrentMode() {
  // Iterate through the ledModes array to find the current mode
  for (int i = 0; i < numModes; i++) {
    if (ledModes[i].name == currentModeName) {
      // Extract parameters for the mode
      unsigned int r = 0, g = 0, b = 0; // For RGB values
      unsigned int sr = 0, sg = 0, sb = 0; // For secondary color
      unsigned long speedParam = 0;
      unsigned long frequencyParam = 0;
      unsigned long divisionParam = 0;

      for (int j = 0; j < ledModes[i].numParams; j++) {
        if (ledModes[i].params[j] == "Color") {
          parseRGB(ledModes[i].paramValues[j], r, g, b); // Parse primary color
        } else if (ledModes[i].params[j] == "SColor") {
          parseRGB(ledModes[i].paramValues[j], sr, sg, sb); // Parse secondary color
        } else if (ledModes[i].params[j] == "Speed") {
          speedParam = ledModes[i].paramValues[j].toInt(); // Convert to integer
        } else if (ledModes[i].params[j] == "Frequency") {
          frequencyParam = ledModes[i].paramValues[j].toInt();
        } else if (ledModes[i].params[j] == "Division") {
          divisionParam = ledModes[i].paramValues[j].toInt();
        }
      }

      // Call the corresponding function
      if (currentModeName == "Color") {
        Serial.println("Color");
        colorMode(r, g, b);
      } else if (currentModeName == "Rainbow") {
        Serial.println("Rainbow");
        rainbowCycle(speedParam);
      } else if (currentModeName == "Alternating colors") {
        alternatingColors(r, g, b, sr, sg, sb, speedParam);
      } else if (currentModeName == "Fade") {
        fade(speedParam);
      } else if (currentModeName == "Pulse") {
        pulse(r, g, b, sr, sg, sb, speedParam);
      } else if (currentModeName == "Breathe") {
        breathe(r, g, b, speedParam);
      } else if (currentModeName == "Paint") {
        paint(speedParam);
      } else if (currentModeName == "Strobe") {
        strobe(r, g, b, speedParam);
      } else if (currentModeName == "Time") {
        tClock(true);
      } else if (currentModeName == "Cylon") {
        cylon(r, g, b, sr, sg, sb, speedParam);
      } else if (currentModeName == "Phaser") {
        phaser(r, g, b, speedParam);
      } else if (currentModeName == "Alternating Phaser") {
        aPhaser(r, g, b, sr, sg, sb);
      } else if (currentModeName == "Weather") {
        // weather();
      } else if (currentModeName == "Police Lights") {
        pLights(speedParam);
      } else if (currentModeName == "Fire") {
        fire(speedParam);
      } else if (currentModeName == "Bouncing Ball") {
        // bouncingBall(r, g, b);
      } else if (currentModeName == "Twinkle") {
        twinkle(r, g, b, frequencyParam);
      } else if (currentModeName == "Sparkle") {
        sparkle(r, g, b, frequencyParam);
      } else if (currentModeName == "Running Lights") {
        rLights(r, g, b, speedParam, divisionParam);
      } else if (currentModeName == "Theatre Chase") {
        tChase(r, g, b, speedParam);
      } else if (currentModeName == "Meteor") {
        // meteorMode(colorParam);
      } else if (currentModeName == "Pop") {
        pop(r, g, b, speedParam);
      } else {
        Serial.print("Unknown mode: ");
        Serial.println(currentModeName);
      }
      return; // Exit after matching the mode
    }
  }
  Serial.println("Mode not found in ledModes[]!");
}

void ledModesCharacteristicWritten(BLECharacteristic& chr, uint8_t* data, uint16_t len) {
  // Convert the received data to a String
  Serial.print("Raw Data: ");
  for (int i = 0; i < len; i++) {
    Serial.print(data[i], HEX);
    Serial.print(" ");
  }
  Serial.println();

  String cleanedData = String((char*)data);  // Removes extra whitespace
  cleanedData.trim();
  Serial.print("Cleaned Data: ");
  Serial.println(cleanedData);

  // Check if it's a parameter value request
  // if (cleanedData.startsWith("request:")) {
  //   // Extract the mode name from the request
  //   String modeName = cleanedData.substring(8);  // Remove "request:" prefix

  //   // Handle the parameter request
  //   handleParameterRequest(modeName);
  // }

  // Reset the buffer explicitly
  memset(data, 0, len + 1);  // Clear the buffer
}

void parameterRequestCharacteristicWritten(uint16_t conn_hdl, BLECharacteristic* chr, uint8_t* data, uint16_t len) {
  Serial.print("Raw Data: ");
  for (int i = 0; i < len; i++) {
    Serial.print(data[i], HEX);
    Serial.print(" ");
  }
  Serial.println();

  char dataString[len + 1]; // +1 for null terminator
  memcpy(dataString, data, len);
  dataString[len] = '\0'; // Explicitly add null terminator
  String receivedData = String(dataString);
  receivedData.trim();
  Serial.print("Cleaned Command2: ");
  Serial.println(receivedData);

  if (receivedData.indexOf(':') == -1) { // No colon means it's a mode name
    String modeName = receivedData;

    // Send parameter values for the requested mode using notifications
    sendParameterValuesForMode(modeName); 
  } else {
    // Handle parameter updates as before
    int firstColonIndex = receivedData.indexOf(':');
    int secondColonIndex = receivedData.indexOf(':', firstColonIndex + 1);

    if (firstColonIndex != -1 && secondColonIndex != -1) {
      String modeName = receivedData.substring(0, firstColonIndex);
      String parameterName = receivedData.substring(firstColonIndex + 1, secondColonIndex);
      String parameterValue = receivedData.substring(secondColonIndex + 1);

      // Update parameter value in ledModes array
      for (int i = 0; i < numModes; i++) {
        if (ledModes[i].name == modeName) {
          for (int j = 0; j < ledModes[i].numParams; j++) {
            if (ledModes[i].params[j] == parameterName) {
              ledModes[i].paramValues[j] = parameterValue; // Store RGB string directly
              Serial.print("Updated parameter ");
              Serial.print(parameterName);
              Serial.print(" for mode ");
              Serial.print(modeName);
              Serial.print(" to: ");
              Serial.println(parameterValue);
              break; // Exit inner loop after updating parameter
            }
          }
          break; // Exit outer loop after finding mode
        }
      }
    } else {
      Serial.println("Invalid parameter update format.");
    }
  }

  // Reset the buffer explicitly
  memset(data, 0, len + 1);  // Clear the buffer
}

void parseRGB(const String &rgbString, unsigned int &r, unsigned int &g, unsigned int &b) {
  sscanf(rgbString.c_str(), "%u,%u,%u", &r, &g, &b); // Use %u for unsigned int
}


void sendParameterValuesForMode(String modeName) {
  String parameterValuesString = "";

  // Find the mode in the ledModes array
  for (int i = 0; i < numModes; i++) {
    if (ledModes[i].name == modeName) {
      // Found the mode, now format the parameter values
      for (int j = 0; j < ledModes[i].numParams; j++) {
        parameterValuesString += ledModes[i].params[j] + "=" + ledModes[i].paramValues[j];
        if (j < ledModes[i].numParams - 1) {
          parameterValuesString += ",";
        }
      }
      break; // Exit the loop after finding the mode
    }
  }

  // Send the parameter values as a notification
  if (parameterValuesString.length() > 0) {
    parameterRequestCharacteristic.notify((uint8_t*)parameterValuesString.c_str(), parameterValuesString.length());
    Serial.print("Parameter values for mode ");
    Serial.print(modeName);
    Serial.print(" sent: ");
    Serial.println(parameterValuesString);
  } else {
    Serial.print("Mode ");
    Serial.print(modeName);
    Serial.println(" not found or has no parameters.");
  }
}

void parameterRequestNotifyWritten(uint16_t conn_hdl, BLECharacteristic* chr, uint8_t* data, uint16_t len) {
  Serial.println("CalledNotifyWritten");
}

// BLE Write callback to receive LED power state commands
void ledBrightnessCharacteristicWritten(uint16_t conn_hdl, BLECharacteristic* chr, uint8_t* data, uint16_t len) {
  Serial.println("Function Called!");

  if (len > 0) {
    // Convert received data to String and trim extra spaces
    String command = String((char*)data);
    command.trim();  // Remove any extra whitespace

    // Debugging: Print the received command
    Serial.print("Received Command: ");
    Serial.println(command);

    // Process the command
    if (command.equalsIgnoreCase("ON")) {
      Serial.println("Command: ON");
      ledState = true;
      // Set LEDs to red
      strip.fill(strip.Color(255, 0, 0), 0, LEDCOUNT);
      strip.show();

    } else if (command.equalsIgnoreCase("OFF")) {
      Serial.println("Command: OFF");
      ledState = false;

      // Turn off LEDs
      strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
      strip.show();
    } else {
      Serial.println("Unknown Command: " + command);
    }

    // Clear the buffer after processing the data
    memset(data, 0, min(len + 1, MAX_BUFFER_SIZE));  // Clear the buffer to avoid stale data
  }
}

void sendLEDModeList() {
  String modeList = "";  // Start with an empty string to hold the modes

  // Loop through each mode and append its details
  for (int i = 0; i < numModes; i++) {
    modeList += ledModes[i].name + ":";         // Mode name
    modeList += ledModes[i].description + ":";  // Mode description

    // Append each parameter for the current mode
    for (int j = 0; j < ledModes[i].numParams; j++) {
      modeList += ledModes[i].params[j]; // Only include parameter name
      if (j < ledModes[i].numParams - 1) {
        modeList += ",";
      }
    }

    modeList += ";";  // Separate modes with semicolon
  }

  // Send the mode list via the BLE characteristic
  ledModesCharacteristic.write((const uint8_t*)modeList.c_str(), modeList.length());
  ledModesCharacteristic.notify(modeList.c_str());

  Serial.println("LED Modes sent to tablet:");
  Serial.println(modeList);  // Print to Serial for debugging
}

void startAdv(void) {
  Bluefruit.Advertising.addFlags(BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE);
  Bluefruit.Advertising.addTxPower();

  // Add the custom service UUID to the advertisement
  Bluefruit.Advertising.addService(customService);

  // Add UART service UUID if needed
  Bluefruit.Advertising.addService(bleuart);

  // Add the device name to the scan response
  Bluefruit.ScanResponse.addName();

  // Start advertising
  Bluefruit.Advertising.restartOnDisconnect(true);
  Bluefruit.Advertising.setInterval(32, 244);  // Advertising interval range in ms
  Bluefruit.Advertising.setFastTimeout(30);    // Fast mode timeout in seconds
  Bluefruit.Advertising.start(0);              // 0 = Don't stop advertising after a set time
}

// void setPowerState(bool state) {
//   powerState = state;

//   if (powerState) {
//     digitalWrite(LED_BUILTIN, HIGH); // Turn on LED to indicate power is ON (replace with actual device control)
//     Serial.println("Power is ON");
//   } else {
//     digitalWrite(LED_BUILTIN, LOW); // Turn off LED to indicate power is OFF
//     Serial.println("Power is OFF");
//   }
// }

void connect_callback(uint16_t conn_handle) {
  Serial.println("Connected-ish");
  BLEConnection* connection = Bluefruit.Connection(conn_handle);
  char central_name[32] = { 0 };
  connection->getPeerName(central_name, sizeof(central_name));
  Serial.print("Connected to ");
  Serial.println(central_name);
  sendLEDModeList();

  // Check if the device is valid and the name is available
  if (connection && connection->connected()) {
    // Access device name safely
    // Provide arguments to getPeerName()
    connection->getPeerName(central_name, sizeof(central_name));
    const char* deviceName = central_name;
    Serial.print("Device name: ");
    Serial.println(deviceName);
    if (cConnected == false) {
      Serial.println("yesconnect");
      Serial.println('\n');
      inRamp = false;
      cConnected = true;
      ledState = true;
      //   strip.setBrightness(stripBright);
      if (timeoutlight == true) {
        timeoutlight = false;
        Serial.println("Timeout Light True");
        ledMode = 0;
        aOn = false;
        strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
        strip.show();
      }
    }
    // ledModes();
  } else {
    Serial.println("Device information not available yet.");
  }
}

void disconnect_callback(uint16_t conn_handle, uint8_t reason) {
  (void)conn_handle;
  (void)reason;
  Serial.println();
  Serial.print("Disconnected, reason = 0x");
  Serial.println(reason, HEX);
  cConnected = false;
}

void RTCMillis() {
  count++;
  if (count >= 113) {
    count = 0;
    sBarPos++;
  }
}

void cResync() {
  DateTime now = rtc.now();
  minute = now.minute();
  if (minute != pMinute) {
    pMinute = minute;
    sBarPos = hourMap[0];
  }
  hour = now.hour() + DST;
  if (hour < 0 || hour > 23) {
    hour = 0;
  }
  second = now.second();
}

void inpReceiving() {
  static bool recInProgress = false;
  static byte ndx = 0;
  char startMarker = '<';
  char endMarker = '>';
  char rc;

  while (Serial.available() > 0 && newData == false) {
    rc = Serial.read();

    if (recInProgress == true) {
      if (rc != endMarker) {
        input[ndx] = rc;
        ndx++;
        if (ndx >= SERIAL_SIZE) {
          ndx = SERIAL_SIZE - 1;
        }
      } else {
        input[ndx] = '\n';
        recInProgress = false;
        ndx = 0;
        newData = true;
      }
    }

    else if (rc == startMarker) {
      recInProgress = true;
    }
  }
}

void parseData() {
  Serial.print("Parsing data: ");
  Serial.println(tempInput);
  char* strtokIndx;

  strtokIndx = strtok(tempInput, ",");
  strcpy(intxt_1, strtokIndx);

  strtokIndx = strtok(NULL, ",");
  inNum_0 = atoi(strtokIndx);

  strtokIndx = strtok(NULL, ",");
  inNum_1 = atof(strtokIndx);

  strtokIndx = strtok(NULL, ",");
  inNum_2 = atof(strtokIndx);

  strtokIndx = strtok(NULL, ",");
  inNum_3 = atof(strtokIndx);
}


void showData() {
  Serial.print("Text Input 1 (1): ");
  Serial.println(intxt_1);
  Serial.print("Number Input 1 (2): ");
  Serial.println(inNum_0);
  Serial.print("Number Input 2 (3): ");
  Serial.println(inNum_1);
  Serial.print("Number Input 3 (4): ");
  Serial.println(inNum_2);
  Serial.print("Number Input 4 (5): ");
  Serial.println(inNum_3);
  Serial.println('\n');
}
String cleanInput(String input) {
  input.trim();             // Remove leading/trailing whitespace
  input.replace("\0", "");  // Remove null characters
  return input;
}


void timeout() {
  if (cConnected == false && timeoutlight == false) {
    //while (millis() - 50 >= 1000) {
    Serial.println("Timeout Triggered");
    ledMode = 11;
    color1[0] = 255;
    color1[1] = 0;
    color1[2] = 0;
    for (uint16_t i = 0; i < LEDCOUNT; i++) {
      if (ledNum < beamSize) {
        if (ledON == false) {
          beamPos[i] = 0;
        } else {
          beamPos[i] = 1;
        }
        ledNum++;
      } else if (ledNum >= beamSize) {
        ledON = !ledON;
        ledNum = 0;
      }
    }
    ledState = true;
    aOn = true;
    timeoutlight = true;
    Serial.println("Timeout");
    Serial.println('\n');
    //break;
    // }
  }
  if (cConnected == false && timeoutlight == true) {
    Serial.println("Timeout Triggered Again");
    timeoutMode(5);
  }
}

void inputHandling() {
  if (strcmp(intxt_1, "b") == 0) {
    buffStripBright = inNum_0;
  }
  if (strcmp(intxt_1, "c") == 0) {
    if (inNum_0 == 0 || inNum_0 == 1) {
      ch = inNum_1;
      cs = inNum_2;
      cv = inNum_3;
      rgb out_rgb;
      out_rgb.r = 0;
      out_rgb.g = 0;
      out_rgb.b = 0;
      hsv in_hsv;
      in_hsv.h = ch;
      in_hsv.s = cs;
      in_hsv.v = cv;
      out_rgb = HSVConverter.HSVtoRGB(in_hsv, out_rgb);
      cr = out_rgb.r;
      cg = out_rgb.g;
      cb = out_rgb.b;
      if (inNum_0 == 0) {
        color1[0] = cr;
        color1[1] = cg;
        color1[2] = cb;
      } else if (inNum_0 == 1) {
        color2[0] = cr;
        color2[1] = cg;
        color2[2] = cb;
      }
    }
    if (inNum_0 == 2) {
      ddColor1 = inNum_1;
    } else if (inNum_0 == 3) {
      ddColor2 = inNum_1;
    }
    hasSet = false;
  }
  if (strcmp(intxt_1, "m") == 0) {
    aOn = false;
    ledMode = inNum_0;
    specialMode = inNum_1;
    hasSet = false;
  }
  if (strcmp(intxt_1, "p") == 0) {
    if (inNum_0 == 0) {
      for (int i = 0; i < strip.numPixels(); i++) {
        strip.setPixelColor(i, 0);
      }
      strip.show();
      ledState = false;
      Serial.println("off");
    } else if (inNum_0 == 1) {
      strip.show();
      ledState = true;
      hasSet = false;
      Serial.println("on");
    }
  }
  if (strcmp(intxt_1, "o") == 0) {
    if (inNum_0 == 0) {  //Speed
      modeSpeed = inNum_1;
      pMillis = cMillis;
    }
    if (inNum_0 == 1) {  //Division
      ledDiv = inNum_1;
    }
    if (inNum_0 == 2) {  //Ramp Brightness
      if (inRamp == false) {
        rampStep = 0;
        inRamp = true;
      }
      if (inRamp == true) {
        rampStep = 0;
      }
    }
    if (inNum_0 == 3) {  //Stop Ramp Brightness
      rampStep = 0;
      inRamp = false;
    }
    if (inNum_0 == 4) {  //Set Max Brightness
      aMBright = inNum_1;
    }
  }
  if (strcmp(intxt_1, "s") == 0) {
    if (inNum_0 == 0) {
      Serial.print("Connection State: ");
      Serial.println(cConnected);
      Serial.print("Hour: ");
      Serial.println(hour);
      Serial.print("Minute: ");
      Serial.println(minute);
      Serial.print("Power: ");
      Serial.println(ledState);
      Serial.print("StripBright: ");
      Serial.println(stripBright);
      Serial.print("Brightness: ");
      Serial.println(brightness);
      Serial.print("PrevBrightness: ");
      Serial.println(prevBrightness);
      Serial.print("goingup: ");
      Serial.println(goingUp);
      Serial.print("Current Mode: ");
      Serial.println(ledMode);
      Serial.print("Special Mode: ");
      Serial.println(specialMode);
      Serial.print("altState:");
      Serial.println(modeSpeed);
      Serial.print("aOn: ");
      Serial.println(aOn);
      Serial.print("aStep: ");
      Serial.println(aStep);
      Serial.print("phaserNum: ");
      Serial.println(phaserNum);
      Serial.print("barDirection: ");
      Serial.println(barDirection);
      Serial.print("setBarSize: ");
      Serial.println(setBarSize);
      Serial.print("BuffBrightness: ");
      Serial.println(buffStripBright);
      Serial.print("aMBright: ");
      Serial.println(aMBright);
      Serial.print("inRamp: ");
      Serial.println(inRamp);
      Serial.print("RampStep: ");
      Serial.println(rampStep);
      Serial.println('\n');
    }
    if (inNum_0 == 1) {
      Serial.println("Got Message");
      Serial.println('\n');
      if (cConnected == true) {
        Serial.println("nomore");
        Serial.println('\n');
        inRamp = false;
      }
      if (cConnected == false) {
        Serial.println("yesconnect");
        Serial.println('\n');
        inRamp = false;
        cConnected = true;
        ledState = true;
        //   strip.setBrightness(stripBright);
        if (timeoutlight == true) {
          timeoutlight = false;
          ledMode = 0;
          aOn = false;
          strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
          strip.show();
        }
      }
    }
    if (inNum_0 == 2) {
      if (inNum_1 == 0) {
        Serial.println(ch);
        Serial.println('\n');
      }

      if (inNum_1 == 1) {
        Serial.println(cs);
        Serial.println('\n');
      }

      if (inNum_1 == 2) {
        Serial.println(cv);
        Serial.println('\n');
      }
    }
    if (inNum_0 == 3) {
      if (inNum_1 == 0) {
        Serial.flush();
        Serial.println(ledState);
        Serial.println('\n');
        Serial.flush();
      }

      if (inNum_1 == 1) {
        Serial.flush();
        Serial.println(stripBright);
        Serial.println('\n');
        Serial.flush();
      }
      if (inNum_1 == 2) {
        Serial.flush();
        Serial.println(ledMode);
        Serial.println('\n');
        Serial.flush();
      }
      if (inNum_1 == 3) {
        Serial.flush();
        Serial.println(ledDiv);
        Serial.println('\n');
        Serial.flush();
      }
      if (inNum_1 == 4) {
        Serial.flush();
        Serial.println(specialMode);
        Serial.println('\n');
        Serial.flush();
      }
      if (inNum_1 == 5) {
        Serial.flush();
        Serial.println(modeSpeed);
        Serial.println('\n');
        Serial.flush();
      }
      if (inNum_1 == 6) {
        Serial.flush();
        Serial.println(ddColor1);
        Serial.println('\n');
        Serial.flush();
      }
      if (inNum_1 == 7) {
        Serial.flush();
        Serial.println(ddColor2);
        Serial.println('\n');
        Serial.flush();
      }
    }
  }
}

void rampBright() {
  if (inRamp == true && rampStep < aMBright) {
    if ((cMillis - rMillis) >= 100) {
      stripBright = rampStep;
      rampStep++;
      rMillis = cMillis;
    }
  }
}


//Clear Inputs
void clearInputs() {
  intxt_1[SERIAL_SIZE] = { 0 };
  inNum_0 = 0;
  inNum_1 = 0.0;
  inNum_2 = 0.0;
  inNum_3 = 0.0;
}

//~~LED MODE HANDLING~~
// void ledModes() {
//   if (ledMode == 1) {  //Rainbow
//     if (aOn == false) {
//       aOn = true;
//       pMillis = -1000;
//     }
//     rainbowCycle(modeSpeed);  //Default 20
//   }
//   if (ledMode == 2 && hasSet == false && ledState == true) {  //Color
//     strip.fill(strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)), 0, LEDCOUNT);
//     strip.show();
//     hasSet = true;
//   }
//   if (ledMode == 3) {  //Fade
//     if (aOn == false) {
//       aOn = true;
//       pMillis = -1000;
//     }
//     fade(modeSpeed);  //Default 100
//   }
//   if (ledMode == 4) {  //Alternating Colors
//     if (aOn == false) {
//       aOn = true;
//       altState = false;
//       color = false;
//       strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//       pMillis = -1000;
//     }
//     alternatingColors(modeSpeed);  //Default 300
//   }
//   if (ledMode == 5) {  //Pulse
//     if (aOn == false) {
//       aOn = true;
//       pMillis = -1000;
//       pixChosen = 0;
//       for (int i = 0; i < LEDCOUNT; i++) {
//         ledStatus[i] = 0;
//       }
//     }
//     pulse(modeSpeed);  //Default 50
//   }
//   if (ledMode == 6) {  //Breathe
//     if (aOn == false) {
//       aOn = true;
//       brightness = stripBright;
//       pMillis = -1000;
//     }
//     breathe(modeSpeed);  //Default 30
//   }
//   if (ledMode == 7) {  //Strobe
//     if (aOn == false) {
//       aOn = true;
//       pMillis = -1000;
//     }
//     strobe(modeSpeed);  //Default 40
//   }
//   if (ledMode == 8) {  //Paint
//     if (aOn == false) {
//       aOn = true;
//       pMillis = -1000;
//       for (uint16_t i = 0; i < LEDCOUNT; i++) {
//         rStates[i] = 0;
//         gStates[i] = 0;
//         bStates[i] = 0;
//       }
//       strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//       strip.show();
//     }
//     paint(modeSpeed);  //Default 120
//   }
//   if (ledMode == 9) {  //Clock
//     if (aOn == false) {
//       aOn = true;
//       pMillis = -1000;
//     }
//     tClock(true);
//   }
//   if (ledMode == 10) {  //Special
//     if (specialMode == 0) {
//       strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//       strip.show();
//     }
//     if (specialMode == 2) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//         aStep = 0;
//         /*for (int i=0;i<=LEDCOUNT;i++){
//             ledStatus[i]=0;
//             }*/
//         memset(ledStatus, 0, sizeof(ledStatus));
//         barDirection = false;
//         setBarSize = 0;
//         Serial.println(2);
//       }
//       cylon(modeSpeed);  //Default 60
//     }
//     if (specialMode == 3) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//         aStep = 0;
//         /*for (int i=0;i<=LEDCOUNT;i++){
//             ledStatus[i]=0;
//             }*/
//         memset(ledStatus, 0, sizeof(ledStatus));
//         barDirection = false;
//         setBarSize = 0;
//         Serial.println(3);
//       }
//       phaser(modeSpeed);  //Default 60
//     }
//     if (specialMode == 4) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//         aStep = 0;
//         phaserNum = 0;
//         /*for (int i=0;i<=LEDCOUNT;i++){
//             ledStatus[i]=0;
//             }*/
//         memset(ledStatus, 0, sizeof(ledStatus));
//         barDirection = false;
//         setBarSize = 0;
//         Serial.println(4);
//       }
//       aPhaser(modeSpeed);  //Default 60
//     }
//     if (specialMode == 5) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//         aStep = 0;
//         /*for (int i=0;i<=LEDCOUNT;i++){
//             ledStatus[i]=0;
//             }*/
//         memset(ledStatus, 0, sizeof(ledStatus));
//         barDirection = false;
//         setBarSize = 0;
//         Serial.println(5);
//       }
//       //weather(modeSpeed);//Default 60
//     }
//     if (specialMode == 6) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//         aStep = 0;
//         altState = false;
//         Serial.println(6);
//       }
//       pLights(modeSpeed);  //Default 60
//     }
//     if (specialMode == 7) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//         aStep = 0;
//         /*for (int i=0;i<=LEDCOUNT;i++){
//             ledStatus[i]=0;
//             }*/
//         memset(ledStatus, 0, sizeof(ledStatus));
//         barDirection = false;
//         setBarSize = 0;
//         Serial.println(7);
//       }
//       fire(modeSpeed);  //Default 60
//     }
//     if (specialMode == 8) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//         aStep = 0;
//         /*for (int i=0;i<=LEDCOUNT;i++){
//             ledStatus[i]=0;
//             }*/
//         memset(ledStatus, 0, sizeof(ledStatus));
//         barDirection = false;
//         setBarSize = 0;
//         Serial.println(8);
//       }
//       // Bouncing Ball(modeSpeed);//Default 60
//     }
//     if (specialMode == 9) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//         /*for (int i=0;i<=LEDCOUNT;i++){
//               ledStatus[i] = 50;
//               setPopHang[i] = 50;
//               popHang[i]=0;
//               rStates[i] = 0;
//               bStates[i] = 0;
//               gStates[i] = 0;
//             }*/
//         memset(ledStatus, 0, sizeof(ledStatus));
//         memset(setPopHang, 0, sizeof(setPopHang));
//         memset(popHang, 0, sizeof(popHang));
//         memset(rStates, 0, sizeof(rStates));
//         memset(gStates, 0, sizeof(gStates));
//         memset(bStates, 0, sizeof(bStates));
//         Serial.println(9);
//       }
//       twinkle(modeSpeed);  //Default 60
//     }
//     if (specialMode == 10) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         //            strip.fill(strip.Color(stripBright*(color1[0]/255),stripBright*(color1[1]/255),stripBright*(color1[2]/255)),0,LEDCOUNT);
//         strip.show();
//         aStep = 0;
//         /*for (int i=0;i<=LEDCOUNT;i++){
//               ledStatus[i] = 50;
//               setPopHang[i] = 50;
//               popHang[i]=0;
//               rStates[i] = 0;
//               bStates[i] = 0;
//               gStates[i] = 0;
//             }*/
//         memset(ledStatus, 0, sizeof(ledStatus));
//         memset(setPopHang, 0, sizeof(setPopHang));
//         memset(popHang, 0, sizeof(popHang));
//         memset(rStates, 0, sizeof(rStates));
//         memset(gStates, 0, sizeof(gStates));
//         memset(bStates, 0, sizeof(bStates));
//         Serial.println(10);
//       }
//       sparkle(modeSpeed);  //Default 60
//     }
//     if (specialMode == 11) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//         aStep = 0;
//         /*for (int i=0;i<=LEDCOUNT;i++){
//             ledStatus[i]=0;
//             }*/
//         memset(ledStatus, 0, sizeof(ledStatus));
//         Serial.println(11);
//       }
//       rLights(modeSpeed);  //Default 60
//     }
//     if (specialMode == 12) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//         aStep = 1;
//         /*for (int i=0;i<=LEDCOUNT;i++){
//             ledStatus[i]=0;
//             }*/
//         memset(ledStatus, 0, sizeof(ledStatus));
//         barDirection = false;
//         setBarSize = 0;
//         Serial.println(12);
//       }
//       tChase(modeSpeed);  //Default 60
//     }
//     if (specialMode == 13) {
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//         aStep = 1;
//         /*for (int i=0;i<=LEDCOUNT;i++){
//             ledStatus[i]=0;
//             }*/
//         memset(ledStatus, 0, sizeof(ledStatus));
//         barDirection = false;
//         setBarSize = 0;
//         Serial.println(13);
//       }
//       // Meteor(modeSpeed);//Default 60
//     }
//     if (specialMode == 14) {  //Pop
//       if (aOn == false) {
//         aOn = true;
//         pMillis = -1000;
//         for (uint16_t i = 0; i < LEDCOUNT; i++) {
//           rStates[i] = 0;
//           gStates[i] = 0;
//           bStates[i] = 0;
//         }
//         strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
//         strip.show();
//       }
//       pop(modeSpeed);  //Default 50
//     }
//   }
//   //Timeout
//   if (ledMode == 11) {
//     if (aOn == false) {
//       // goingUp = false;
//       for (int i = 0; i < LEDCOUNT; i++) {
//         beamPos[i] = 1;
//         if (ledNum < beamSize) {
//           if (ledON == false) {
//             beamPos[i] = 1;
//           } else {
//             beamPos[i] = 1;
//           }
//           ledNum++;
//         } else if (ledNum >= beamSize) {
//           ledON = !ledON;
//           ledNum = 0;
//         }
//       }
//       aOn = true;
//       brightness = 255;
//       pMillis = -1000;
//     }
//     timeoutMode(20);
//   }
// }



void colorMode (unsigned int r, unsigned int g, unsigned int b){
  if (currentModeName != previousModeName){
  strip.fill(strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)), 0, LEDCOUNT);
  strip.show();
  previousModeName = currentModeName;
  }
}

// Fill the dots one after the other with a color
// void colorWipe(uint32_t c, uint8_t freq) {
//   uint16_t wait;
//   wait = (1000 / freq) / 2;
//   for (uint16_t i = 0; i < strip.numPixels(); i++) {
//     strip.setPixelColor(i, c);
//     strip.show();
//     delay(wait);
//   }
// }

// Slightly different, this makes the rainbow equally distributed throughout
void rainbowCycle(unsigned long freq) {
  uint16_t wait;
  wait = (1000 / freq) / 2;
  uint16_t i;
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    pMillis = cMillis;
    if (aStep < 256) {
      for (i = 0; i < strip.numPixels(); i++) {
        strip.setPixelColor(i, Wheel(((i * 256 / strip.numPixels()) + aStep) & 255));
      }
      strip.show();
      aStep++;
    }
  }
  if (aStep >= 256) {
    aStep = 0;
  }
}

// Input a value 0 to 255 to get a color value.
// The colours are a transition r - g - b - back to r.
uint32_t Wheel(byte WheelPos) {
  WheelPos = 255 - WheelPos;
  if (WheelPos < 85) {
    return strip.Color(stripBright * (255 - WheelPos * 3) / 255, 0, stripBright * (WheelPos * 3) / 255);
  }
  if (WheelPos < 170) {
    WheelPos -= 85;
    return strip.Color(0, stripBright * (WheelPos * 3) / 255, stripBright * (255 - WheelPos * 3) / 255);
  }
  WheelPos -= 170;
  return strip.Color(stripBright * (WheelPos * 3) / 255, stripBright * (255 - WheelPos * 3) / 255, 0);
}

void fade(unsigned long freq) {
  uint16_t wait;
  wait = (1000 / freq) / 2;
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    pMillis = cMillis;
    if (aStep < 360) {

      fh = aStep;
      rgb out_rgb;
      out_rgb.r = 0;
      out_rgb.g = 0;
      out_rgb.b = 0;
      hsv in_hsv;
      in_hsv.h = fh;
      in_hsv.s = 100;
      in_hsv.v = 100;
      out_rgb = HSVConverter.HSVtoRGB(in_hsv, out_rgb);
      fr = out_rgb.r;
      fg = out_rgb.g;
      fb = out_rgb.b;
      strip.fill(strip.Color(stripBright * (fr / 255), stripBright * (fg / 255), stripBright * (fb / 255)), 0, LEDCOUNT);
    }
    strip.show();
    aStep++;
  }
  if (aStep >= 360) {
    aStep = 0;
  }
}

void breathe(unsigned int r, unsigned int g, unsigned int b, unsigned long freq) {
  long cwait;
  cwait = ((1000 / freq) / 2) * (255 / stripBright);
  if (brightness < stripBright && prevBrightness != brightness && (cMillis - pMillis >= cwait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    prevBrightness = brightness;
    strip.fill(strip.Color(brightness * (color1[0] / 255), brightness * (color1[1] / 255), brightness * (color1[2] / 255)), 0, LEDCOUNT);
    strip.show();
    if (goingUp == true) {
      brightness++;
    } else if (goingUp == false) {
      brightness--;
    }
    if (brightness >= stripBright) {
      goingUp = false;
    }
    if (brightness <= 0) {
      goingUp = true;
    }
    pMillis = cMillis;
  }
  if (brightness >= stripBright && (cMillis - pMillis >= (1000 / (2 * (brightness - (stripBright)))) && (aOn == true) && (ledState == true)) && (freq > 0)) {
    strip.fill(strip.Color(brightness * (color1[0] / 255), brightness * (color1[1] / 255), brightness * (color1[2] / 255)), 0, LEDCOUNT);
    strip.show();
    if (brightness == stripBright) {
      prevBrightness = brightness;
    }
    goingUp = false;
    if (goingUp == false) {
      brightness--;
    }
    pMillis = cMillis;
  }
}

void strobe(unsigned int r, unsigned int g, unsigned int b, unsigned long freq) {
  uint16_t wait;
  wait = (1000 / freq) / 2;
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    // Serial.println("Strobe Start");
    if (strobeOn == false) {
      strip.fill(strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)), 0, LEDCOUNT);
      strobeOn = true;
    } else {
      strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
      strobeOn = false;
    }
    strip.show();
    pMillis = cMillis;
  }
}

void alternatingColors(unsigned int r, unsigned int g, unsigned int b, unsigned int sr, unsigned int sg, unsigned int sb, unsigned long freq) {
  uint16_t wait;
  wait = (1000 / freq) / 2;
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    if ((ledDiv % 2) == 0) {
      if (altState == true) {
        for (int i = 0; i <= (ledDiv - 1); i++) {
          if (color == false) {
            strip.fill(strip.Color(stripBright * ((color1[0]) / 255), stripBright * ((color1[1]) / 255), stripBright * ((color1[2]) / 255)), (((LEDCOUNT / ledDiv) + 1) * i), (LEDCOUNT / ledDiv) * (i + 1));
            color = true;
          } else {
            strip.fill(strip.Color(stripBright * (color2[0] / 255), stripBright * (color2[1] / 255), stripBright * (color2[2] / 255)), (((LEDCOUNT / ledDiv) + 1) * i), (LEDCOUNT / ledDiv) * (i + 1));
            color = false;
          }
        }
        strip.show();
        altState = false;
      } else {
        for (int j = 0; j <= (ledDiv - 1); j++) {
          if (color == false) {
            strip.fill(strip.Color(stripBright * (color2[0] / 255), stripBright * (color2[1] / 255), stripBright * (color2[2] / 255)), (((LEDCOUNT / ledDiv) + 1) * j), (LEDCOUNT / ledDiv) * (j + 1));
            color = true;
          } else {
            strip.fill(strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)), (((LEDCOUNT / ledDiv) + 1) * j), (LEDCOUNT / ledDiv) * (j + 1));
            color = false;
          }
        }
        strip.show();
        altState = true;
      }
    } else if ((ledDiv % 2)) {
      if (altState == true) {
        for (int i = 0; i <= (ledDiv - 1); i++) {
          if (color == false) {
            strip.fill(strip.Color(stripBright * ((color1[0]) / 255), stripBright * ((color1[1]) / 255), stripBright * ((color1[2]) / 255)), (((LEDCOUNT / ledDiv) + 1) * i), (LEDCOUNT / ledDiv) * (i + 1));
            color = true;
          } else {
            strip.fill(strip.Color(stripBright * (color2[0] / 255), stripBright * (color2[1] / 255), stripBright * (color2[2] / 255)), (((LEDCOUNT / ledDiv) + 1) * i), (LEDCOUNT / ledDiv) * (i + 1));
            color = false;
          }
        }
        strip.show();
        altState = true;
      } else {
        for (int j = 0; j <= (ledDiv - 1); j++) {
          if (color == false) {
            strip.fill(strip.Color(stripBright * (color2[0] / 255), stripBright * (color2[1] / 255), stripBright * (color2[2] / 255)), (((LEDCOUNT / ledDiv) + 1) * j), (LEDCOUNT / ledDiv) * (j + 1));
            color = true;
          } else {
            strip.fill(strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)), (((LEDCOUNT / ledDiv) + 1) * j), (LEDCOUNT / ledDiv) * (j + 1));
            color = false;
          }
        }
        strip.show();
        altState = false;
      }
    }

    pMillis = cMillis;
  }
}

void pulse(unsigned int r, unsigned int g, unsigned int b, unsigned int sr, unsigned int sg, unsigned int sb, unsigned long freq) {
  uint16_t wait;
  wait = (1000 / freq);
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    while (pixChosen < 5) {
      if (pixChosen == 1) {

        int dir = (random(0, 1000) / 2);
        if ((dir % 2) == 0) {
          pulseBar1[0] = 0;
        } else {
          pulseBar1[0] = 1;
        }
        pulseBar1[1] = random(2, 10);
        pulseBar1[2] = (stripBright * (color1[0] / 255));
        pulseBar1[3] = (stripBright * (color1[1] / 255));
        pulseBar1[4] = (stripBright * (color1[2] / 255));
        pulseBar1[5] = 72;
        pulseBar1[6] = random(0, 8);
        pulseBar1[7] = 0;
      }
      if (pixChosen == 2) {
        pulseBar2[0] = random(0, 1);
        pulseBar2[1] = random(1, 6);
        pulseBar2[2] = (stripBright * (color1[0] / 255));
        pulseBar2[3] = (stripBright * (color1[1] / 255));
        pulseBar2[4] = (stripBright * (color1[2] / 255));
        pulseBar2[5] = 72;
        pulseBar2[6] = random(0, 8);
        pulseBar2[7] = 0;
      }
      if (pixChosen == 3) {
        pulseBar3[0] = random(0, 1);
        pulseBar3[1] = random(1, 6);
        pulseBar3[2] = (stripBright * (color1[0] / 255));
        pulseBar3[3] = (stripBright * (color1[1] / 255));
        pulseBar3[4] = (stripBright * (color1[2] / 255));
        pulseBar3[5] = 72;
        pulseBar3[6] = random(0, 8);
        pulseBar3[7] = 0;
      }
      if (pixChosen == 4) {
        pulseBar4[0] = random(0, 1);
        pulseBar4[1] = random(1, 6);
        pulseBar4[2] = (stripBright * (color1[0] / 255));
        pulseBar4[3] = (stripBright * (color1[1] / 255));
        pulseBar4[4] = (stripBright * (color1[2] / 255));
        pulseBar4[5] = 72;
        pulseBar4[6] = random(0, 8);
        pulseBar4[7] = 0;
      }
      if (pixChosen == 5) {
        pulseBar5[0] = random(0, 1);
        pulseBar5[1] = random(1, 6);
        pulseBar5[2] = (stripBright * (color1[0] / 255));
        pulseBar5[3] = (stripBright * (color1[1] / 255));
        pulseBar5[4] = (stripBright * (color1[2] / 255));
        pulseBar5[5] = 72;
        pulseBar5[6] = random(0, 8);
        pulseBar5[7] = 0;
      } else {
      }
      pixChosen++;
    }
    if (pixChosen >= 5) {
      if (pulseBar1[7] == pulseBar1[6]) {
        if (pulseBar1[5] == 0 || pulseBar1[5] == LEDCOUNT) {
          if (pulseBar1[0] == 0) {
            pulseBar1[5] = pulseBar1[5] + pulseBar1[1] + 1;
            pulseBar1[0] = 1;
          } else {
            pulseBar1[5] = pulseBar1[5] - pulseBar1[1] - 1;
            pulseBar1[0] = 0;
          }
        }

        ledStatus[int(pulseBar1[5])] = 1;
        if (pulseBar1[0] == 1) {
          ledStatus[int(pulseBar1[5]) - int(pulseBar1[1])] = 0;
          pulseBar1[5]++;
        } else {
          ledStatus[int(pulseBar1[5]) + int(pulseBar1[1])] = 0;
          pulseBar1[5]--;
        }
        pulseBar1[7] = 0;
      } else {
        pulseBar1[7]++;
      }
      if (pulseBar2[7] == pulseBar2[6]) {
        if (pulseBar2[5] == 0 || pulseBar2[5] == LEDCOUNT) {
          if (pulseBar2[0] == 0) {
            pulseBar2[5] = pulseBar2[5] + pulseBar2[1] + 1;
            pulseBar2[0] = 1;
          } else {
            pulseBar2[5] = pulseBar2[5] - pulseBar2[1] - 1;
            pulseBar2[0] = 0;
          }
        }

        ledStatus[int(pulseBar2[5])] = 1;
        if (pulseBar2[0] == 1) {
          ledStatus[int(pulseBar2[5]) - int(pulseBar2[1])] = 0;
          pulseBar2[5]++;
        } else {
          ledStatus[int(pulseBar2[5]) + int(pulseBar2[1])] = 0;
          pulseBar2[5]--;
        }
        pulseBar2[7] = 0;
      } else {
        pulseBar2[7]++;
      }
      if (pulseBar3[7] == pulseBar3[6]) {
        if (pulseBar3[5] == 0 || pulseBar3[5] == LEDCOUNT) {
          if (pulseBar3[0] == 0) {
            pulseBar3[5] = pulseBar3[5] + pulseBar3[1] + 1;
            pulseBar3[0] = 1;
          } else {
            pulseBar3[5] = pulseBar3[5] - pulseBar3[1] - 1;
            pulseBar3[0] = 0;
          }
        }

        ledStatus[int(pulseBar3[5])] = 1;
        if (pulseBar3[0] == 1) {
          ledStatus[int(pulseBar3[5]) - int(pulseBar3[1])] = 0;
          pulseBar3[5]++;
        } else {
          ledStatus[int(pulseBar3[5]) + int(pulseBar3[1])] = 0;
          pulseBar3[5]--;
        }
        pulseBar3[7] = 0;
      } else {
        pulseBar3[7]++;
      }
      if (pulseBar4[7] == pulseBar4[6]) {
        if (pulseBar4[5] == 0 || pulseBar4[5] == LEDCOUNT) {
          if (pulseBar4[0] == 0) {
            pulseBar4[5] = pulseBar4[5] + pulseBar4[1] + 1;
            pulseBar4[0] = 1;
          } else {
            pulseBar4[5] = pulseBar4[5] - pulseBar4[1] - 1;
            pulseBar4[0] = 0;
          }
        }

        ledStatus[int(pulseBar4[5])] = 1;
        if (pulseBar4[0] == 1) {
          ledStatus[int(pulseBar4[5]) - int(pulseBar4[1])] = 0;
          pulseBar4[5]++;
        } else {
          ledStatus[int(pulseBar4[5]) + int(pulseBar4[1])] = 0;
          pulseBar4[5]--;
        }
        pulseBar4[7] = 0;
      } else {
        pulseBar4[7]++;
      }
      if (pulseBar5[7] == pulseBar5[6]) {
        if (pulseBar5[5] == 0 || pulseBar5[5] == LEDCOUNT) {
          if (pulseBar5[0] == 0) {
            pulseBar5[5] = pulseBar5[5] + pulseBar5[1] + 1;
            pulseBar5[0] = 1;
          } else {
            pulseBar5[5] = pulseBar5[5] - pulseBar5[1] - 1;
            pulseBar5[0] = 0;
          }
        }

        ledStatus[int(pulseBar5[5])] = 1;
        if (pulseBar5[0] == 1) {
          ledStatus[int(pulseBar5[5]) - int(pulseBar5[1])] = 0;
          pulseBar5[5]++;
        } else {
          ledStatus[int(pulseBar5[5]) + int(pulseBar5[1])] = 0;
          pulseBar5[5]--;
        }
        pulseBar5[7] = 0;
      } else {
        pulseBar5[7]++;
      }
    }
    for (uint16_t i = 0; i < LEDCOUNT; i++) {
      if (ledStatus[i] == 1) {
        strip.setPixelColor(i, (stripBright * (color1[0] / 255)), (stripBright * (color1[1] / 255)), (stripBright * (color1[2] / 255)) / 10);
      } else {
        strip.setPixelColor(i, ((stripBright * (color2[0] / 255)) / 10), ((stripBright * (color2[1] / 255)) / 10), ((stripBright * (color2[2] / 255)) / 10));
      }
    }
    strip.show();
    pMillis = cMillis;
  }
}

void pop(unsigned int r, unsigned int g, unsigned int b, unsigned long speed) {
  unsigned long freq = map(speed, 1, 100, 300, 1);
  if ((cMillis - pMillis) >= 10 && (aOn == true) && (ledState == true)) {
    if (random(freq) == 1) {
      uint16_t pix = random(LEDCOUNT);
      if (rStates[pix] < 1 && gStates[pix] < 1 && bStates[pix] < 1 && (speed > 0)) {
        rStates[pix] = (stripBright * (color2[0] / 255));
        gStates[pix] = (stripBright * (color2[1] / 255));
        bStates[pix] = (stripBright * (color2[2] / 255));
      }
    }
    for (uint16_t i = 0; i < LEDCOUNT; i++) {
      if (rStates[i] > 1 || gStates[i] > 1 || bStates[i] > 1) {
        strip.setPixelColor(i, rStates[i], gStates[i], bStates[i]);

        if (popHang[i] >= 200) {
          if (rStates[i] > 1) {
            rStates[i] = rStates[i] * 0.99;
          } else {
            rStates[i] = 0;
          }

          if (gStates[i] > 1) {
            gStates[i] = gStates[i] * 0.99;
          } else {
            gStates[i] = 0;
          }

          if (bStates[i] > 1) {
            bStates[i] = bStates[i] * 0.99;
          } else {
            bStates[i] = 0;
          }
        } else if (popHang[i] < 200) {
          popHang[i]++;
        }
      } else {
        strip.setPixelColor(i, ((stripBright * (color1[0] / 255)) / 10), ((stripBright * (color1[1] / 255)) / 10), ((stripBright * (color1[2] / 255)) / 10));
      }
    }
    strip.show();
    pMillis = cMillis;
  }
}

void paint(unsigned long freq) {
  uint16_t wait = (1000 / freq) / 2;
  uint16_t pix;
  if (((cMillis - pMillis) >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    if (random(75) == 1) {
      pix = random(LEDCOUNT);
      if ((rStates[pix] != nextrgb[0]) || (gStates[pix] != nextrgb[1]) || (bStates[pix] != nextrgb[2])) {
        rStates[pix] = nextrgb[0];
        gStates[pix] = nextrgb[1];
        bStates[pix] = nextrgb[2];
        strip.setPixelColor(pix, rStates[pix], gStates[pix], bStates[pix]);
        strip.show();
        Serial.println("Chosen");
        pixChosen++;
        Serial.print("Pixels Left: ");
        Serial.println(LEDCOUNT - pixChosen);
      }
    }
    if (pixChosen >= (LEDCOUNT - 50)) {
      Serial.println("Already Set");

      uint16_t colorOption = random(7);
      while (colorOption == pColorOption) {
        colorOption = random(7);
      }
      pColorOption = colorOption;
      for (uint16_t i = 0; i < LEDCOUNT; i++) {
        rStates[i] = 0;
        gStates[i] = 0;
        bStates[i] = 0;
      }
      Serial.print("Chosen Option: ");
      Serial.println(colorOption);
      pixChosen = 0;
      strip.fill(strip.Color(nextrgb[0], nextrgb[1], nextrgb[2]), 0, LEDCOUNT);
      strip.show();

      if (colorOption == 0) {
        nextrgb[0] = 255;
        nextrgb[1] = 0;
        nextrgb[2] = 0;
      }
      if (colorOption == 1) {
        nextrgb[0] = 255;
        nextrgb[1] = 165;
        nextrgb[2] = 0;
      }
      if (colorOption == 2) {
        nextrgb[0] = 255;
        nextrgb[1] = 255;
        nextrgb[2] = 0;
      }
      if (colorOption == 3) {
        nextrgb[0] = 0;
        nextrgb[1] = 255;
        nextrgb[2] = 0;
      }
      if (colorOption == 4) {
        nextrgb[0] = 0;
        nextrgb[1] = 0;
        nextrgb[2] = 255;
      }
      if (colorOption == 5) {
        nextrgb[0] = 255;
        nextrgb[1] = 0;
        nextrgb[2] = 255;
      }
      if (colorOption == 6) {
        nextrgb[0] = 255;
        nextrgb[1] = 102;
        nextrgb[2] = 178;
      }
      if (colorOption == 7) {
        nextrgb[0] = 102;
        nextrgb[1] = 255;
        nextrgb[2] = 255;
      } else {
      }
    }
    pMillis = cMillis;
  }
}
void cylon(unsigned int r, unsigned int g, unsigned int b, unsigned int sr, unsigned int sg, unsigned int sb, unsigned long freq) {
  uint16_t wait = (1000 / freq);
  if ((barDirection == false) && (ledStatus[aStep] == 0) && (setBarSize <= barSize) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)));
    strip.show();
    ledStatus[aStep] = 1;
    setBarSize++;
    aStep++;
    pMillis = cMillis;
  }
  if ((barDirection == false) && (ledStatus[aStep] == 0) && (setBarSize >= barSize) && (aStep <= LEDCOUNT) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)));
    strip.setPixelColor((aStep - barSize - 1), strip.Color(0, 0, 0));
    ledStatus[aStep - barSize - 1] = 0;
    strip.show();
    ledStatus[aStep] = 1;
    if (aStep == LEDCOUNT) {
      barDirection = true;
      aStep = (aStep - barSize - 1);
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
  if ((barDirection == true) && (ledStatus[aStep] == 0) && (ledStatus[aStep + 1] == 1) && (setBarSize >= barSize) && (aStep >= 0) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(stripBright * (color2[0] / 255), stripBright * (color2[1] / 255), stripBright * (color2[2] / 255)));
    strip.setPixelColor((aStep + barSize + 1), strip.Color(0, 0, 0));
    ledStatus[aStep + barSize + 1] = 0;
    strip.show();
    ledStatus[aStep] = 1;
    if (aStep == 0) {
      barDirection = false;
      aStep = (aStep + barSize + 1);
    } else {
      aStep--;
    }
    pMillis = cMillis;
  }
}

void phaser(unsigned int r, unsigned int g, unsigned int b, unsigned long freq) {
  uint16_t wait = (1000 / freq);
  if ((barDirection == false) && (ledStatus[aStep] == 0) && (setBarSize <= barSize) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)));
    strip.show();
    ledStatus[aStep] = 1;
    setBarSize++;
    aStep++;
    pMillis = cMillis;
  }
  if ((barDirection == false) && (ledStatus[aStep] == 0) && (setBarSize >= barSize) && (aStep <= LEDCOUNT) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)));
    strip.setPixelColor((aStep - barSize - 1), strip.Color(0, 0, 0));
    ledStatus[aStep - barSize - 1] = 0;
    strip.show();
    ledStatus[aStep] = 1;
    if (aStep == LEDCOUNT) {
      barDirection = true;
      aStep = (aStep - barSize);
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
  if ((barDirection == true) && (ledStatus[aStep] == 1) && (aStep <= LEDCOUNT) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(0, 0, 0));
    strip.show();
    setBarSize--;
    ledStatus[aStep] = 0;
    if (aStep == LEDCOUNT) {
      barDirection = false;
      aStep = 0;
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
}

void aPhaser(unsigned int r, unsigned int g, unsigned int b, unsigned int sr, unsigned int sg, unsigned int sb) {
  uint16_t wait = 1000;
  if ((barDirection == false) && (ledStatus[aStep] == 0) && (setBarSize <= barSize) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 0)) {
    strip.setPixelColor(aStep, strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)));
    strip.show();
    ledStatus[aStep] = 1;
    setBarSize++;
    aStep++;
    pMillis = cMillis;
  }
  if ((barDirection == false) && (ledStatus[aStep] == 0) && (setBarSize >= barSize) && (aStep <= LEDCOUNT) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 0)) {
    strip.setPixelColor(aStep, strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)));
    strip.setPixelColor((aStep - barSize - 1), strip.Color(0, 0, 0));
    ledStatus[aStep - barSize - 1] = 0;
    strip.show();
    ledStatus[aStep] = 1;
    if (aStep == LEDCOUNT) {
      barDirection = true;
      aStep = (aStep - barSize);
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
  if ((barDirection == true) && (ledStatus[aStep] == 1) && (aStep <= LEDCOUNT) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 0)) {
    strip.setPixelColor(aStep, strip.Color(0, 0, 0));
    strip.show();
    setBarSize--;
    ledStatus[aStep] = 0;
    if (aStep == LEDCOUNT) {
      phaserNum = 1;
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
  if ((barDirection == true) && (ledStatus[aStep] == 0) && (setBarSize <= barSize) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 1)) {
    strip.setPixelColor(aStep, strip.Color(stripBright * (color2[0] / 255), stripBright * (color2[1] / 255), stripBright * (color2[2] / 255)));
    strip.show();
    ledStatus[aStep] = 1;
    setBarSize++;
    aStep--;
    pMillis = cMillis;
  }
  if ((barDirection == true) && (ledStatus[aStep] == 0) && (setBarSize >= barSize) && (aStep >= 0) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 1)) {
    strip.setPixelColor(aStep, strip.Color(stripBright * (color2[0] / 255), stripBright * (color2[1] / 255), stripBright * (color2[2] / 255)));
    strip.setPixelColor((aStep + barSize + 1), strip.Color(0, 0, 0));
    ledStatus[aStep + barSize + 1] = 0;
    strip.show();
    ledStatus[aStep] = 1;
    if (aStep == 0) {
      barDirection = false;
      aStep = (aStep + barSize);
    } else {
      aStep--;
    }
    pMillis = cMillis;
  }
  if ((barDirection == false) && (ledStatus[aStep] == 1) && (aStep >= 0) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 1)) {
    strip.setPixelColor(aStep, strip.Color(0, 0, 0));
    strip.show();
    setBarSize--;
    ledStatus[aStep] = 0;
    if (aStep == 0) {
      phaserNum = 0;
    } else {
      aStep--;
    }
    pMillis = cMillis;
  }
}

void pLights(unsigned long freq) {
  uint16_t wait;
  wait = (1000 / freq) / 2;
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (altState == false) && (freq <= 10)) {
    strip.fill(strip.Color(255, 0, 0), (LEDCOUNT / 2), LEDCOUNT);
    strip.fill(strip.Color(0, 0, 0), 0, (LEDCOUNT / 2));
    strip.show();
    altState = true;
    pMillis = cMillis;
  }
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (altState == true) && (freq <= 10)) {
    strip.fill(strip.Color(0, 0, 255), 0, (LEDCOUNT / 2));
    strip.fill(strip.Color(0, 0, 0), (LEDCOUNT / 2), LEDCOUNT);
    strip.show();
    altState = false;
    pMillis = cMillis;
  }
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (altState == false) && (freq > 10)) {
    if ((aStep == 0) || (aStep == 2) || (aStep == 4) || (aStep == 6) || (aStep == 8)) {
      strip.fill(strip.Color(255, 0, 0), (LEDCOUNT / 2), LEDCOUNT);
      strip.show();
    }

    if ((aStep == 1) || (aStep == 3) || (aStep == 5) || (aStep == 7) || (aStep == 9)) {
      strip.fill(strip.Color(0, 0, 0), (LEDCOUNT / 2), LEDCOUNT);
      strip.show();
    }
    if (aStep >= 9) {
      altState = true;
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (altState == true) && (freq > 10)) {
    if ((aStep == 0) || (aStep == 2) || (aStep == 4) || (aStep == 6) || (aStep == 8)) {
      strip.fill(strip.Color(0, 0, 255), 0, (LEDCOUNT / 2));
      strip.show();
    }
    if ((aStep == 1) || (aStep == 3) || (aStep == 5) || (aStep == 7) || (aStep == 9)) {
      strip.fill(strip.Color(0, 0, 0), 0, (LEDCOUNT / 2));
      strip.show();
    }
    if (aStep <= 0) {
      altState = false;
    } else {
      aStep--;
    }
    pMillis = cMillis;
  }
}

void tChase(unsigned int r, unsigned int g, unsigned int b, unsigned long freq) {
  uint16_t wait;
  int dotSpacing = 12;
  wait = (1000 / freq);
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    if (aStep < dotSpacing) {
      aStep++;
    } else if (aStep >= dotSpacing) {
      aStep = 1;
    }
    for (int i = 0; i <= LEDCOUNT; i++) {
      if ((i + aStep) % dotSpacing == 0) {
        strip.setPixelColor(i, strip.Color(stripBright * (color2[0] / 255), stripBright * (color2[1] / 255), stripBright * (color2[2] / 255)));
      } else {
        strip.setPixelColor(i, strip.Color(0, 0, 0));
      }
    }
    strip.show();
    pMillis = cMillis;
  }
}

void rLights(unsigned int r, unsigned int g, unsigned int b, unsigned long freq, unsigned long div) {
  uint16_t wait;
  int barSize = 3;
  int spacingSize = 12;
  int index = 0;
  wait = (1000 / freq);
  int offsetNum = 0;
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    if (aStep < spacingSize) {
      aStep++;
    } else if (aStep >= spacingSize) {
      aStep = 0;
    }
    index = 0;
    strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
    for (int i = 0; i <= LEDCOUNT; i++) {
      if ((index <= (barSize - 1)) && (index <= spacingSize)) {
        strip.setPixelColor(i + aStep, strip.Color(stripBright * (color1[0] / 255), stripBright * (color1[1] / 255), stripBright * (color1[2] / 255)));
        index++;
      } else if ((index >= barSize) && (index <= (spacingSize + 1))) {
        strip.setPixelColor(i + aStep, strip.Color(0, 0, 0));
        index++;
      }
      if ((index > barSize) && (index > spacingSize)) {
        index = 0;
      }
    }
    strip.show();
    pMillis = cMillis;
  }
}

void fire(unsigned long freq) {
  uint16_t wait;
  int barSize = 3;
  int spacingSize = 12;
  int index = 0;
  wait = (1000 / freq);
  int offsetNum = 0;
  if ((cMillis - pMillis >= random(150, 275)) && (aOn == true) && (ledState == true)) {
    for (int i = 0; i < LEDCOUNT; i++) {
      int flicker = random(0, 150);
      int r1 = 255 - flicker;
      int g1 = 150 - flicker;
      int b1 = 40 - flicker;
      if (g1 < 0) g1 = 0;
      if (r1 < 0) r1 = 0;
      if (b1 < 0) b1 = 0;
      strip.setPixelColor(i, r1, g1, b1);
    }
    strip.show();
    pMillis = cMillis;
  }
}

void tClock(bool tUpdate) {
  const int hBar = 20;
  const int mBar = 6;
  const int sBar = 12;
  const int sBarTrail = 3;


  if (!tUpdate || !aOn || !ledState) {
    return;
  }

  if (stripBright >= 30) {
    handBright = (255 / 255) * stripBright;
    mHandBright = (255 / 255) * stripBright / 4;
    backBright = (255 / 255) * stripBright / 4;
  } else {
    handBright = 60;
    mHandBright = 15;
    backBright = (255 / 255) * stripBright / 4;
  }

  int elapsedsec = (cMillis - tMillis) / 1000;
  int cHour;
  if (hour >= 12) {
    cHour = hour - 12;
  } else {
    cHour = hour;
  }
  if (sBarPos - sBar / 2 >= LEDCOUNT) {
    sBarPos = sBar / 2;
  }
  for (int i = 0; i < LEDCOUNT; i++) {
    if ((i <= hourMap[cHour] + (hBar / 2) && i >= hourMap[cHour] - (hBar / 2)) && (i > minuteMap[minute] + (mBar / 2) || i < minuteMap[minute] - (mBar / 2))) {
      strip.setPixelColor(i, strip.Color(handBright, 0, 0));
    } /*else if (hourMap[cHour] + (hBar/2) > LEDCOUNT){
      strip.fill(strip.Color(handBright, 0, 0),0,(hourMap[cHour] + (hBar/2) - LEDCOUNT)); //This bit of code is to remap the hour hand in the event that its bar spans the start and end of the LED strip
    } else if (hourMap[cHour] - (hBar/2) < 0){
      strip.fill(strip.Color(handBright, 0, 0),(LEDCOUNT + (hourMap[cHour]-(hBar/2))), LEDCOUNT);
    }*/
    else if ((i > hourMap[cHour] + (hBar / 2) || i < hourMap[cHour] - (hBar / 2)) && (i <= minuteMap[minute] + (mBar / 2) && i >= minuteMap[minute] - (mBar / 2))) {
      strip.setPixelColor(i, strip.Color(handBright, handBright, 0));
    } else if ((i <= hourMap[cHour] + (hBar / 2) && i >= hourMap[cHour] - (hBar / 2)) && (i <= minuteMap[minute] + (mBar / 2) && i >= minuteMap[minute] - (mBar / 2))) {
      strip.setPixelColor(i, strip.Color(handBright, handBright, handBright));
    } else {
      strip.setPixelColor(i, strip.Color(backBright, 0, backBright));
    }
  }
  for (int j = -sBar / 2; j < sBar / 2; j++) {
    if (j < -sBar / 2 + sBarTrail) {
      strip.setPixelColor(j + sBarPos, strip.Color(0, (abs((255 / sBarTrail) / j * 16) / 255) * stripBright, 0));
    } else if (j + sBarPos > LEDCOUNT) {
      strip.setPixelColor(j + sBarPos - LEDCOUNT, strip.Color(0, handBright, 0));
    } else if (j + sBarPos < 0) {
      strip.setPixelColor(LEDCOUNT + j + 1, strip.Color(0, handBright, 0));
    } else {
      strip.setPixelColor(j + sBarPos, strip.Color(0, handBright, 0));
    }
  }
  for (int l = 0; l < sizeof(minuteMap) / sizeof(minuteMap[0]); l++) {
    int m = minuteMap[l];
    bool isInHourMap = false;
    for (int n = 0; n < sizeof(hourMap) / sizeof(hourMap[0]); n++) {
      int k = hourMap[n];
      if (m == k) {
        isInHourMap = true;
        break;
      } else if (n % 3 == 0) {
        strip.setPixelColor(k, strip.Color(handBright, handBright, handBright));
      }
    }
    if (isInHourMap && l != 0 && l != 15 && l != 30 && l != 45) {
      strip.setPixelColor(m, strip.Color(0, handBright / 2, handBright / 2));
    } else if (!isInHourMap) {
      strip.setPixelColor(m, strip.Color(0, 0, mHandBright));
    }
  }
  strip.show();
}
void twinkle(unsigned int r, unsigned int g, unsigned int b, unsigned long speed) {
  unsigned long freq = map(speed, 1, 100, 300, 1);
  if ((cMillis - pMillis) >= 20 && (aOn == true) && (ledState == true)) {
    if (random(freq) == 1) {
      uint16_t pix = random(LEDCOUNT);
      if ((ledStatus[pix] == 0) && (speed > 0)) {
        rStates[pix] = color1[0];
        gStates[pix] = color1[1];
        bStates[pix] = color1[2];
        ledStatus[pix] = 1;
        setPopHang[pix] = random(0, 20);
      }
    }
    for (int i = 0; i < LEDCOUNT; i++) {
      if ((ledStatus[i] >= 100) && (popHang[i] <= setPopHang[i])) {
        popHang[i]++;
      }
      if ((ledStatus[i] > 0) && (ledStatus[i] <= 100)) {
        int correctedbrightness = map(ledStatus[i], 1, 100, 1, 255);
        strip.setPixelColor(i, stripBright * (((rStates[i] / 255) * correctedbrightness) / 255), stripBright * (((gStates[i] / 255) * correctedbrightness) / 255), stripBright * (((bStates[i] / 255) * correctedbrightness)) / 255);
        ledStatus[i]++;
      }
      if ((ledStatus[i] > 100) && (ledStatus[i] < 200) && (popHang[i] >= setPopHang[i])) {
        int correctedbrightness = map(ledStatus[i], 101, 200, 255, 1);
        strip.setPixelColor(i, stripBright * (((rStates[i] / 255) * correctedbrightness) / 255), stripBright * (((gStates[i] / 255) * correctedbrightness) / 255), stripBright * (((bStates[i] / 255) * correctedbrightness)) / 255);
        ledStatus[i]++;
      }
      if ((ledStatus[i] >= 200)) {
        strip.setPixelColor(i, 0, 0, 0);
        ledStatus[i] = 0;
        popHang[i] = 0;
        setPopHang[i] = 0;
        rStates[i] = 0;
        gStates[i] = 0;
        bStates[i] = 0;
      }
    }
    strip.show();
    pMillis = cMillis;
  }
}

void sparkle(unsigned int r, unsigned int g, unsigned int b, unsigned long freq) {
  uint16_t wait;
  int dotSpacing = 12;
  wait = (1000 / freq);
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    for (int i = 0; i <= LEDCOUNT; i++) {
      if (i % dotSpacing == 0) {
        if ((ledStatus[i] == setPopHang[i])) {
          popHang[i] = setPopHang[i];
          while ((setPopHang[i] >= popHang[i] - 40) && (setPopHang[i] <= popHang[i] + 40)) {
            setPopHang[i] = random(0, 100);
          }
        }

        if ((ledStatus[i] > setPopHang[i])) {
          ledStatus[i]--;
          int correctedbrightness = map(ledStatus[i], 0, 100, 0, 255);
          strip.setPixelColor(i, stripBright * (((color1[0] / 255) * correctedbrightness) / 255), stripBright * (((color1[1] / 255) * correctedbrightness) / 255), stripBright * (((color1[2] / 255) * correctedbrightness)) / 255);
          strip.show();
        }
        if ((ledStatus[i] < setPopHang[i])) {
          ledStatus[i]++;
          int correctedbrightness = map(ledStatus[i], 0, 100, 0, 255);
          strip.setPixelColor(i, stripBright * (((color1[0] / 255) * correctedbrightness) / 255), stripBright * (((color1[1] / 255) * correctedbrightness) / 255), stripBright * (((color1[2] / 255) * correctedbrightness)) / 255);
          strip.show();
        }
      }
    }
    pMillis = cMillis;
  }
}

void timeoutMode(unsigned long freq) {
  long cwait;
  cwait = ((1000 / freq) / 2);
  if (prevBrightness != brightness && (cMillis - pMillis >= cwait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    Serial.println("timeoutMode Triggered");
    prevBrightness = brightness;
    for (int i = 0; i < LEDCOUNT; i++) {
      if (beamPos[i] == 1) {
        strip.setPixelColor(i, brightness * (color1[0] / 255), brightness * (color1[1] / 255), brightness * (color1[2] / 255));
        //     strip.setPixelColor(i,255,0,0);
      }
      if (beamPos[i] == 0) {
        strip.setPixelColor(i, 0, 0, 0);
      }
    }
    strip.show();
    if (goingUp == true) {
      brightness++;
    } else if (goingUp == false) {
      brightness--;
    }
    if (brightness >= stripBright) {
      goingUp = false;
    }
    if (brightness <= 0) {
      goingUp = true;
    }
    if (aStep < beamSize) {
      for (int i = 1; i < LEDCOUNT; i++) {
        if (beamPos[i] == 0 && beamPos[i + 1] == 1) {
          beamPos[i] = 1;
        }
        if (beamPos[i] == 1 && beamPos[i + 1] == 0) {
          beamPos[i] = 0;
        }
      }
      if (beamPos[beamSize] == 0 && beamPos[LEDCOUNT - beamSize] == 0) {
        beamPos[LEDCOUNT] = 1;
      }
      if (beamPos[LEDCOUNT - beamSize] == 1) {
        beamPos[LEDCOUNT] = 0;
      }

      aStep++;
      if (aStep >= beamSize) {
        aStep = 0;
      }
    }
    pMillis = cMillis;
  }
}