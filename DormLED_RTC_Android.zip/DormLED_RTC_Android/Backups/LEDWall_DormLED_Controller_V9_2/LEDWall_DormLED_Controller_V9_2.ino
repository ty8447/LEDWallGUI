// DormLED Controller V9.2 - guided LED calibration (Android v5.12)
#include <Adafruit_NeoPixel.h>
#include <EasyColor.h>
#include <Adafruit_TinyUSB.h>
#include "RTClib.h"
#include <bluefruit.h>
#include <vector>
#include <stddef.h>
#include <Adafruit_LittleFS.h>
#include <InternalFileSystem.h>
#include "LEDWall_ConfigTypes.h"

#define MAX_PRPH_CONNECTION 2 // Verified target configuration: two concurrent tablets.
uint8_t connection_count = 0;
static uint32_t stateRevision = 1;
// The BLE write callbacks must not emit a burst of notifications. They only
// flag that the authoritative state changed; loop() publishes it gradually.
static volatile bool pendingStateBroadcast = false;
static volatile bool pendingConfigBroadcast = false;
static uint32_t publishingRevision = 0;
static uint8_t publishingStep = 0;
static uint8_t publishingParameter = 0;
static uint32_t lastStateBroadcastMs = 0;
// Diagnostics: a long gap here indicates a blocked animation or slow peripheral.
static uint32_t maxObservedLoopGapMs = 0;
static uint32_t loopTickCounter = 0;
static uint32_t lastReceivedCommandMs = 0;
static volatile uint32_t totalBleCommandCount = 0;

static uint16_t replyConnection = BLE_CONN_HANDLE_INVALID;
// Diagnostics request: State:Diag:{?} => seconds,loops,maxLoopGapMs,rxCommands,clients,preview
static bool pendingSecurityDisconnect = false;
static uint32_t securityDisconnectAt = 0;
static bool controllerPinSet = false;
static char controllerPin[5] = {};
static bool pinStorageAvailable = false;
static bool sessionAuthorized[MAX_PRPH_CONNECTION] = {};
static uint16_t sessionHandles[MAX_PRPH_CONNECTION] = {};
static uint8_t badPinCount[MAX_PRPH_CONNECTION] = {};
static uint32_t pinLockoutUntil[MAX_PRPH_CONNECTION] = {};
static uint8_t globalBadPinCount = 0;
static uint32_t globalPinLockoutUntil = 0;
static const char* PIN_FILE = "/ledpin4.bin";
static const uint32_t PIN_MAGIC = 0x4C503034UL;
static uint32_t pinChecksum(const StoredPin& cfg) {
  const uint8_t* bytes = reinterpret_cast<const uint8_t*>(&cfg);
  uint32_t h = 2166136261UL;
  for (size_t i=0; i<offsetof(StoredPin, checksum); ++i) h = (h ^ bytes[i]) * 16777619UL;
  return h;
}
static bool validPin(String value) {
  if (value.length() != 4) return false;
  for (int i=0; i<4; ++i) if (value[i] < '0' || value[i] > '9') return false;
  return true;
}
static int authSlot(uint16_t handle) {
  for (int i=0; i<MAX_PRPH_CONNECTION; ++i) if (sessionHandles[i] == handle) return i;
  return -1;
}
static bool authorized(uint16_t handle) {
  const int slot = authSlot(handle);
  return slot >= 0 && sessionAuthorized[slot] && controllerPinSet;
}
static bool lockedOut(uint16_t handle) {
  const int slot = authSlot(handle);
  return (int32_t)(globalPinLockoutUntil - millis()) > 0 ||
         (slot >= 0 && (int32_t)(pinLockoutUntil[slot] - millis()) > 0);
}
static void recordPinFailure(uint16_t handle) {
  if (++globalBadPinCount >= 5) {
    globalPinLockoutUntil = millis() + 60000UL;
    globalBadPinCount = 0;
  }
  const int slot = authSlot(handle);
  if (slot >= 0 && ++badPinCount[slot] >= 5) {
    pinLockoutUntil[slot] = millis() + 60000UL;
    badPinCount[slot] = 0;
  }
}
static void clearAuth() {
  for (int i=0; i<MAX_PRPH_CONNECTION; ++i) sessionAuthorized[i] = false;
}
static bool saveControllerPin() {
  if (!pinStorageAvailable) return false;
  StoredPin cfg = {};
  cfg.magic = PIN_MAGIC;
  if (controllerPinSet) memcpy(cfg.digits, controllerPin, 4);
  cfg.checksum = pinChecksum(cfg);
  Adafruit_LittleFS_Namespace::File file(InternalFS);
  if (!file.open(PIN_FILE, Adafruit_LittleFS_Namespace::FILE_O_WRITE)) return false;
  bool ok = file.seek(0) && file.truncate(0);
  if (ok) ok = file.write((const uint8_t*)&cfg, sizeof(cfg)) == sizeof(cfg);
  file.close();
  return ok;
}
static void loadControllerPin() {
  pinStorageAvailable = true; // InternalFS is already mounted by loadClockConfig().
  if (!pinStorageAvailable) return;
  Adafruit_LittleFS_Namespace::File file(InternalFS);
  if (!file.open(PIN_FILE, Adafruit_LittleFS_Namespace::FILE_O_READ)) return;
  StoredPin cfg = {};
  bool ok = file.size() == sizeof(cfg) && file.read(&cfg, sizeof(cfg)) == sizeof(cfg);
  file.close();
  if (!ok || cfg.magic != PIN_MAGIC || cfg.checksum != pinChecksum(cfg)) return;
  controllerPinSet = true;
  for (int i=0; i<4; ++i) {
    if (cfg.digits[i] < '0' || cfg.digits[i] > '9') { controllerPinSet = false; break; }
    controllerPin[i] = cfg.digits[i];
  }
  controllerPin[4] = '\0';
}
static bool updateControllerPin(const String& value, bool clear) {
  char original[5]; memcpy(original, controllerPin, 5);
  bool originalSet = controllerPinSet;
  if (clear) { controllerPinSet = false; memset(controllerPin, 0, 5); }
  else { if (!validPin(value)) return false; value.toCharArray(controllerPin, 5); controllerPinSet = true; }
  if (!saveControllerPin()) { memcpy(controllerPin, original, 5); controllerPinSet = originalSet; return false; }
  clearAuth();
  return true;
}
static void scheduleDisconnectAll() {
  pendingSecurityDisconnect = true;
  securityDisconnectAt = millis() + 650;
}


//HSV to RGB Setup
EasyColor::HSVRGB HSVConverter;
RTC_DS3231 rtc;
//End HSV to RGB Setup
#define PIN 5
#define SQWV 10
#define LEDCOUNT 1165  // Compiled array capacity; user-selected count must not exceed this.
static uint16_t activeLedCount = LEDCOUNT;
static uint16_t ledsPerMeter = 60;
static uint16_t roomStartLed = 0;
static uint8_t northSegment = 0;
static RoomCorner savedRoomCorners[MAX_ROOM_CORNERS] = {};
static RoomCorner draftRoomCorners[MAX_ROOM_CORNERS] = {};
static uint8_t savedRoomCornerCount = 0;
static uint8_t draftRoomCornerCount = 0;
static bool mapPreviewActive = false;
// BLE callbacks request LED renders; only loop() calls strip.show().
static volatile bool mapPreviewDirty = false;
static volatile bool outputBlackoutPending = false;
static uint32_t lastMapFrameMs = 0;

static bool mapMeasureActive = false; // illuminates only one measured physical LED
static uint16_t clockPath[LEDCOUNT] = {}; // eligible clock LEDs only; short jogs are background
static uint16_t clockPathSize = 0;
static uint16_t clockNorthPhase = 0; // midpoint of the selected north wall in physical traversal
// Four physical-path anchor positions for 12/3/6/9 o'clock respectively.
static uint16_t clockSideStart[4] = {};
static uint16_t clockSideCount[4] = {};
// Declared before BLE callbacks; they must not appear after their first use.
static bool meteorActive = false;
static uint8_t meteorExplosion = 0;
// Volatile preview perimeter. The actual LED count is not committed until Cfg:Set.
static uint16_t mapPreviewLedCount = LEDCOUNT;
static bool mapTestColors = false;
static uint16_t mapHoldOwner = BLE_CONN_HANDLE_INVALID;
static int8_t mapHeldWall = -1; // Read-only preview, never persisted
static bool roomDraftInProgress = false;
static uint16_t draftRoomStartLed = 0;
static int32_t mapPendingLed = -1;

#define SERIAL_SIZE 32
#define MAX_BUFFER_SIZE 256

//LED Status + Modes Variables
int ledMode = 1;
int specialMode = 0;
bool cConnected = false;
uint16_t buffStripBright = 255;
uint16_t stripBright = 255;
uint16_t prevStripBright = 255;

struct LEDMode {
  String name;
  int numParams;
  String paramNames[7];
  // Instead of storing the string value, store the individual RGB components
  unsigned int paramValuesR[7];  // Red values
  unsigned int paramValuesG[7];  // Green values
  unsigned int paramValuesB[7];  // Blue values
  String paramValuesOther[7];    // Store other parameter types as strings
};

// Array of LED Modes
LEDMode ledModes[] = {
  { "Color", 1, { "Color" }, { 255 }, { 0 }, { 0 }, { "" } },  // Red
  { "Rainbow", 1, { "Speed" }, { 0 }, { 0 }, { 0 }, { "20" } },
  { "Alternating colors", 3, { "Color", "SColor", "Speed" }, { 0, 0, 0 }, { 0, 255, 0 }, { 255, 0, 0 }, { "", "", "20" } },  // Blue, Green
  { "Fade", 1, { "Speed" }, { 0 }, { 0 }, { 0 }, { "40" } },
  { "Pulse", 3, { "Color", "SColor", "Speed" }, { 0, 0, 0 }, { 0, 255, 0 }, { 255, 0, 0 }, { "", "", "20" } },  // Blue, Green
  { "Breathe", 2, { "Color", "Speed" }, { 255 }, { 0 }, { 0 }, { "", "20" } },                                  // Red
  { "Paint", 1, { "Speed" }, { 0 }, { 0 }, { 0 }, { "20" } },
  { "Strobe", 2, { "Color", "Speed" }, { 255 }, { 0 }, { 0 }, { "", "30" } },                                   // Red
  { "Time", 1, { "Color" }, { 255 }, { 0 }, { 0 }, { "" } },                                                    // Red
  { "Cylon", 4, { "Color", "SColor", "Speed", "Length" }, { 255, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 }, { "", "", "40", "20" } },
  { "Phaser", 4, { "Color", "Speed", "Length", "Pattern" }, { 255 }, { 0 }, { 0 }, { "", "70", "22", "0" } },
  { "Alternating Phaser", 6, { "Color", "SColor", "Speed", "Length", "Spawn", "Collision" }, { 255, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 }, { "", "", "70", "20", "1", "1" } },
  { "Weather", 0, {}, {}, {}, {}, {} }, // Weather palette comes from current conditions and daylight
  { "Police Lights", 1, { "Speed" }, { 0 }, { 0 }, { 0 }, { "20" } },
  { "Fire", 1, { "Speed" }, { 0 }, { 0 }, { 0 }, { "20" } },
  { "Twinkle", 3, { "Color", "Spawn", "Decay" }, { 255 }, { 0 }, { 0 }, { "", "35", "55" } },
  { "Sparkle", 3, { "Color", "Spawn", "Decay" }, { 255 }, { 0 }, { 0 }, { "", "45", "60" } },
  { "Running Lights", 3, { "Color", "Speed", "Division" }, { 255 }, { 0 }, { 0 }, { "", "10", "20" } },  // Red
  { "Theatre Chase", 2, { "Color", "Speed" }, { 255 }, { 0 }, { 0 }, { "", "10" } },                     // Red
  { "Meteor", 1, { "Speed" }, { 0 }, { 0 }, { 0 }, { "45" } },
  { "Pop", 4, { "Color", "Spawn", "Speed", "Size" }, { 255 }, { 0 }, { 0 }, { "", "40", "60", "35" } },
  { "Audio reactive", 3, { "Color", "Sensitivity", "Reaction" }, { 0 }, { 180 }, { 255 }, { "", "50", "1" } },
  { "Gravity Fill", 4, { "Pattern", "Direction", "Speed", "Bounce" }, {}, {}, {}, { "0", "0", "55", "1" } },
  { "Gravity Wipe", 6, { "Pattern", "Direction", "Speed", "Color", "Palette", "Fade" },
      { 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 120, 0, 0 }, { 0, 0, 0, 255, 0, 0 }, { "2", "0", "55", "", "1", "25" } },
  { "Ripple", 3, { "Color", "Frequency", "Speed" }, { 0, 0, 0 }, { 170, 0, 0 }, { 255, 0, 0 }, { "", "45", "55" } },
  // Reaction 0 = spectrum fill, 1 = whole-room amplitude, 2 = transient color pulse.
};

int numModes = sizeof(ledModes) / sizeof(ledModes[0]);  // Get the number of LED modes

static bool effectResetPending = true;
bool ledState = true;
bool timeoutlight = false;
bool hasSet = false;
int ddColor1 = 0;
int ddColor2 = 0;
int ch = 69;
int cs = 70;
int cv = 71;
float cr = 255;
float cg = 255;
float cb = 255;
int fh = 0;
float fr = 255;
float fg = 255;
float fb = 255;
String val;
//End LED Status + Modes Variables

//Parsing Serial Data Variables
const byte serialsize = 32;
char input[SERIAL_SIZE];
char tempInput[SERIAL_SIZE];
char intxt_1[SERIAL_SIZE] = { 0 };
int inNum_0 = 0;
float inNum_1 = 0.0;
float inNum_2 = 0.0;
float inNum_3 = 0.0;
bool newData = false;
int second = 0;
int minute = 18;
int hour = 3;
int dayOfWeek = 2;
int dayOfMonth = 1;
int month = 5;
int year = 23;
String currentModeName = "";
String previousModeName = "";
//End Parsing Serial Data Variables

//Global Animation Variables
static const uint16_t originalMinuteMap[60] = { 707, 724, 741, 757, 774, 791, 807, 823, 840, 856, 872, 888, 905, 921, 938, 954, 972, 990, 1008, 1026, 1044, 1063, 1081, 8, 26, 45, 63, 81, 98, 116, 134, 156, 178, 199, 221, 243, 265, 286, 308, 329, 351, 373, 394, 416, 437, 459, 476, 492, 509, 525, 542, 558, 575, 591, 608, 624, 641, 657, 674, 690 };
static const uint16_t originalHourMap[12] = { 707, 791, 872, 954, 1044, 45, 134, 243, 351, 459, 542, 624 };
int minuteMap[60] = { 707, 724, 741, 757, 774, 791, 807, 823, 840, 856, 872, 888, 905, 921, 938, 954, 972, 990, 1008, 1026, 1044, 1063, 1081, 8, 26, 45, 63, 81, 98, 116, 134, 156, 178, 199, 221, 243, 265, 286, 308, 329, 351, 373, 394, 416, 437, 459, 476, 492, 509, 525, 542, 558, 575, 591, 608, 624, 641, 657, 674, 690 };
int hourMap[12] = { 707, 791, 872, 954, 1044, 45, 134, 243, 351, 459, 542, 624 };
int beamSize = LEDCOUNT / 20;
bool ledON = false;
int ledNum = 0;
int beamPos[LEDCOUNT];
unsigned long cMillis = 0;
unsigned long pMillis = 0;
unsigned long rMillis = 0;
unsigned long sMillis = 0;
unsigned long tMillis = 0;
int DST = 0;  // Manual hour offset, 1 when daylight-saving time is active
int pSecond = 0;
bool aOn = false;
bool goingUp = true;
uint16_t brightness = 254;
uint16_t prevBrightness = 1;
int handBright = 0;
int mHandBright = 0;
int backBright = 0;
int aStep = 0;
bool strobeOn = false;
bool altState = false;
int ledDiv = 15;
bool color = false;
int modeSpeed = 60;
float rStates[LEDCOUNT];
float bStates[LEDCOUNT];
float gStates[LEDCOUNT];
float pulseBar1[8];  // Direction, Size, r, g, b
float pulseBar2[8];
float pulseBar3[8];
float pulseBar4[8];
float pulseBar5[8];
float popHang[LEDCOUNT];
float setPopHang[LEDCOUNT];
uint16_t nextrgb[] = { 255, 0, 0 };
float color1[] = { 255, 255, 255 };
float color2[] = { 0, 255, 0 };
int pixChosen = 0;
int pColorOption = 0;
int ledStatus[LEDCOUNT];
// Legacy animation modes sometimes step one pixel beyond a strip boundary.
// Bounds-checked reads and writes protect RAM when the configured count changes.
static inline int ledFlag(int index) {
  return index >= 0 && index < activeLedCount ? ledStatus[index] : 0;
}
static inline void setLedFlag(int index, int value) {
  if (index >= 0 && index < activeLedCount) ledStatus[index] = value;
}

bool barDirection = false;
const int barSize = 30;
int setBarSize = 0;
int phaserNum = 0;
bool inRamp = false;
int rampStep = 0;
int aMBright = 255;
volatile long count = 0;
long pMinute = 0;
int sBarPos = hourMap[0];
char storedRequestType[24];
char storedRequestName[24];
static uint32_t lastEffectFrameMs = 0;
static uint16_t gravityFilled[MAX_ROOM_CORNERS] = {};
static uint16_t gravityTravel[MAX_ROOM_CORNERS] = {};
static uint8_t gravityHue = 0;
static bool gravityInit = false;
static uint16_t cylonHead = 0;
static bool cylonReturning = false;
static uint8_t tabletWeatherCode = 0;
static bool weatherCodeReceived = false;
static uint16_t tabletWindKmh = 0;
static bool tabletWeatherDay = true;
static bool weatherDayReceived = false;
volatile uint8_t tabletAudioLevel = 0;
unsigned long lastAudioPacketMs = 0;
unsigned long lastAudioFrameMs = 0;

#define CUSTOM_SERVICE_UUID "12345678-1234-5678-1234-56789abcdef0"
#define LED_MODE_LIST_UUID "12345678-1234-5678-1234-56789abcdef1"
#define PARAMETER_REQUEST_UUID "12345678-1234-5678-1234-56789abcdef2"
#define PARAMETER_RESPONSE_UUID "12345678-1234-5678-1234-56789abcdef3"
#define PARAMETER_CONTROL_UUID "12345678-1234-5678-1234-56789abcdef4"

#define BLE_CCCD_NOTIFY_VALUE 0x0001
#define BLE_CCCD_INDICATE_VALUE 0x0002

// #define PAIRING_PIN     "123456"

// Parameter 1 = number of pixels in strip
// Parameter 2 = Arduino pin number (most are valid)
// Parameter 3 = pixel type flags, add together as needed:
//   NEO_KHZ800  800 KHz bitstream (most NeoPixel products w/WS2812 LEDs)
//   NEO_KHZ400  400 KHz (classic 'v1' (not v2) FLORA pixels, WS2811 drivers)
//   NEO_GRB     Pixels are wired for GRB bitstream (most NeoPixel products)
//   NEO_RGB     Pixels are wired for RGB bitstream (v1 FLORA pixels, not v2)
//   NEO_RGBW    Pixels are wired for RGBW bitstream (NeoPixel RGBW products)
Adafruit_NeoPixel strip = Adafruit_NeoPixel(LEDCOUNT, PIN, NEO_GRB + NEO_KHZ800);

// Optional per-range brightness and color calibration. Stored separately from
// the controller's established room/clock configuration for backward compatibility.
static const uint32_t CAL_MAGIC = 0x4C434139UL; // LCA9
static const char* CAL_FILE = "/ledcal9.bin";
static StoredLedCorrections calibration = {};
static bool calibrationStorageOK = false;
static uint8_t uncorrectedFrame[LEDCOUNT * 3]; // GRB data restored after each output
static bool calibrationPreview = false;
static uint16_t calibrationPreviewStart = 0, calibrationPreviewEnd = 0;
static uint8_t calibrationSampleR = 10, calibrationSampleG = 10, calibrationSampleB = 10;
// Guided calibration: these are RAM-only previews and do not alter flash profiles.
static bool calibrationJog = false;
static uint16_t calibrationJogStart = LEDCOUNT, calibrationJogEnd = LEDCOUNT, calibrationJogCursor = 0;
static bool calibrationCompare = false;
static bool calibrationCompareAfter = false;
static LedCorrectionRange calibrationCandidate = {};

static uint8_t sunriseLevel = 255; // 255 means no scheduled clear-morning sunrise
static uint32_t sunrisePacketMs = 0;

static uint32_t calibrationChecksum(const StoredLedCorrections& cfg) {
  uint32_t h = 2166136261UL;
  const uint8_t* bytes = reinterpret_cast<const uint8_t*>(&cfg);
  for (size_t i=0; i<offsetof(StoredLedCorrections, checksum); ++i)
    h = (h ^ bytes[i]) * 16777619UL;
  return h;
}
static bool validCalibrationRange(const LedCorrectionRange& r) {
  return r.start <= r.end && r.end < activeLedCount &&
    r.brightnessPercent >= 50 && r.brightnessPercent <= 150 && r.lowLift <= 16 &&
    r.redPercent >= 50 && r.redPercent <= 150 &&
    r.greenPercent >= 50 && r.greenPercent <= 150 &&
    r.bluePercent >= 50 && r.bluePercent <= 150;
}
static bool saveCalibration() {
  if (!calibrationStorageOK) return false;
  calibration.magic = CAL_MAGIC; calibration.version = 1;
  calibration.checksum = calibrationChecksum(calibration);
  Adafruit_LittleFS_Namespace::File file(InternalFS);
  if (!file.open(CAL_FILE, Adafruit_LittleFS_Namespace::FILE_O_WRITE)) return false;
  bool ok = file.seek(0) && file.truncate(0);
  if (ok) ok = file.write((const uint8_t*)&calibration, sizeof(calibration)) == sizeof(calibration);
  file.close();
  return ok;
}
static void loadCalibration() {
  calibration = {};
  calibrationStorageOK = true;
  if (!calibrationStorageOK) return;
  Adafruit_LittleFS_Namespace::File file(InternalFS);
  if (!file.open(CAL_FILE, Adafruit_LittleFS_Namespace::FILE_O_READ)) return;
  StoredLedCorrections loaded = {};
  bool ok = file.size() == sizeof(loaded) && file.read(&loaded, sizeof(loaded)) == sizeof(loaded);
  file.close();
  if (!ok || loaded.magic != CAL_MAGIC || loaded.version != 1 ||
      loaded.count > MAX_LED_CORRECTIONS || loaded.checksum != calibrationChecksum(loaded)) return;
  for (uint8_t i=0; i<loaded.count; ++i) {
    if (!validCalibrationRange(loaded.ranges[i])) return;
    for (uint8_t j=0; j<i; ++j)
      if (loaded.ranges[i].start <= loaded.ranges[j].end &&
          loaded.ranges[j].start <= loaded.ranges[i].end) return;
  }
  calibration = loaded;
}
// Centralized output correction: black remains black; decoded pixels are
// restored in memory so effects still see their original, linear colors.
// This assumes the NeoPixel show() call has completed its GRB-buffer transfer.
static inline uint8_t corrected(uint8_t v, uint8_t overall, uint8_t channel, uint8_t lift) {
  if (v == 0) return 0;
  uint32_t scaled = ((uint32_t)v * overall * channel + 5000UL) / 10000UL + lift;
  return (uint8_t)(scaled > 255 ? 255 : scaled);
}
static void calibratedShow() {
  if (calibration.count == 0 && !(calibrationCompare && calibrationPreview)) { strip.show(); return; }
  uint8_t* pixels = strip.getPixels();
  if (!pixels) { strip.show(); return; }
  const size_t bytes = (size_t)activeLedCount * 3U;
  memcpy(uncorrectedFrame, pixels, bytes);
  for (uint8_t i=0; i<calibration.count; ++i) {
    const LedCorrectionRange& r = calibration.ranges[i];
    if (!validCalibrationRange(r)) continue;
    // Low-level lift tapers to zero by ~25% global brightness.
    // During a guided comparison the chosen sample intensity, not the previous
    // lighting mode's brightness, controls the low-level lift curve.
    const uint8_t brightnessLevel = calibrationCompare && calibrationPreview ?
      (uint16_t)max(calibrationSampleR, max(calibrationSampleG, calibrationSampleB)) * 100U / 255U :
      (uint32_t)stripBright * 100U / 255U;
    const uint8_t effectiveLift = brightnessLevel >= 25 ? 0 :
      (uint16_t)r.lowLift * (25 - brightnessLevel) / 25;
    for (uint16_t led=r.start; led<=r.end; ++led) {
      // Replace only the selected range with a temporary candidate correction
      // during Before/After. Other saved ranges remain representative.
      if (calibrationCompare && calibrationPreview &&
          led >= calibrationCandidate.start && led <= calibrationCandidate.end) continue;
      const uint16_t offset = led*3U; // NeoPixel configured NEO_GRB
      pixels[offset] = corrected(pixels[offset], r.brightnessPercent, r.greenPercent, effectiveLift);
      pixels[offset+1] = corrected(pixels[offset+1], r.brightnessPercent, r.redPercent, effectiveLift);
      pixels[offset+2] = corrected(pixels[offset+2], r.brightnessPercent, r.bluePercent, effectiveLift);
    }
  }
  if (calibrationCompare && calibrationPreview && calibrationCompareAfter) {
    const LedCorrectionRange& r = calibrationCandidate;
    // During a guided comparison the chosen sample intensity, not the previous
    // lighting mode's brightness, controls the low-level lift curve.
    const uint8_t brightnessLevel = calibrationCompare && calibrationPreview ?
      (uint16_t)max(calibrationSampleR, max(calibrationSampleG, calibrationSampleB)) * 100U / 255U :
      (uint32_t)stripBright * 100U / 255U;
    const uint8_t effectiveLift = brightnessLevel >= 25 ? 0 :
      (uint16_t)r.lowLift * (25 - brightnessLevel) / 25;
    for (uint16_t led = r.start; led <= r.end; ++led) {
      const uint16_t offset = led * 3U;
      pixels[offset]   = corrected(pixels[offset], r.brightnessPercent, r.greenPercent, effectiveLift);
      pixels[offset+1] = corrected(pixels[offset+1], r.brightnessPercent, r.redPercent, effectiveLift);
      pixels[offset+2] = corrected(pixels[offset+2], r.brightnessPercent, r.bluePercent, effectiveLift);
    }
  }
  strip.show();
  memcpy(pixels, uncorrectedFrame, bytes);
}


// IMPORTANT: To reduce NeoPixel burnout risk, add 1000 uF capacitor across
// pixel power leads, add 300 - 500 Ohm resistor on first pixel's data input
// and minimize distance between Arduino and first pixel.  Avoid connecting
// on a live circuit...if you must, connect GND first.

BLEDfu bledfu;  // OTA DFU service
BLEDis bledis;  // device information
// BLEUart bleuart;  // uart over BLE

BLEService customService(CUSTOM_SERVICE_UUID);
BLECharacteristic ledModesCharacteristic(LED_MODE_LIST_UUID, BLERead, 512);
BLECharacteristic parameterRequestCharacteristic(PARAMETER_REQUEST_UUID, BLEWriteWithoutResponse, 128);
BLECharacteristic parameterResponseCharacteristic(PARAMETER_RESPONSE_UUID, BLERead | BLEWriteWithoutResponse | BLENotify, 256);
BLECharacteristic parameterControlCharacteristic(PARAMETER_CONTROL_UUID, BLEWriteWithoutResponse, 256);

uint16_t connHandle;

// Define a structure to store key-value pairs
struct KeyValue {
  String key;
  String value;
};

// Set a max size for your key-value storage
#define MAX_PARAMETERS 10
KeyValue parameters[MAX_PARAMETERS];
int paramCount = 0;

void cResync();
void sendLEDModeList();

// Revision 1: tablet-programmable clock walls and DST.
// The DS3231 is kept in *standard local time*. DST adds an hour only for display.
// Wall n covers minutes 15*n .. 15*n+14, in clockwise clock order.
static const uint32_t CLOCK_CFG_MAGIC = 0x4c454431UL; // LED1
static const char* CLOCK_CFG_FILE = "/ledclock.bin";
static ClockWall stagedWalls[4] = {};
static ClockWall appliedWalls[4] = {};  // Persist only validated, committed wall settings.
static uint8_t stagedWallMask = 0;
static bool customWallMapEnabled = false;
static bool clockStorageAvailable = false;

static uint32_t clockConfigChecksum(const StoredClockConfig& cfg) {
  const uint8_t* bytes = reinterpret_cast<const uint8_t*>(&cfg);
  uint32_t value = 2166136261UL;
  for (size_t i = 0; i < offsetof(StoredClockConfig, checksum); ++i) {
    value = (value ^ bytes[i]) * 16777619UL;
  }
  return value;
}

static bool isValidClockWall(const ClockWall& w) {
  return w.count >= 15 && w.start < LEDCOUNT &&
         (uint32_t)w.start + w.count <= LEDCOUNT && w.reverse <= 1;
}

static bool validateClockWalls(const ClockWall walls[4]) {
  for (int i = 0; i < 4; i++) {
    if (!isValidClockWall(walls[i])) return false;
    for (int j = 0; j < i; j++) {
      uint32_t a0 = walls[i].start, a1 = a0 + walls[i].count;
      uint32_t b0 = walls[j].start, b1 = b0 + walls[j].count;
      if (a0 < b1 && b0 < a1) return false; // no physical overlaps
    }
  }
  return true;
}

static void resetClockMap() {
  for (int i = 0; i < 60; i++) minuteMap[i] = originalMinuteMap[i];
  for (int i = 0; i < 12; i++) hourMap[i] = originalHourMap[i];
  customWallMapEnabled = false;
  stagedWallMask = 0;
  memset(stagedWalls, 0, sizeof(stagedWalls));
  memset(appliedWalls, 0, sizeof(appliedWalls));
  sBarPos = hourMap[0];
}

static void applyClockWalls(const ClockWall walls[4]) {
  for (int wall = 0; wall < 4; wall++) {
    for (int slot = 0; slot < 15; slot++) {
      const int displacement = ((uint32_t)slot * walls[wall].count) / 15;
      minuteMap[wall * 15 + slot] = walls[wall].reverse
          ? walls[wall].start + walls[wall].count - 1 - displacement
          : walls[wall].start + displacement;
    }
  }
  for (int i = 0; i < 12; i++) hourMap[i] = minuteMap[i * 5];
  memcpy(stagedWalls, walls, sizeof(stagedWalls));
  memcpy(appliedWalls, walls, sizeof(appliedWalls));
  stagedWallMask = 0x0F;
  customWallMapEnabled = true;
  sBarPos = hourMap[0];
}

static bool saveClockConfig() {
  if (!clockStorageAvailable) return false;
  StoredClockConfig cfg = {};
  cfg.magic = CLOCK_CFG_MAGIC;
  cfg.version = 1;
  cfg.dst = (uint8_t)DST;
  cfg.wallEnabled = customWallMapEnabled ? 1 : 0;
  memcpy(cfg.walls, appliedWalls, sizeof(appliedWalls)); // Do not persist uncommitted edits.
  cfg.checksum = clockConfigChecksum(cfg);
  Adafruit_LittleFS_Namespace::File file(InternalFS);
  if (!file.open(CLOCK_CFG_FILE, Adafruit_LittleFS_Namespace::FILE_O_WRITE)) return false;
  bool ok = file.seek(0) && file.truncate(0);
  if (ok) ok = file.write((const uint8_t*)&cfg, sizeof(cfg)) == sizeof(cfg);
  file.close();
  return ok;
}

static void loadClockConfig() {
  clockStorageAvailable = InternalFS.begin();
  if (!clockStorageAvailable) {
    Serial.println("Clock config storage unavailable; settings will not persist");
    return;
  }
  Adafruit_LittleFS_Namespace::File file(InternalFS);
  if (!file.open(CLOCK_CFG_FILE, Adafruit_LittleFS_Namespace::FILE_O_READ)) return;
  StoredClockConfig cfg = {};
  const bool readOk = file.size() == sizeof(cfg) &&
                      file.read(&cfg, sizeof(cfg)) == sizeof(cfg);
  file.close();
  if (!readOk || cfg.magic != CLOCK_CFG_MAGIC || cfg.version != 1 ||
      cfg.dst > 1 || cfg.wallEnabled > 1 ||
      cfg.checksum != clockConfigChecksum(cfg)) {
    Serial.println("Invalid stored clock settings; using defaults");
    return;
  }
  DST = cfg.dst;
  if (cfg.wallEnabled && validateClockWalls(cfg.walls)) applyClockWalls(cfg.walls);
}

static bool parseDecimal(const String& s, int& out) {
  if (s.length() < 1 || s.length() > 5) return false;
  for (unsigned int i = 0; i < s.length(); i++) {
    if (s[i] < '0' || s[i] > '9') return false;
  }
  out = s.toInt();
  return true;
}

static bool parseClockWall(const String& s, ClockWall& wall) {
  const int first = s.indexOf(',');
  const int second = s.indexOf(',', first + 1);
  if (first < 1 || second < first + 2 || s.indexOf(',', second + 1) >= 0) return false;
  int start, count, reverse;
  if (!parseDecimal(s.substring(0, first), start) ||
      !parseDecimal(s.substring(first + 1, second), count) ||
      !parseDecimal(s.substring(second + 1), reverse)) return false;
  wall.start = start;
  wall.count = count;
  wall.reverse = reverse;
  wall.reserved = 0;
  return isValidClockWall(wall);
}

static bool parseClockDateTime(const String& s, DateTime& parsed) {
  // ISO 8601 local STANDARD time, no timezone suffix or DST adjustment.
  if (s.length() != 19 || s[4] != '-' || s[7] != '-' || s[10] != 'T' ||
      s[13] != ':' || s[16] != ':') return false;
  for (int i = 0; i < 19; i++) {
    if (i == 4 || i == 7 || i == 10 || i == 13 || i == 16) continue;
    if (s[i] < '0' || s[i] > '9') return false;
  }
  const int year = s.substring(0, 4).toInt();
  const int month = s.substring(5, 7).toInt();
  const int day = s.substring(8, 10).toInt();
  const int hour = s.substring(11, 13).toInt();
  const int minute = s.substring(14, 16).toInt();
  const int second = s.substring(17, 19).toInt();
  if (year < 2000 || year > 2099 || month < 1 || month > 12 ||
      hour > 23 || minute > 59 || second > 59 || day < 1) return false;
  static const uint8_t daysInMonth[] = {31,28,31,30,31,30,31,31,30,31,30,31};
  int maxDay = daysInMonth[month - 1];
  if (month == 2 && ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)) maxDay++;
  if (day > maxDay) return false;
  parsed = DateTime(year, month, day, hour, minute, second);
  return true;
}

static String formatClockDateTime(const DateTime& dt) {
  char buffer[21];
  snprintf(buffer, sizeof(buffer), "%04u-%02u-%02uT%02u:%02u:%02u",
           dt.year(), dt.month(), dt.day(), dt.hour(), dt.minute(), dt.second());
  return String(buffer);
}

static void notifyAll(const String& line) {
  if (line.length() >= 128) return;
  uint16_t connected[MAX_PRPH_CONNECTION] = {};
  const uint8_t count = Bluefruit.getConnectedHandles(connected, MAX_PRPH_CONNECTION);
  for (uint8_t i=0; i<count; ++i) {
    if (parameterResponseCharacteristic.notifyEnabled(connected[i])) {
      parameterResponseCharacteristic.notify(connected[i], line.c_str());
    }
  }
}
static void sendTo(const String& line, uint16_t connection) {
  if (line.length() >= 128) return;
  parameterResponseCharacteristic.write((const uint8_t*)line.c_str(), line.length());
  if (connection != BLE_CONN_HANDLE_INVALID && parameterResponseCharacteristic.notifyEnabled(connection)) {
    parameterResponseCharacteristic.notify(connection, line.c_str());
  }
}
static void protocolReply(const String& type, const String& name, const String& value) {
  sendTo(type + ":" + name + ":{" + value + "}\n", replyConnection);
}
static void broadcastCoreState() {
  const uint16_t percent = (uint32_t)buffStripBright * 100 / 255;
  notifyAll("State:Core:{" + String(stateRevision) + "|" + (ledState ? "1" : "0") + "|" +
       String(percent) + "|" + currentModeName + "}\n");
}
static void broadcastCurrentParams() {
  for (int i=0; i<numModes; ++i) {
    if (ledModes[i].name != currentModeName) continue;
    for (int j=0; j<ledModes[i].numParams; ++j) {
      String value = ledModes[i].paramNames[j] == "Color" || ledModes[i].paramNames[j] == "SColor"
          ? String(ledModes[i].paramValuesR[j]) + "," + String(ledModes[i].paramValuesG[j]) + "," + String(ledModes[i].paramValuesB[j])
          : ledModes[i].paramValuesOther[j];
      notifyAll("State:Param:{" + String(stateRevision) + "|" + currentModeName + "|" + ledModes[i].paramNames[j] + "|" + value + "}\n");
    }
    break;
  }
}
static void announceChangedState(bool config = false) {
  ++stateRevision;
  if (stateRevision == 0) stateRevision = 1;
  // No blocking GATT notifications from write callbacks.
  pendingStateBroadcast = true;
  if (config) pendingConfigBroadcast = true;
}
// Publish at most one characteristic notification per tablet per tick. Slider
// bursts are coalesced to the most recent revision, never queued indefinitely.
static void serviceStateBroadcast() {
  if (!pendingStateBroadcast || connection_count == 0) return;
  const uint32_t nowMs = millis();
  if ((uint32_t)(nowMs - lastStateBroadcastMs) < 80UL) return;
  lastStateBroadcastMs = nowMs;
  if (publishingRevision != stateRevision) {
    publishingRevision = stateRevision;
    publishingStep = 0;
    publishingParameter = 0;
  }
  if (publishingStep == 0) {
    broadcastCoreState();
    publishingStep = 1;
    return;
  }
  if (publishingStep == 1) {
    for (int i = 0; i < numModes; ++i) {
      if (ledModes[i].name != currentModeName) continue;
      if (publishingParameter < ledModes[i].numParams) {
        const int j = publishingParameter++;
        String value = ledModes[i].paramNames[j] == "Color" || ledModes[i].paramNames[j] == "SColor"
            ? String(ledModes[i].paramValuesR[j]) + "," + String(ledModes[i].paramValuesG[j]) + "," + String(ledModes[i].paramValuesB[j])
            : ledModes[i].paramValuesOther[j];
        notifyAll("State:Param:{" + String(publishingRevision) + "|" + currentModeName + "|" +
                  ledModes[i].paramNames[j] + "|" + value + "}\n");
        return;
      }
      break;
    }
    publishingStep = 2;
  }
  if (pendingConfigBroadcast) {
    notifyAll("State:Config:{" + String(publishingRevision) + "}\n");
    pendingConfigBroadcast = false;
  }
  if (publishingRevision == stateRevision) pendingStateBroadcast = false;
  publishingStep = 0;
}
static void sendStateRequest(const String& name) {
  if (name == "Core") {
    protocolReply("State", name, String(stateRevision) + "|" + (ledState ? "1" : "0") + "|" +
        String((uint32_t)buffStripBright * 100 / 255) + "|" + currentModeName);
  } else if (name == "Params") {
    for (int i=0; i<numModes; ++i) if (ledModes[i].name == currentModeName) {
      String value = String(stateRevision) + "|" + currentModeName;
      for (int j=0; j<ledModes[i].numParams; ++j) {
        value += "|" + ledModes[i].paramNames[j] + "=";
        if (ledModes[i].paramNames[j] == "Color" || ledModes[i].paramNames[j] == "SColor") {
          value += String(ledModes[i].paramValuesR[j]) + "," + String(ledModes[i].paramValuesG[j]) + "," + String(ledModes[i].paramValuesB[j]);
        } else value += ledModes[i].paramValuesOther[j];
      }
      protocolReply("State", name, value);
      return;
    }
    protocolReply("State", name, String(stateRevision) + "|" + currentModeName);
  } else if (name == "Diag") {
    // Readable with an existing State:Diag:{?} request. Useful when diagnosing
    // controllers that appear connected but have stopped processing commands.
    protocolReply("State", name, String(millis() / 1000UL) + "," +
        String(loopTickCounter) + "," + String(maxObservedLoopGapMs) + "," +
        String(totalBleCommandCount) + "," +
        String(connection_count) + "," + String(mapPreviewActive ? 1 : 0));
  } else if (name == "Proto") protocolReply("State", name, "1");
  else if (name == "Version") protocolReply("State", name, "5");
  else protocolReply("State", name, "ERR_INPUT");
}
static void endRoomPreview(); // Used by the protected factory-reset handler.
static bool factoryResetSetup(); // Defined after room config storage helpers.
static void handleSecurityControl(uint16_t conn_hdl, const String& name, const String& value) {
  if (name == "Init" && !controllerPinSet) {
    if (!validPin(value)) { protocolReply("Sec", name, "ERR_PIN"); return; }
    if (!updateControllerPin(value, false)) { protocolReply("Sec", name, "ERR_FLASH"); return; }
    const int slot = authSlot(conn_hdl);
    if (slot >= 0) sessionAuthorized[slot] = true;
    protocolReply("Sec", name, "OK");
    scheduleDisconnectAll();
  } else if (name == "Auth") {
    if (!controllerPinSet) { protocolReply("Sec", name, "UNSET"); return; }
    if (lockedOut(conn_hdl)) { protocolReply("Sec", name, "ERR_LOCKED"); return; }
    if (validPin(value) && value.equals(controllerPin)) {
      const int slot = authSlot(conn_hdl);
      if (slot >= 0) { sessionAuthorized[slot] = true; badPinCount[slot] = 0; }
      globalBadPinCount = 0;
      protocolReply("Sec", name, "OK");
    } else { recordPinFailure(conn_hdl); protocolReply("Sec", name, "ERR_PIN"); }
  } else if (name == "Factory") {
    if (lockedOut(conn_hdl)) { protocolReply("Sec", name, "ERR_LOCKED"); return; }
    if (!controllerPinSet || !validPin(value) || !value.equals(controllerPin) || !authorized(conn_hdl)) {
      recordPinFailure(conn_hdl); protocolReply("Sec", name, "ERR_PIN"); return;
    }
    if (!factoryResetSetup()) { protocolReply("Sec", name, "ERR_FLASH"); return; }
    protocolReply("Sec", name, "OK");
    scheduleDisconnectAll();
  } else if (name == "Change" || name == "Reset") {
    const int comma = value.indexOf(',');
    const String oldPin = name == "Change" && comma >= 0 ? value.substring(0, comma) : value;
    const String newPin = name == "Change" && comma >= 0 ? value.substring(comma+1) : "";
    if (lockedOut(conn_hdl)) { protocolReply("Sec", name, "ERR_LOCKED"); return; }
    if (!controllerPinSet || !validPin(oldPin) || !oldPin.equals(controllerPin)) {
      recordPinFailure(conn_hdl); protocolReply("Sec", name, "ERR_PIN"); return;
    }
    if (name == "Change" && !validPin(newPin)) { protocolReply("Sec", name, "ERR_PIN"); return; }
    if (!updateControllerPin(newPin, name == "Reset")) { protocolReply("Sec", name, "ERR_FLASH"); return; }
    protocolReply("Sec", name, "OK");
    scheduleDisconnectAll();
  } else protocolReply("Sec", name, "ERR_INPUT");
}
static void handleSecurityRequest(const String& name) {
  if (name == "Status") protocolReply("Sec", name, controllerPinSet ? "SET" : "UNSET");
  else protocolReply("Sec", name, "ERR_INPUT");
}

static void handleClockControl(const String& type, const String& name, const String& value) {
  if (type == "RTC") {
    if (name == "Time") {
      DateTime target(2000, 1, 1);
      if (parseClockDateTime(value, target)) {
        rtc.adjust(target);
        cResync();
        protocolReply(type, name, "OK"); announceChangedState(true);
      } else protocolReply(type, name, "ERR_DATE");
    } else if (name == "DST" && (value == "0" || value == "1")) {
      DST = value.toInt();
      protocolReply(type, name, saveClockConfig() ? "OK" : "OK_VOLATILE"); announceChangedState(true);
    } else protocolReply(type, name, "ERR_INPUT");
  } else if (type == "Wall") {
    if (name.length() == 1 && name[0] >= '0' && name[0] <= '3') {
      const int index = name[0] - '0';
      ClockWall wall = {};
      if (!parseClockWall(value, wall)) {
        protocolReply(type, name, "ERR_WALL");
      } else {
        stagedWalls[index] = wall;
        stagedWallMask |= 1 << index;
        protocolReply(type, name, "OK");
      }
    } else if (name == "Apply" && value == "1") {
      if (stagedWallMask == 0x0F && validateClockWalls(stagedWalls)) {
        applyClockWalls(stagedWalls);
        protocolReply(type, name, saveClockConfig() ? "OK" : "OK_VOLATILE"); announceChangedState(true);
      } else protocolReply(type, name, "ERR_LAYOUT");
    } else if (name == "Reset" && value == "1") {
      resetClockMap();
      protocolReply(type, name, saveClockConfig() ? "OK" : "OK_VOLATILE"); announceChangedState(true);
    } else protocolReply(type, name, "ERR_INPUT");
  }
}

static void handleClockRequest(const String& type, const String& name) {
  if (type == "RTC") {
    if (name == "Time") protocolReply(type, name, formatClockDateTime(rtc.now()));
    else if (name == "Now") {
      const DateTime now = rtc.now();
      protocolReply(type, name, formatClockDateTime(DateTime(now.unixtime() + DST * 3600UL)));
    } else if (name == "DST") protocolReply(type, name, String(DST));
    else protocolReply(type, name, "ERR_INPUT");
  } else if (type == "Wall") {
    if (name == "State") protocolReply(type, name, customWallMapEnabled ? "1" : "0");
    else if (name.length() == 1 && name[0] >= '0' && name[0] <= '3') {
      const int index = name[0] - '0';
      if (stagedWallMask & (1 << index)) {
        ClockWall& wall = stagedWalls[index];
        protocolReply(type, name, String(wall.start) + "," + String(wall.count) + "," + String(wall.reverse));
      } else protocolReply(type, name, "UNSET");
    } else protocolReply(type, name, "ERR_INPUT");
  }
}



// Room layout is a *separate* v2 flash record. Legacy RTC/DST and four-wall settings
// remain in their original file for compatibility with existing controllers.
static const uint32_t ROOM_MAGIC = 0x4c524d32UL;  // LRM2
static const char* ROOM_FILE = "/ledroom2.bin";
static bool roomStorageAvailable = false;
static uint32_t roomChecksum(const StoredRoomConfig& cfg) {
  const uint8_t* data = reinterpret_cast<const uint8_t*>(&cfg);
  uint32_t result = 2166136261UL;
  for (size_t i = 0; i < offsetof(StoredRoomConfig, checksum); ++i)
    result = (result ^ data[i]) * 16777619UL;
  return result;
}
static uint16_t clockwiseDistance(uint16_t a, uint16_t b) {
  return b >= a ? b - a : activeLedCount - a + b;
}
static bool validRoom(const RoomCorner* corners, uint8_t count, uint16_t total) {
  if (count < 4 || count > MAX_ROOM_CORNERS || total < 4) return false;
  if (corners[0].led >= total) return false;
  uint16_t lastProgress = 0;
  for (uint8_t i = 0; i < count; i++) {
    if (corners[i].led >= total || corners[i].inside > 1) return false;
    const uint16_t progress = corners[i].led >= corners[0].led
        ? corners[i].led - corners[0].led : total - corners[0].led + corners[i].led;
    if (i && progress <= lastProgress) return false;
    lastProgress = progress;
  }
  return true;
}
static void rebuildDefaultClockForCount() {
  // Original hand-tuned clock is only calibrated for its original 1165 pixels.
  // On a changed strip length with no new room wizard map, distribute ticks evenly.
  if (activeLedCount == LEDCOUNT) return;
  for (uint8_t tick = 0; tick < 60; tick++)
    minuteMap[tick] = ((uint32_t)tick * activeLedCount) / 60;
  for (uint8_t h = 0; h < 12; h++) hourMap[h] = minuteMap[h * 5];
  customWallMapEnabled = true;
  sBarPos = hourMap[0];
}
// Convert fractional clock minutes into actual LED-path positions. Each quarter
// interpolates between the CENTERS of N/E/S/W. Unequal wall lengths are not
// mistakenly treated as equal quarters of the LED perimeter.
static uint16_t clockPathIndex(double minuteValue) {
  if (!clockPathSize) return 0;
  double minute = minuteValue;
  while (minute < 0.0) minute += 60.0;
  while (minute >= 60.0) minute -= 60.0;
  const uint8_t quadrant = (uint8_t)(minute / 15.0);
  const double fraction = (minute - (double)quadrant * 15.0) / 15.0;
  const uint16_t from = clockSideStart[quadrant];
  const uint16_t to = clockSideStart[(quadrant + 1) & 3];
  const uint16_t distance = (to + clockPathSize - from) % clockPathSize;
  return (from + (uint16_t)(fraction * distance)) % clockPathSize;
}

static void rebuildRoomClock() {
  clockPathSize = 0;
  clockNorthPhase = 0;
  memset(clockSideStart, 0, sizeof(clockSideStart));
  memset(clockSideCount, 0, sizeof(clockSideCount));
  if (savedRoomCornerCount < 4) { rebuildDefaultClockForCount(); return; }

  uint16_t wallLength[MAX_ROOM_CORNERS] = {};
  uint8_t heading[MAX_ROOM_CORNERS] = {}; // Wiring order directions: E, S, W, N.
  uint16_t longest = 0;
  for (uint8_t i = 0; i < savedRoomCornerCount; ++i) {
    wallLength[i] = clockwiseDistance(savedRoomCorners[i].led,
        savedRoomCorners[(i + 1) % savedRoomCornerCount].led);
    if (wallLength[i] > longest) longest = wallLength[i];
    if (i) heading[i] = (heading[i-1] + (savedRoomCorners[i].inside ? 3 : 1)) & 3;
  }
  const uint8_t north = northSegment % savedRoomCornerCount;
  const uint16_t threshold = max((uint16_t)2, (uint16_t)(longest / 7));
  const uint8_t northHeading = heading[north];
  // Discover winding from the first significant perpendicular wall after north.
  // This keeps logical time in PHYSICAL LED order for either wiring direction.
  bool clockwise = true;
  for (uint8_t k = 1; k < savedRoomCornerCount; ++k) {
    const uint8_t i = (north + k) % savedRoomCornerCount;
    if (wallLength[i] < threshold) continue;
    const uint8_t turn = (heading[i] + 4 - northHeading) & 3;
    if (turn == 1 || turn == 3) { clockwise = turn == 1; break; }
  }

  uint16_t firstSide[4] = {0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF};
  uint16_t firstNorthCount = 0, lastNorthCount = 0;
  bool seenOtherSide = false, validSideSequence = true;
  uint8_t phase = 0;
  // Iterate physically in wiring order; eliminated jogs remain background LEDs.
  // The chosen north wall always stays in the clock path, even when short.
  for (uint8_t k = 0; k < savedRoomCornerCount; ++k) {
    const uint8_t i = (north + k) % savedRoomCornerCount;
    if (i != north && wallLength[i] < threshold) continue;
    const uint8_t diff = (heading[i] + 4 - northHeading) & 3;
    const uint8_t side = clockwise ? diff : ((4 - diff) & 3);
    if (side == 0) {
      if (phase == 0) firstNorthCount += wallLength[i];
      else if (phase >= 3) { phase = 4; lastNorthCount += wallLength[i]; }
      else validSideSequence = false;
    } else {
      seenOtherSide = true;
      if (phase == 4 || side < phase || side > phase + 1) validSideSequence = false;
      else phase = side;
    }
    if (firstSide[side] == 0xFFFF) firstSide[side] = clockPathSize;
    clockSideCount[side] += wallLength[i];
    const uint16_t start = savedRoomCorners[i].led;
    for (uint16_t n = 0; n < wallLength[i] && clockPathSize < LEDCOUNT; ++n)
      clockPath[clockPathSize++] = (start + n) % activeLedCount;
  }

  if (clockPathSize < 4) {
    const uint16_t center = (savedRoomCorners[north].led + wallLength[north] / 2) % activeLedCount;
    for (uint8_t tick = 0; tick < 60; ++tick)
      minuteMap[tick] = (center + ((uint32_t)tick * activeLedCount) / 60) % activeLedCount;
  } else {
    validSideSequence = validSideSequence && seenOtherSide;
    for (uint8_t side = 1; side < 4; ++side)
      if (firstSide[side] == 0xFFFF || clockSideCount[side] == 0) validSideSequence = false;
    if (validSideSequence) {
      // North can straddle the beginning and end of this cyclic ordered path.
      const int32_t northMid = ((int32_t)firstNorthCount - (int32_t)lastNorthCount) / 2;
      clockSideStart[0] = (northMid + clockPathSize) % clockPathSize;
      for (uint8_t side = 1; side < 4; ++side)
        clockSideStart[side] = (firstSide[side] + clockSideCount[side] / 2) % clockPathSize;
    } else {
      // Degenerate/non-orthogonal maps: retain smooth physical order, not jumps.
      clockSideStart[0] = (wallLength[north] / 2) % clockPathSize;
      for (uint8_t side = 1; side < 4; ++side)
        clockSideStart[side] = (clockSideStart[0] + ((uint32_t)side * clockPathSize) / 4) % clockPathSize;
    }
    clockNorthPhase = clockSideStart[0];
    for (uint8_t tick = 0; tick < 60; ++tick)
      minuteMap[tick] = clockPath[clockPathIndex((double)tick)];
  }
  for (uint8_t h = 0; h < 12; ++h) hourMap[h] = minuteMap[h * 5];
  customWallMapEnabled = true;
  sBarPos = hourMap[0];
}
static bool saveRoomConfig() {
  if (!roomStorageAvailable) return false;
  StoredRoomConfig cfg = {};
  cfg.magic = ROOM_MAGIC; cfg.version = 2;
  cfg.ledCount = activeLedCount; cfg.density = ledsPerMeter;
  cfg.firstLed = roomStartLed; cfg.north = northSegment;
  cfg.cornerCount = savedRoomCornerCount;
  memcpy(cfg.corners, savedRoomCorners, sizeof(savedRoomCorners));
  cfg.checksum = roomChecksum(cfg);
  Adafruit_LittleFS_Namespace::File file(InternalFS);
  if (!file.open(ROOM_FILE, Adafruit_LittleFS_Namespace::FILE_O_WRITE)) return false;
  bool ok = file.seek(0) && file.truncate(0);
  if (ok) ok = file.write((const uint8_t*)&cfg, sizeof(cfg)) == sizeof(cfg);
  file.close();
  return ok;
}
static bool factoryResetSetup() {
  // Deliberately destructive. The tablet must first export a readable backup;
  // firmware independently verifies the existing PIN and session authorization.
  if (!clockStorageAvailable || !roomStorageAvailable || !pinStorageAvailable) return false;
  endRoomPreview();
  activeLedCount = LEDCOUNT; mapPreviewLedCount = LEDCOUNT;
  ledsPerMeter = 60; roomStartLed = 0; northSegment = 0;
  savedRoomCornerCount = 0; draftRoomCornerCount = 0; roomDraftInProgress = false;
  memset(savedRoomCorners, 0, sizeof(savedRoomCorners));
  memset(draftRoomCorners, 0, sizeof(draftRoomCorners));
  resetClockMap(); DST = 0;
  if (!saveRoomConfig() || !saveClockConfig()) return false;
  if (!updateControllerPin("", true)) return false;
  calibration.count = 0;
  if (calibrationStorageOK && !saveCalibration()) return false;
  strip.clear(); calibratedShow();
  return true;
}

static void loadRoomConfig() {
  roomStorageAvailable = clockStorageAvailable; // Reuse mounted InternalFS.
  if (!roomStorageAvailable) return;
  Adafruit_LittleFS_Namespace::File file(InternalFS);
  if (!file.open(ROOM_FILE, Adafruit_LittleFS_Namespace::FILE_O_READ)) return;
  StoredRoomConfig cfg = {};
  bool ok = file.size() == sizeof(cfg) && file.read(&cfg, sizeof(cfg)) == sizeof(cfg);
  file.close();
  if (!ok || cfg.magic != ROOM_MAGIC || cfg.version != 2 ||
      cfg.ledCount < 60 || cfg.ledCount > LEDCOUNT ||
      cfg.density < 1 || cfg.density > 240 || cfg.firstLed >= cfg.ledCount ||
      cfg.cornerCount > MAX_ROOM_CORNERS || cfg.checksum != roomChecksum(cfg)) {
    Serial.println("Room settings invalid; retaining defaults");
    return;
  }
  if (cfg.cornerCount && !validRoom(cfg.corners, cfg.cornerCount, cfg.ledCount)) return;
  activeLedCount = cfg.ledCount; ledsPerMeter = cfg.density;
  roomStartLed = cfg.cornerCount ? cfg.corners[0].led : cfg.firstLed;
  northSegment = cfg.cornerCount ? (cfg.north < cfg.cornerCount ? cfg.north : 0) : 0;
  savedRoomCornerCount = cfg.cornerCount;
  memcpy(savedRoomCorners, cfg.corners, sizeof(savedRoomCorners));
  beamSize = max(1, activeLedCount / 20);
  rebuildRoomClock();
}
static bool parseRoomPair(const String& s, int& one, int& two) {
  const int comma = s.indexOf(',');
  return comma > 0 && s.indexOf(',', comma + 1) < 0 &&
         parseDecimal(s.substring(0, comma), one) && parseDecimal(s.substring(comma + 1), two);
}
static uint16_t previewDistance(uint16_t start, uint16_t end) {
  return end >= start ? end - start : mapPreviewLedCount - start + end;
}
static void renderRoomPreviewFrame() {
  if (calibrationJog) {
    // Black background, green confirmed points and a red moving cursor.
    // The moving red dot always takes precedence on the current LED.
    strip.clear();
    if (calibrationJogStart < activeLedCount)
      strip.setPixelColor(calibrationJogStart, strip.Color(0, 175, 0));
    if (calibrationJogEnd < activeLedCount)
      strip.setPixelColor(calibrationJogEnd, strip.Color(0, 175, 0));
    if (calibrationJogCursor < activeLedCount)
      strip.setPixelColor(calibrationJogCursor, strip.Color(255, 0, 0));
    calibratedShow();
    return;
  }
  if (calibrationPreview) {
    // Light the entire strip at the SAME low reference level so corrections
    // can be compared directly against unadjusted neighboring LEDs.
    strip.clear();
    const uint32_t color=strip.Color(calibrationSampleR,calibrationSampleG,calibrationSampleB);
    strip.fill(color,0,activeLedCount);
    calibratedShow();
    return;
  }
  static const uint32_t palette[] = {0xFF8316, 0x05BFF7, 0xBD44FF, 0xFFE840,
                                     0x21DAAA, 0xE85688, 0x3FA4FF, 0xFFB877};
  strip.clear(); // Always blank strip outside the operating count.
  if (mapMeasureActive) {
    if (mapPendingLed >= 0 && mapPendingLed < activeLedCount)
      strip.setPixelColor((uint16_t)mapPendingLed, strip.Color(255, 255, 255));
    calibratedShow();
    return;
  }
  const RoomCorner* corners = roomDraftInProgress ? draftRoomCorners : savedRoomCorners;
  const uint8_t count = roomDraftInProgress ? draftRoomCornerCount : savedRoomCornerCount;
  if (mapHeldWall >= 0 && mapHeldWall < savedRoomCornerCount && savedRoomCornerCount >= 4) {
    // Light ONLY the selected saved wall while a connected tablet holds it.
    const uint8_t i = (uint8_t)mapHeldWall;
    const uint16_t start = savedRoomCorners[i].led;
    const uint16_t end = savedRoomCorners[(i + 1) % savedRoomCornerCount].led;
    uint16_t length = end >= start ? end - start : activeLedCount - start + end;
    if (i == savedRoomCornerCount - 1 && length == 0) length = activeLedCount;
    for (uint16_t n = 0; n < length; ++n)
      strip.setPixelColor((start + n) % activeLedCount, palette[i % 8]);
    calibratedShow();
    return;
  }
  if (mapTestColors && count >= 2) {
    for (uint8_t i = 0; i < count; i++) {
      uint16_t start = corners[i].led;
      uint16_t end = (i + 1 < count) ? corners[i + 1].led : corners[0].led;
      uint16_t length = previewDistance(start, end);
      if (i == count - 1 && length == 0) length = mapPreviewLedCount;
      for (uint16_t n = 0; n < length; n++)
        strip.setPixelColor((start + n) % mapPreviewLedCount, palette[i % 8]);
    }
  } else {
    for (uint8_t i = 0; i < count; i++) strip.setPixelColor(corners[i].led, 0x00FF00);
    if (count) strip.setPixelColor(corners[0].led, 0x00FF00);
    if (mapPendingLed >= 0 && mapPendingLed < LEDCOUNT)
      strip.setPixelColor((uint16_t)mapPendingLed, 0xFF0000);
  }
  calibratedShow();
}
static void renderRoomPreview() {
  mapPreviewDirty = true; // Actual LED output is handled in loop().
}
static void endRoomPreview() {
  mapPreviewActive = false; calibrationPreview = false; calibrationCompare = false; calibrationJog = false; mapMeasureActive = false; mapTestColors = false; mapHeldWall = -1; mapHoldOwner = BLE_CONN_HANDLE_INVALID; mapPendingLed = -1;
  mapPreviewDirty = false;
  outputBlackoutPending = true;
  previousModeName = ""; aOn = false;
}
static void handleRoomControl(const String& type, const String& name, const String& value) {
  if (type == "Cfg" && name == "Set") {
    int p1 = value.indexOf(','), p2 = value.indexOf(',', p1 + 1);
    int p3 = value.indexOf(',', p2 + 1);
    int total, density, first, north;
    if (p1 <= 0 || p2 <= p1 || p3 <= p2 || value.indexOf(',', p3 + 1) >= 0 ||
        !parseDecimal(value.substring(0, p1), total) ||
        !parseDecimal(value.substring(p1 + 1, p2), density) ||
        !parseDecimal(value.substring(p2 + 1, p3), first) ||
        !parseDecimal(value.substring(p3 + 1), north) ||
        total < 60 || total > LEDCOUNT || density < 1 || density > 240 ||
        first >= total || north > MAX_ROOM_CORNERS - 1) {
      protocolReply(type, name, "ERR_RANGE"); return;
    }
    // A new strip length can invalidate the old polygon. Safely discard the old
    // polygon before writing the new settings; it is backed up on the tablet.
    if (savedRoomCornerCount && !validRoom(savedRoomCorners, savedRoomCornerCount, total)) {
      savedRoomCornerCount = 0;
      memset(savedRoomCorners, 0, sizeof(savedRoomCorners));
      resetClockMap();
    }
    endRoomPreview();
    if (total != activeLedCount && customWallMapEnabled && savedRoomCornerCount == 0)
      resetClockMap(); // Old fixed-wall coordinates are no longer within the new strip.
    activeLedCount = total; ledsPerMeter = density;
    bool calibInvalid=false;
    for (uint8_t i=0;i<calibration.count;++i)
      if (!validCalibrationRange(calibration.ranges[i])) calibInvalid=true;
    if (calibInvalid) { calibration.count=0; saveCalibration(); }
    mapPreviewLedCount = total;
    roomStartLed = first; northSegment = north;
    beamSize = max(1, activeLedCount / 20);
    // Preserve the fixed-capacity array for NeoPixel DMA, but do not light the unused tail.
    rebuildRoomClock();
    outputBlackoutPending = true;
    protocolReply(type, name, saveRoomConfig() ? "OK" : "OK_VOLATILE"); announceChangedState(true);
  } else if (type == "Map" && name == "Clear" && value == "1") {
    endRoomPreview();
    savedRoomCornerCount = 0; draftRoomCornerCount = 0; roomDraftInProgress = false;
    memset(savedRoomCorners, 0, sizeof(savedRoomCorners));
    memset(draftRoomCorners, 0, sizeof(draftRoomCorners));
    northSegment = 0;
    resetClockMap();
    protocolReply(type, name, saveRoomConfig() ? "OK" : "OK_VOLATILE"); announceChangedState(true);
  } else if (type == "Map" && name == "Range") {
    // Safe, RAM-only perimeter for mapping a strip whose physical count differs
    // from the controller's old saved count. Never modifies flash or normal effects.
    int total;
    if (!parseDecimal(value, total) || total < 60 || total > LEDCOUNT) {
      protocolReply(type, name, "ERR_RANGE"); return;
    }
    mapPreviewLedCount = total;
    protocolReply(type, name, "OK");
  } else if (type == "Map" && name == "Begin") {
    int start;
    if (!parseDecimal(value, start) || start >= mapPreviewLedCount) {
      protocolReply(type, name, "ERR_RANGE"); return;
    }
    draftRoomCornerCount = 0;
    memset(draftRoomCorners, 0, sizeof(draftRoomCorners));
    draftRoomStartLed = start; roomDraftInProgress = true;
    mapPreviewActive = true; mapTestColors = false;
    mapPendingLed = start; renderRoomPreview();
    protocolReply(type, name, "OK");
  } else if (type == "Map" && name == "Corner") {
    int p1 = value.indexOf(','), p2 = value.indexOf(',', p1 + 1);
    int seq, physical, inside;
    if (p1 <= 0 || p2 <= p1 || value.indexOf(',', p2 + 1) >= 0 ||
        !parseDecimal(value.substring(0, p1), seq) ||
        !parseDecimal(value.substring(p1 + 1, p2), physical) ||
        !parseDecimal(value.substring(p2 + 1), inside) ||
        seq < 0 || seq >= MAX_ROOM_CORNERS || seq > draftRoomCornerCount ||
        physical >= mapPreviewLedCount || inside > 1) {
      protocolReply(type, name, "ERR_CORNER"); return;
    }
    if (seq == 0 && physical != draftRoomStartLed) {
      protocolReply(type, name, "ERR_START"); return;
    }
    if (seq > 0) {
      const uint16_t prev = previewDistance(draftRoomStartLed, draftRoomCorners[seq - 1].led);
      const uint16_t next = previewDistance(draftRoomStartLed, physical);
      if (next <= prev) { protocolReply(type, name, "ERR_ORDER"); return; }
    }
    draftRoomCorners[seq] = { (uint16_t)physical, (uint8_t)inside, 0 };
    if (seq == draftRoomCornerCount) draftRoomCornerCount++;
    mapPreviewActive = true; mapTestColors = false;
    renderRoomPreview();
    protocolReply(type, name, "OK");
  } else if (type == "Map" && name == "Preview") {
    int led;
    if (!parseDecimal(value, led) || led >= LEDCOUNT) {
      protocolReply(type, name, "ERR_RANGE"); return;
    }
    mapPendingLed = led; mapPreviewActive = true; mapTestColors = false;
    renderRoomPreview(); protocolReply(type, name, "OK");
  } else if (type == "Map" && name == "WallHold") {
    int wall;
    if (!parseDecimal(value, wall) || savedRoomCornerCount < 4 ||
        wall < 0 || wall >= savedRoomCornerCount) {
      protocolReply(type, name, "ERR_RANGE"); return;
    }
    mapMeasureActive = false;
    mapHeldWall = (int8_t)wall;
    mapHoldOwner = replyConnection;
    mapPreviewActive = true; mapTestColors = false; roomDraftInProgress = false;
    renderRoomPreview(); protocolReply(type, name, "OK");
  } else if (type == "Map" && name == "Measure") {
    int led;
    if (!parseDecimal(value, led) || led < 0 || led >= activeLedCount) {
      protocolReply(type, name, "ERR_RANGE"); return;
    }
    mapMeasureActive = true; mapHeldWall = -1; mapTestColors = false;
    mapPendingLed = led; roomDraftInProgress = false; mapPreviewActive = true;
    renderRoomPreview(); protocolReply(type, name, "OK");
  } else if (type == "Map" && name == "Test") {
    mapPreviewActive = true; mapTestColors = value == "1";
    renderRoomPreview(); protocolReply(type, name, "OK");
  } else if (type == "Map" && name == "Stop") {
    endRoomPreview(); mapPreviewLedCount = activeLedCount;
    protocolReply(type, name, "OK");
  } else if (type == "Map" && name == "Apply") {
    int count, north;
    if (!parseRoomPair(value, count, north) || count != draftRoomCornerCount ||
        !validRoom(draftRoomCorners, count, activeLedCount) || north >= count) {
      protocolReply(type, name, "ERR_LAYOUT"); return;
    }
    savedRoomCornerCount = count; northSegment = north;
    memcpy(savedRoomCorners, draftRoomCorners, sizeof(savedRoomCorners));
    roomStartLed = savedRoomCorners[0].led;
    roomDraftInProgress = false;
    customWallMapEnabled = false;
    rebuildRoomClock();
    endRoomPreview();
    protocolReply(type, name, saveRoomConfig() ? "OK" : "OK_VOLATILE"); announceChangedState(true);
  } else protocolReply(type, name, "ERR_INPUT");
}
static void handleRoomRequest(const String& type, const String& name) {
  if (type == "Cfg" && name == "Info") {
    protocolReply(type, name, String(activeLedCount) + "," + String(ledsPerMeter) + "," +
        String(roomStartLed) + "," + String(northSegment) + "," + String(savedRoomCornerCount));
  } else if (type == "Map" && name == "Count") {
    protocolReply(type, name, String(savedRoomCornerCount));
  } else if (type == "Map") {
    int seq;
    if (parseDecimal(name, seq) && seq < savedRoomCornerCount) {
      const RoomCorner& c = savedRoomCorners[seq];
      protocolReply(type, name, String(c.led) + "," + String(c.inside));
    } else protocolReply(type, name, "UNSET");
  } else protocolReply(type, name, "ERR_INPUT");
}
static bool parseCsvIntegers(const String& input, int* values, int expected) {
  int from=0;
  for (int i=0; i<expected; ++i) {
    int comma=input.indexOf(',',from);
    if ((i<expected-1 && comma<0) || (i==expected-1 && comma>=0)) return false;
    String piece=input.substring(from, comma<0 ? input.length() : comma);
    if (!parseDecimal(piece, values[i])) return false;
    from=comma+1;
  }
  return true;
}

static void handleCalibrationRequest(const String& name) {
  if (name == "Count") { protocolReply("Cal", name, String(calibration.count)); return; }
  int index = -1;
  if (!parseDecimal(name, index) || index < 0 || index >= calibration.count) {
    protocolReply("Cal", name, "UNSET"); return;
  }
  const LedCorrectionRange& r = calibration.ranges[index];
  protocolReply("Cal", name, String(r.start) + "," + String(r.end) + "," +
    String(r.brightnessPercent) + "," + String(r.lowLift) + "," +
    String(r.redPercent) + "," + String(r.greenPercent) + "," + String(r.bluePercent));
}
static void handleCalibrationControl(const String& name, const String& value) {
  if (name == "Clear" && value == "1") {
    StoredLedCorrections previous = calibration;
    calibration = {};
    if (!saveCalibration()) { calibration = previous; protocolReply("Cal", name, "ERR_FLASH"); return; }
    protocolReply("Cal", name, "OK"); announceChangedState(true); return;
  }
  if (name == "Stop") {
    calibrationPreview = false; calibrationCompare = false; calibrationJog = false;
    endRoomPreview();
    protocolReply("Cal", name, "OK"); return;
  }
  if (name == "Jog") {
    // confirmedStart,confirmedEnd,moving. A sentinel equal to activeLedCount
    // means not yet confirmed. All values are physical LED indices.
    int vals[3] = {};
    if (!parseCsvIntegers(value, vals, 3)) { protocolReply("Cal", name, "ERR_INPUT"); return; }
    if (vals[0] < 0 || vals[0] > activeLedCount ||
        vals[1] < 0 || vals[1] > activeLedCount ||
        vals[2] < 0 || vals[2] >= activeLedCount) {
      protocolReply("Cal", name, "ERR_RANGE"); return;
    }
    calibrationJogStart = (uint16_t)vals[0];
    calibrationJogEnd = (uint16_t)vals[1];
    calibrationJogCursor = (uint16_t)vals[2];
    calibrationJog = true; calibrationPreview = false; calibrationCompare = false;
    mapPreviewActive = true; mapPreviewDirty = true;
    protocolReply("Cal", name, "OK"); return;
  }
  if (name == "Compare") {
    // start,end,R,G,B,after,brightnessGain,lowLift,redGain,greenGain,blueGain
    // Uses RAM-only candidate settings. No flash writes and no mode change.
    int vals[11] = {};
    if (!parseCsvIntegers(value, vals, 11)) { protocolReply("Cal", name, "ERR_INPUT"); return; }
    if (vals[0] < 0 || vals[1] < vals[0] || vals[1] >= activeLedCount ||
        vals[2] < 0 || vals[2] > 255 || vals[3] < 0 || vals[3] > 255 ||
        vals[4] < 0 || vals[4] > 255 || vals[5] < 0 || vals[5] > 1 ||
        vals[6] < 50 || vals[6] > 150 || vals[7] < 0 || vals[7] > 16 ||
        vals[8] < 50 || vals[8] > 150 || vals[9] < 50 || vals[9] > 150 ||
        vals[10] < 50 || vals[10] > 150) {
      protocolReply("Cal", name, "ERR_RANGE"); return;
    }
    calibrationCandidate = {(uint16_t)vals[0], (uint16_t)vals[1],
      (uint8_t)vals[6], (uint8_t)vals[7], (uint8_t)vals[8],
      (uint8_t)vals[9], (uint8_t)vals[10], 0};
    calibrationSampleR=(uint8_t)vals[2];calibrationSampleG=(uint8_t)vals[3];calibrationSampleB=(uint8_t)vals[4];
    calibrationCompareAfter=vals[5]==1;
    calibrationCompare=true;calibrationJog=false;calibrationPreview=true;
    mapPreviewActive=true;mapPreviewDirty=true;
    protocolReply("Cal", name, "OK"); return;
  }
  if (name == "Preview") {
    // start,end,R,G,B as RAW RGB values so a sample of 10 looks like ~4% brightness.
    int vals[5] = {};
    if (!parseCsvIntegers(value, vals, 5)) { protocolReply("Cal", name, "ERR_INPUT"); return; }
    if (vals[0] < 0 || vals[1] < vals[0] || vals[1] >= activeLedCount ||
        vals[2] < 0 || vals[2] > 255 || vals[3] < 0 || vals[3] > 255 || vals[4] < 0 || vals[4] > 255) {
      protocolReply("Cal", name, "ERR_RANGE"); return;
    }
    calibrationPreviewStart=vals[0]; calibrationPreviewEnd=vals[1];
    calibrationSampleR=vals[2];calibrationSampleG=vals[3];calibrationSampleB=vals[4];
    calibrationCompare=false;calibrationJog=false;
    calibrationPreview=true;mapPreviewActive=true;mapPreviewDirty=true;
    protocolReply("Cal", name, "OK"); return;
  }
  if (name == "Save") {
    int vals[8] = {};
    if (!parseCsvIntegers(value, vals, 8)) { protocolReply("Cal", name, "ERR_INPUT"); return; }
    int index=vals[0];
    if (index<0 || index>=MAX_LED_CORRECTIONS || index>calibration.count) {
      protocolReply("Cal", name, "ERR_RANGE"); return;
    }
    LedCorrectionRange r = {(uint16_t)vals[1],(uint16_t)vals[2],
      (uint8_t)vals[3],(uint8_t)vals[4],(uint8_t)vals[5],
      (uint8_t)vals[6],(uint8_t)vals[7],0};
    if (vals[1] < 0 || vals[2] < 0 || vals[1] >= activeLedCount || vals[2] >= activeLedCount ||
        vals[3] < 50 || vals[3] > 150 || vals[4] < 0 || vals[4] > 16 ||
        vals[5] < 50 || vals[5] > 150 || vals[6] < 50 || vals[6] > 150 ||
        vals[7] < 50 || vals[7] > 150 || !validCalibrationRange(r)) {
      protocolReply("Cal", name, "ERR_RANGE"); return;
    }
    for (uint8_t i=0; i<calibration.count; ++i)
      if (i != index && r.start<=calibration.ranges[i].end && calibration.ranges[i].start<=r.end) {
        protocolReply("Cal", name, "ERR_OVERLAP"); return;
      }
    StoredLedCorrections previous=calibration;
    calibration.ranges[index]=r;
    if (index==calibration.count) calibration.count++;
    if (!saveCalibration()) { calibration=previous; protocolReply("Cal", name, "ERR_FLASH"); return; }
    protocolReply("Cal", name, "OK"); announceChangedState(true); return;
  }
  if (name == "Delete") {
    int index = -1;
    if (!parseDecimal(value, index) || index < 0 || index >= calibration.count) {
      protocolReply("Cal", name, "ERR_RANGE"); return;
    }
    StoredLedCorrections previous=calibration;
    for (int i=index; i+1<calibration.count; ++i) calibration.ranges[i]=calibration.ranges[i+1];
    calibration.count--;
    if (!saveCalibration()) { calibration=previous; protocolReply("Cal", name, "ERR_FLASH"); return; }
    protocolReply("Cal", name, "OK"); announceChangedState(true); return;
  }
  protocolReply("Cal", name, "ERR_INPUT");
}

void setup() {
  Serial.begin(115200);
  strip.begin();
  Serial.println("------------------------------\n");
  Serial.println("Starting Controller");
  if (!rtc.begin()) {
    Serial.println("Couldn't find RTC");
    Serial.flush();
    while (1) delay(10);
  }

  strip.setBrightness(255);
  strip.fill(strip.Color(0, 0, 0), 0, LEDCOUNT);
  calibratedShow();
  if (rtc.lostPower()) {
    Serial.println("RTC lost power, let's set the time!");
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }
  ledState = false;
  ledMode = 0;
  loadClockConfig();
  loadRoomConfig();
  loadControllerPin();
  loadCalibration();
  if (currentModeName.length() == 0) currentModeName = "Color";
  for (int i=0; i<MAX_PRPH_CONNECTION; ++i) sessionHandles[i] = BLE_CONN_HANDLE_INVALID;
  DateTime now = rtc.now();
  randomSeed((unsigned long)now.unixtime() ^ (unsigned long)micros());
  tMillis = now.second() * 1000;

  // Initialize BLE
  // if (!Bluefruit.begin()) {
  //   Serial.println("BLE initialization failed.");
  //   while (1) delay(10);  // Stay here if initialization fails
  // }
  Bluefruit.configPrphBandwidth(BANDWIDTH_MAX);
  Bluefruit.configCentralBandwidth(BANDWIDTH_MAX);
  Bluefruit.begin(MAX_PRPH_CONNECTION, 0);
  // Bluefruit.setTxPower(4);
  Bluefruit.Periph.setConnectCallback(connect_callback);
  Bluefruit.Periph.setDisconnectCallback(disconnect_callback);

  Serial.println("Configuring the Custom Service");
  customService.begin();

  // Serial.println("Setting pairing PIN to: " PAIRING_PIN);
  // Bluefruit.Security.setPIN(PAIRING_PIN);

  ledModesCharacteristic.setProperties(CHR_PROPS_READ | CHR_PROPS_NOTIFY);
  ledModesCharacteristic.setPermission(SECMODE_OPEN, SECMODE_OPEN);
  ledModesCharacteristic.setCccdWriteCallback(cccd_callback);
  ledModesCharacteristic.begin();

  parameterRequestCharacteristic.setProperties(CHR_PROPS_WRITE | CHR_PROPS_WRITE_WO_RESP);
  parameterRequestCharacteristic.setPermission(SECMODE_OPEN, SECMODE_OPEN);
  parameterRequestCharacteristic.setCccdWriteCallback(cccd_callback);
  parameterRequestCharacteristic.setWriteCallback(parameterRequestCharacteristicWritten);
  parameterRequestCharacteristic.begin();

  // For the response characteristic, ensure that it supports notifications.
  parameterResponseCharacteristic.setProperties(CHR_PROPS_READ | CHR_PROPS_NOTIFY | CHR_PROPS_WRITE_WO_RESP);
  parameterResponseCharacteristic.setPermission(SECMODE_OPEN, SECMODE_OPEN);
  parameterResponseCharacteristic.setWriteCallback(parameterResponseCharacteristicWritten);
  parameterResponseCharacteristic.setCccdWriteCallback(cccd_callback);
  parameterResponseCharacteristic.begin();

  parameterControlCharacteristic.setProperties(CHR_PROPS_WRITE | CHR_PROPS_WRITE_WO_RESP);
  parameterControlCharacteristic.setPermission(SECMODE_OPEN, SECMODE_OPEN);
  parameterControlCharacteristic.setWriteCallback(parameterControlCharacteristicWritten);
  parameterControlCharacteristic.begin();

  Serial.println("Starting Mode Push");

  Serial.println("Advertising BLE service");

  bledfu.begin();
  bledis.setManufacturer("Cole Rabe");
  bledis.setModel("DormLED Controller");
  bledis.begin();

  // bleuart.begin();

  Bluefruit.setName("Room LED Controller");  // Change Bluetooth device name here

  // Prepopulate readable mode list before any phone connects.
  sendLEDModeList();

  // Start advertising
  startAdv();

  pinMode(SQWV, INPUT);
  rtc.writeSqwPinMode(DS3231_SquareWave1kHz);
  cResync();
  attachInterrupt(digitalPinToInterrupt(SQWV), RTCMillis, CHANGE);
  timeout();
}

void loop() {
  cMillis = millis();
  static uint32_t previousLoopMs = 0;
  if (previousLoopMs) {
    const uint32_t gap = (uint32_t)(cMillis - previousLoopMs);
    if (gap > maxObservedLoopGapMs) maxObservedLoopGapMs = gap;
  }
  previousLoopMs = cMillis;
  ++loopTickCounter;
  // Physical recovery: connect USB, open Serial Monitor 115200 and type PINRESET. This
  // does not allow a remote unauthenticated BLE client to reset the 4-digit code.
  static String serialRecovery = "";
  while (Serial.available()) {
    const char c = (char)Serial.read();
    if (c == '\n' || c == '\r') {
      if (serialRecovery == "PINRESET") {
        if (updateControllerPin("", true)) { Serial.println("Controller PIN erased; disconnecting all devices"); scheduleDisconnectAll(); }
        else Serial.println("PIN reset failed: flash unavailable");
      }
      serialRecovery = "";
    } else if (serialRecovery.length() < 20) serialRecovery += c;
  }
  if (pendingSecurityDisconnect && (int32_t)(millis() - securityDisconnectAt) >= 0) {
    pendingSecurityDisconnect = false;
    uint16_t handles[MAX_PRPH_CONNECTION] = {};
    const uint8_t count = Bluefruit.getConnectedHandles(handles, MAX_PRPH_CONNECTION);
    for (uint8_t i=0; i<count; ++i) Bluefruit.disconnect(handles[i]);
  }
  cResync();
  if (outputBlackoutPending) {
    outputBlackoutPending = false;
    strip.clear(); calibratedShow();
  }
  // Render all LEDs only from the main loop: never from the BLE callbacks.
  if (mapPreviewActive) {
    if (mapPreviewDirty && (uint32_t)(cMillis - lastMapFrameMs) >= 45UL) {
      mapPreviewDirty = false;
      lastMapFrameMs = cMillis;
      renderRoomPreviewFrame();
    }
  } else {
    executeCurrentMode();
  }
  rampBright();
  serviceStateBroadcast();
  static uint32_t lastHealthPrintMs = 0;
  if (Serial && (uint32_t)(cMillis - lastHealthPrintMs) >= 30000UL) {
    lastHealthPrintMs = cMillis;
    Serial.print("HEALTH uptime_s="); Serial.print(cMillis / 1000UL);
    Serial.print(" loop_max_ms="); Serial.print(maxObservedLoopGapMs);
    Serial.print(" ble_clients="); Serial.println(connection_count);
  }

  if (stripBright != buffStripBright && inRamp == false) {
    stripBright = buffStripBright;
    prevStripBright = buffStripBright;
    hasSet = false;
  }

  // Responses are only written for explicit requests, never on every frame.
}


// Small catalog pages avoid the BLE notification MTU limit and permit new modes.
// The first page is the readable GATT characteristic, the rest are requested.
static void sendModeCatalogPart(int begin, int end) {
  String list;
  for (int i=begin; i<end && i<numModes; ++i) {
    list += ledModes[i].name + ":";
    for (int j=0; j<ledModes[i].numParams; ++j) {
      if (j) list += ",";
      list += ledModes[i].paramNames[j];
    }
    list += ";";
  }
  // Existing request has already selected Extra or Extra2 for reply routing.
  parameterResponse(list);
}

void sendLEDModeList() {
  String modeList = "";  // Start with an empty string to hold the modes

  // Loop through each mode and append its details
  for (int i = 0; i < 12 && i < numModes; i++) {
    modeList += ledModes[i].name + ":";  // Mode name

    // Append each parameter for the current mode
    for (int j = 0; j < ledModes[i].numParams; j++) {
      modeList += ledModes[i].paramNames[j];  // Only include parameter name
      if (j < ledModes[i].numParams - 1) {
        modeList += ",";
      }
    }

    modeList += ";";  // Separate modes with semicolon
  }

  // Send the mode list via the BLE characteristic
  ledModesCharacteristic.write((const uint8_t*)modeList.c_str(), modeList.length());
  if (connection_count > 0 && ledModesCharacteristic.notifyEnabled()) {
    ledModesCharacteristic.notify(modeList.c_str());
  }

  Serial.println("LED Modes sent to tablet:");
  Serial.println(modeList);  // Print to Serial for debugging
}

void parameterControlCharacteristicWritten(uint16_t conn_hdl, BLECharacteristic* chr, uint8_t* data, uint16_t len) {
  replyConnection = conn_hdl;
  lastReceivedCommandMs = millis();
  ++totalBleCommandCount;
  // Optional compact v1 transport (4 bytes). Only real-time non-security
  // controls use it. All protected configuration operations stay textual.
  // 0xA5, version=1, opcode, value. Unknown versions fall back to text safely.
  if (len == 4 && data[0] == 0xA5 && data[1] == 1) {
    const uint8_t op = data[2], value = data[3];
    if (op == 1 && value <= 100) {
      tabletAudioLevel = value; lastAudioPacketMs = millis();
    } else if (op == 2 && value <= 100) {
      if (mapPreviewActive) endRoomPreview();
      setBrightness(value); announceChangedState();
    } else if (op == 3 && value <= 99) { tabletWeatherCode = value; weatherCodeReceived = true; }
    else if (op == 4 && value <= 200) tabletWindKmh = value;
    else if (op == 5 && value <= 1) { tabletWeatherDay = value == 1; weatherDayReceived = true; }
    else if (op == 6 && (value <= 100 || value == 255)) {
      sunriseLevel = value; sunrisePacketMs = millis();
    }
    return;
  }
  // Security payloads must never be logged (even over USB Serial).
  Serial.println("Data Control Action Called!");
  if (len == 0 || len >= MAX_BUFFER_SIZE) {
    Serial.println("Error: Received control payload outside supported length.");
    return;
  }

  char cleanedData[MAX_BUFFER_SIZE] = { 0 };
  strncpy(cleanedData, (char*)data, min((int)len, MAX_BUFFER_SIZE - 1));  // Use min to prevent buffer overflow

  String controlData = String(cleanedData);
  controlData.trim();

  if (!controlData.startsWith("Sec:")) Serial.println("Received command: " + controlData);


  int firstColonIndex = controlData.indexOf(":");
  if (firstColonIndex == -1) {
    Serial.println("Invalid command format: Missing first colon.");
    return;
  }

  String controlType = controlData.substring(0, firstColonIndex);
  controlData = controlData.substring(firstColonIndex + 1);  // Remove type from command

  int secondColonIndex = controlData.indexOf(":");
  if (secondColonIndex == -1) {
    Serial.println("Invalid command format: Missing second colon.");
    return;
  }

  String controlName = controlData.substring(0, secondColonIndex);
  String controlValue = controlData.substring(secondColonIndex + 1);

  controlType.trim();
  controlName.trim();
  controlValue.trim();

  if (controlValue.startsWith("{") && controlValue.endsWith("}")) {
    controlValue = controlValue.substring(1, controlValue.length() - 1);
  }

  if (controlType == "Audio" && controlName == "Level") {
    // Throttled tablet microphone envelope (0..100). Ignore non-decimal payloads.
    int level = -1;
    if (parseDecimal(controlValue, level) && level >= 0 && level <= 100) {
      tabletAudioLevel = (uint8_t)level;
      lastAudioPacketMs = millis();
    }
    return;
  }
  if (controlType == "Sec") {
    handleSecurityControl(conn_hdl, controlName, controlValue);
    return;
  }
  if ((controlType == "RTC" || controlType == "Wall" || controlType == "Cfg" || controlType == "Map" || controlType == "Cal")
      && !authorized(conn_hdl)) {
    protocolReply(controlType, controlName, controllerPinSet ? "ERR_AUTH" : "ERR_SET_PIN");
    return;
  }
  if (controlType == "RTC" || controlType == "Wall") {
    handleClockControl(controlType, controlName, controlValue);
  } else if (controlType == "Cfg" || controlType == "Map") {
    handleRoomControl(controlType, controlName, controlValue);
  } else if (controlType == "Cal") {
    handleCalibrationControl(controlName, controlValue);
  } else if (controlType == "Mode") {
    bool found = false;
    for (int i=0; i<numModes; ++i) if (ledModes[i].name == controlValue) { found = true; break; }
    if (!found) { protocolReply(controlType, controlName, "ERR_MODE"); return; }
    if (mapPreviewActive) endRoomPreview(); // A mode command always exits setup preview.
    currentModeName = controlValue;
    gravityInit=false; meteorActive=false; meteorExplosion=0;
    lastEffectFrameMs=0; cylonHead=0; cylonReturning=false;
    // Reset effect state when switching away and returning to the same effect.
    effectResetPending = true;
    announceChangedState();
    protocolReply(controlType, controlName, "OK");
    Serial.print("Updated Mode to ");
    Serial.println(currentModeName);
    aOn = false;
  } else if (controlType == "Parameter") {
    bool parameterUpdated = false;
    // Find the current mode in the array
    for (int i = 0; i < sizeof(ledModes) / sizeof(ledModes[0]); i++) {
      if (ledModes[i].name == currentModeName) {
        // Mode found, now find the parameter to update
        for (int j = 0; j < ledModes[i].numParams; j++) {
          if (ledModes[i].paramNames[j] == controlName) {
            if (controlName == "Color" || controlName == "SColor") {
              unsigned int r, g, b;
              parseRGB(controlValue, r, g, b);

              // Update the parameter values in the array (store r, g, b separately)
              for (int j = 0; j < ledModes[i].numParams; j++) {
                if (ledModes[i].paramNames[j] == controlName) {
                  ledModes[i].paramValuesR[j] = r;
                  ledModes[i].paramValuesG[j] = g;
                  ledModes[i].paramValuesB[j] = b;
                  Serial.print("Updated parameter ");
                  Serial.print(controlName);
                  Serial.print(" to ");
                  Serial.print(r);
                  Serial.print(", ");
                  Serial.print(g);
                  Serial.print(", ");
                  Serial.println(b);
                  parameterUpdated = true;
                  break;
                }
              }
             } else if (controlName == "Speed" || controlName == "Frequency" || controlName == "Division" ||
                       controlName == "Sensitivity" || controlName == "Reaction" ||
                       controlName == "Pattern" || controlName == "Direction" ||
                       controlName == "Bounce" || controlName == "Palette" || controlName == "Fade" ||
                       controlName == "Spawn" || controlName == "Decay" || controlName == "Length" ||
                       controlName == "Size" || controlName == "Collision") {
              // Remove brackets if present (before converting to int)
              if (controlValue.startsWith("[") && controlValue.endsWith("]")) {
                controlValue = controlValue.substring(1, controlValue.length() - 1);
              }
              int numValue = controlValue.toInt();
              if (controlName == "Sensitivity") numValue = constrain(numValue, 1, 100);
              if (controlName == "Reaction") numValue = constrain(numValue, 0, 2);
              if (controlName == "Pattern") numValue = constrain(numValue, 0, 2);
              if (controlName == "Direction") numValue = constrain(numValue, 0, 2);
              if (controlName == "Palette" || controlName == "Bounce") numValue = constrain(numValue, 0, 1);
              if (controlName == "Fade") numValue = constrain(numValue, 0, 100);
              if (controlName == "Collision") numValue = constrain(numValue, 0, 1);
              if (controlName == "Spawn" && currentModeName == "Alternating Phaser") numValue = constrain(numValue, 0, 2);
              if (controlName == "Length" || controlName == "Size" || controlName == "Decay") numValue = constrain(numValue, 1, 100);
              Serial.print("Parsed Numeric Parameter (");
              Serial.print(controlName);
              Serial.print("): ");
              Serial.println(numValue);

              // Update the parameter value in the array (convert to String)
              ledModes[i].paramValuesOther[j] = String(numValue);
              Serial.print("Updated parameter ");
              Serial.print(controlName);
              Serial.print(" to ");
              Serial.println(numValue);
              parameterUpdated = true;
            }
            break;  // Parameter found, exit inner loop
          }
        }
        break;  // Mode found, exit outer loop
      }
    }
    if (parameterUpdated) {  // Check the flag *after* the loops
      announceChangedState();
      protocolReply(controlType, controlName, "OK");
      Serial.println("Successfully updated parameters in the array.");
      previousModeName = "";
      if (currentModeName == "Gravity Fill" || currentModeName == "Gravity Wipe") {
        gravityInit=false;
        lastEffectFrameMs=0;
      }
    } else {
      Serial.println("Parameter not found for the current mode.");
      protocolReply(controlType, controlName, "ERR_PARAM");
    }
  } else if (controlType == "Weather" && controlName == "Code") {
    int weatherCode;
    if (!parseDecimal(controlValue, weatherCode) || weatherCode > 99) {
      protocolReply(controlType, controlName, "ERR_RANGE"); return;
    }
    tabletWeatherCode = (uint8_t)weatherCode;
    weatherCodeReceived = true;
    protocolReply(controlType, controlName, "OK");
  } else if (controlType == "Weather" && controlName == "Day") {
    tabletWeatherDay = controlValue == "1";
    weatherDayReceived = true;
    protocolReply(controlType, controlName, "OK");
  } else if (controlType == "Weather" && controlName == "Wind") {
    int wind;
    if (!parseDecimal(controlValue, wind) || wind > 200) {
      protocolReply(controlType, controlName, "ERR_RANGE"); return;
    }
    tabletWindKmh = wind;
    protocolReply(controlType, controlName, "OK");
  } else if (controlType == "Brightness") {
    int brightnessValue = constrain(controlValue.toInt(), 0, 100);
    setBrightness(brightnessValue);
    announceChangedState();
    protocolReply(controlType, controlName, "OK");
    Serial.print("Updated Brightness to ");
    Serial.println(brightnessValue);
  } else if (controlType == "Power") {
    if (mapPreviewActive) endRoomPreview();
    int powerState = controlValue.toInt();
    ledState = powerState;
    announceChangedState();
    protocolReply(controlType, controlName, "OK");
    if (ledState) {
      Serial.println("Turning ON LED");
      previousModeName = "";
    } else {
      outputBlackoutPending = true;
      Serial.println("Turning OFF LED");
    }
    // Set Power State Here
  } else {
    Serial.println("Unknown Type");
  }
}

static void parameterResponseCharacteristicWritten(uint16_t conn_handle, BLECharacteristic* pCharacteristic, uint8_t* data, uint16_t len) {
  if (pCharacteristic->uuid == parameterResponseCharacteristic.uuid) {
    std::vector<uint8_t> value(data, data + len);

    if (value.size() == 2) {
      uint16_t cccdValue = (value[1] << 8) | value[0];

      // Use Adafruit's definitions:
      if (cccdValue == BLE_CCCD_NOTIFY_VALUE) {  // Corrected!
        Serial.println("Notifications enabled for parameterResponseCharacteristic");
        // parameterResponseCharacteristic.notify();  // Notify after setting a value
      } else if (cccdValue == BLE_CCCD_INDICATE_VALUE) {  // Corrected!
        Serial.println("Indications enabled for parameterResponseCharacteristic");
      } else if (cccdValue == 0) {
        Serial.println("Notifications/Indications disabled for parameterResponseCharacteristic");
      }
    }
  }
}

void parameterRequestCharacteristicWritten(uint16_t conn_hdl, BLECharacteristic* chr, uint8_t* data, uint16_t len) {
  replyConnection = conn_hdl;
  lastReceivedCommandMs = millis();
  ++totalBleCommandCount;
  // Avoid dumping every byte over USB for every app request.
  // Serial.println("Data Request Action Called!");
  // Per-byte Serial logging is intentionally disabled for BLE stability.

  // Bound callback payload length before copying from the BLE-owned buffer.
  if (len == 0 || len >= MAX_BUFFER_SIZE) return;
  char dataString[MAX_BUFFER_SIZE];
  memcpy(dataString, data, len);
  dataString[len] = '\0';
  String receivedData = String(dataString);
  receivedData.trim();
  Serial.print("Cleaned Command: ");
  Serial.println(receivedData);

  // Extract mode and parameter
  String requestType = "";   //Type of request
  String requestName = "";   //Request the value from type in mode
  String requestValue = "";  //Request the value from type

  int firstColonIndex = receivedData.indexOf(":");
  if (firstColonIndex == -1) {
    Serial.println("Invalid command format: Missing first colon.");
    return;
  } else {
    String requestType = receivedData.substring(0, firstColonIndex);
    receivedData = receivedData.substring(firstColonIndex + 1);

    int secondColonIndex = receivedData.indexOf(":");
    if (secondColonIndex == -1) {
      Serial.println("Invalid command format: Missing second colon.");
      return;
    }

    String requestName = receivedData.substring(0, secondColonIndex);
    String requestValue = receivedData.substring(secondColonIndex + 1);

    requestType.trim();
    requestName.trim();
    requestValue.trim();

    requestType.toCharArray(storedRequestType, sizeof(storedRequestType));
    requestName.toCharArray(storedRequestName, sizeof(storedRequestName));

    Serial.print("Requesting Type: ");
    Serial.println(requestType);
    Serial.print("From Mode: ");
    Serial.println(requestName);
    Serial.print("And Value: ");
    Serial.println(requestValue);

    if (requestValue.startsWith("{") && requestValue.endsWith("}")) {
      requestValue = requestValue.substring(1, requestValue.length() - 1);
    }
    if (requestType == "State") sendStateRequest(requestName);
    else if (requestType == "Sec") handleSecurityRequest(requestName);
    else if (requestType == "RTC" || requestType == "Wall") {
      handleClockRequest(requestType, requestName);
    } else if (requestType == "Cfg" || requestType == "Map") {
      handleRoomRequest(requestType, requestName);
    } else if (requestType == "Cal") {
      handleCalibrationRequest(requestName);
    } else if (requestType == "Mode" && requestName == "Extra") {
      sendModeCatalogPart(12, 19);
    } else if (requestType == "Mode" && requestName == "Extra2") {
      sendModeCatalogPart(19, 24);
    } else if (requestType == "Mode" && requestName == "Extra3") {
      sendModeCatalogPart(24, numModes);
    } else if (requestType == "Mode") {
      String currentModeNameStr = String(currentModeName);  // Convert mode name to string
      parameterResponse(currentModeNameStr);
    } else if (requestType == "Parameter") {
      bool parameterFound = false;
      for (int i = 0; i < sizeof(ledModes) / sizeof(ledModes[0]); i++) {
        if (ledModes[i].name == requestName) {
          // Look for the requested parameter
          for (int j = 0; j < ledModes[i].numParams; j++) {
            if (ledModes[i].paramNames[j] == requestValue) {
              String responseValue;
              // Check if the parameter corresponds to a color (RGB)
              if (requestValue == "Color" || requestValue == "SColor") {
                responseValue = "{" + String(ledModes[i].paramValuesR[j]) + "," + String(ledModes[i].paramValuesG[j]) + "," + String(ledModes[i].paramValuesB[j]) + "}";
              } else {
                // Non-color parameters are stored as strings in paramValuesOther
                responseValue = ledModes[i].paramValuesOther[j];
              }
              // Send the response
              parameterResponse(responseValue);
              parameterFound = true;

              Serial.print("Responding with ");
              Serial.print(requestValue);
              Serial.print(": ");
              Serial.println(responseValue);
              break;
            }
          }
          if (!parameterFound) {
            Serial.print("Unknown Parameter Name: ");
            Serial.println(requestValue);
          }
        } else {
          Serial.println("Mode name not found!");
        }
      }
    } else if (requestType == "Brightness") {
      String buffStripBrightStr = String(buffStripBright);  // Convert brightness to string
      parameterResponse(buffStripBrightStr);
    } else if (requestType == "Power") {
      String ledStateStr = String(ledState);  // Convert power state to string
      parameterResponse(ledStateStr);
    } else {
      Serial.println("Unknown Request Type");
    }
  }
}

void parameterResponse(const String& responseStr) {
  // Determine parameter type and mode.
  // (These could be dynamically determined; here we assume defaults for demonstration.)
  String type = storedRequestType; 
  String mode = storedRequestName; 
  String value = responseStr;  // raw value received, e.g. "1"

  // Build the formatted response.
  String formattedResponse = type + ":" + mode + ":{" + value + "}\n";

  if (formattedResponse.length() > 0) {
    // Write the response to the characteristic.
    parameterResponseCharacteristic.write((uint8_t*)formattedResponse.c_str(), formattedResponse.length());
    // Notify connected devices.
    bool notifySuccess = replyConnection != BLE_CONN_HANDLE_INVALID &&
        parameterResponseCharacteristic.notifyEnabled(replyConnection) &&
        parameterResponseCharacteristic.notify(replyConnection, (uint8_t*)formattedResponse.c_str(), formattedResponse.length());
    if (notifySuccess) {
      Serial.print("Responded with: ");
      Serial.println(formattedResponse);
    } else {
      Serial.println("Notification failed!");
    }
  } else {
    Serial.println("Could not respond as length is 0!");
  }
}

// Read the currently selected mode's scalar parameter without repeated parsing code.
static int currentSetting(const char* key, int fallback) {
  for (int i=0; i<numModes; ++i) if (ledModes[i].name == currentModeName)
    for (int j=0; j<ledModes[i].numParams; ++j) if (ledModes[i].paramNames[j] == key)
      return ledModes[i].paramValuesOther[j].toInt();
  return fallback;
}

// V8.5: independent nonblocking renderers. No dynamic allocations per frame.
static uint8_t weatherLife[LEDCOUNT] = {};
// One-byte star ages: 0 is idle, 1..48 fades in and back out over ~4 s.
// This is intentionally independent of rain/snow drop lifetime.
static uint8_t weatherStarAge[LEDCOUNT] = {};

static uint16_t meteorWall = 0;
static uint16_t meteorTravel = 0;
static uint8_t meteorHue = 0;

static uint32_t scaledColor(uint32_t raw, uint8_t amount) {
  uint8_t r = (raw >> 16) & 255, g = (raw >> 8) & 255, b = raw & 255;
  const uint16_t scale = ((uint32_t)stripBright * amount) / 255;
  return strip.Color((uint16_t)r * scale / 255,
                     (uint16_t)g * scale / 255,
                     (uint16_t)b * scale / 255);
}
static uint32_t fadeColor(uint32_t raw, uint8_t amount) {
  return strip.Color(((raw >> 16) & 255) * amount / 255,
                     ((raw >> 8) & 255) * amount / 255,
                     (raw & 255) * amount / 255);
}
static uint8_t physicalWallCount() { return savedRoomCornerCount >= 4 ? savedRoomCornerCount : 4; }
static uint16_t physicalWallStart(uint8_t i) {
  return savedRoomCornerCount >= 4 ? savedRoomCorners[i].led : ((uint32_t)i * activeLedCount) / 4;
}
static uint16_t physicalWallLength(uint8_t i) {
  if (savedRoomCornerCount >= 4)
    return clockwiseDistance(savedRoomCorners[i].led, savedRoomCorners[(i+1)%savedRoomCornerCount].led);
  return ((uint32_t)(i+1)*activeLedCount)/4 - ((uint32_t)i*activeLedCount)/4;
}
static uint8_t physicalWallHeading(uint8_t index) {
  if (savedRoomCornerCount < 4) return index % 4;
  uint8_t heading = 0;
  for (uint8_t j=0; j<index; ++j) {
    uint8_t next=(j+1)%savedRoomCornerCount;
    heading=(heading+(savedRoomCorners[next].inside ? 3 : 1))%4;
  }
  uint8_t northHeading=0;
  for (uint8_t j=0; j<northSegment%savedRoomCornerCount; ++j) {
    uint8_t next=(j+1)%savedRoomCornerCount;
    northHeading=(northHeading+(savedRoomCorners[next].inside ? 3 : 1))%4;
  }
  return (heading+4-northHeading)%4;
}
static bool gravityWallSelected(uint8_t i, uint8_t pattern) {
  if (pattern == 2) return true;
  const uint8_t heading = physicalWallHeading(i);
  return heading == 1 || heading == 3; // East and West relative to selected north
}
static bool gravityReverse(uint8_t i, uint8_t pattern, uint8_t direction) {
  // Both E and W begin at the same geographic end. Reverse toggles the drop;
  // square mode can alternate orientation when Direction is Both.
  bool reverse = pattern == 1;
  if (pattern != 2 && physicalWallHeading(i)==3) reverse = !reverse;
  if (pattern == 2) reverse = direction==1 || (direction==2 && (i%2)!=0);
  return reverse;
}
static void renderGravity(bool wipe, int pattern, int direction, int speed, int bounce,
                          uint32_t solidColor, int palette, int fade) {
  if (!ledState) return;
  const uint32_t frameMs = (uint32_t)map(constrain(speed,1,100),1,100,180,42);
  if (millis()-lastEffectFrameMs < frameMs) return;
  lastEffectFrameMs=millis();
  if (!gravityInit) {
    memset(gravityFilled,0,sizeof(gravityFilled));
    memset(gravityTravel,0,sizeof(gravityTravel));
    strip.clear(); gravityInit=true;
  }
  if (wipe) {
    // Fade=0: only the moving head; Fade>0: adjustable trail duration.
    const uint8_t fadeScale = fade<=0 ? 0 : (uint8_t)map(constrain(fade,1,100),1,100,50,239);
    for (uint16_t n=0;n<activeLedCount;n++)
      strip.setPixelColor(n,fadeColor(strip.getPixelColor(n),fadeScale));
    const uint8_t n=physicalWallCount();
    bool anyLive=false;
    for(uint8_t i=0;i<n;i++) if(gravityWallSelected(i,pattern)) {
      uint16_t len=physicalWallLength(i);
      if(len==0 || gravityTravel[i]>=len) continue;
      anyLive=true;
      bool reverse=gravityReverse(i,pattern,direction);
      uint16_t px=(physicalWallStart(i)+(reverse?len-1-gravityTravel[i]:gravityTravel[i]))%activeLedCount;
      const uint32_t c=palette==0?solidColor:Wheel(gravityHue+i*23);
      strip.setPixelColor(px,scaledColor(c,255));
      gravityTravel[i]+=(uint16_t)map(constrain(speed,1,100),1,100,1,7);
    }
    if(!anyLive) {
      memset(gravityTravel,0,sizeof(gravityTravel));
      gravityHue+=47;
    }
    calibratedShow();return;
  }
  strip.clear();
  const uint8_t nWalls=physicalWallCount();
  bool allFull=true;
  for (uint8_t i=0;i<nWalls;i++) {
    if (!gravityWallSelected(i,pattern)) continue;
    uint16_t length=physicalWallLength(i);
    if (length==0) continue;
    const uint16_t start=physicalWallStart(i);
    const bool reverse=gravityReverse(i,pattern,direction);
    const uint16_t filled=min(length,gravityFilled[i]);
    // A bouncing 'new drop' runs towards the growing stack.
    const uint16_t landing=length-filled-1;
    const uint16_t t=min(gravityTravel[i],landing);
    if (!wipe) {
      const uint32_t stackColor=scaledColor(Wheel(gravityHue+i*19),225);
      for (uint16_t j=0;j<filled;j++) {
        const uint16_t index=(start+(reverse?j:length-1-j))%activeLedCount;
        strip.setPixelColor(index,stackColor);
      }
    }
    if (filled<length) {
      allFull=false;
      // Travel advances one logical pixel per effect frame, with a controlled
      // bounce flash at the impact point and no array overflow.
      uint16_t offset=reverse ? length-1-t : t;
      const uint16_t pixel=(start+offset)%activeLedCount;
      const uint32_t dot=(wipe && palette==0) ? solidColor : Wheel(gravityHue+i*23);
      strip.setPixelColor(pixel,scaledColor(dot,255));
      if (gravityTravel[i]>=landing) {
        if (bounce && !wipe && landing>0) {
          uint16_t neighbor=(start+(reverse?length-landing:length-2-landing))%activeLedCount;
          strip.setPixelColor(neighbor,scaledColor(dot,90));
        }
        gravityFilled[i]++;
        gravityTravel[i]=0;
      } else gravityTravel[i]+=max((uint16_t)1,(uint16_t)(length/6));
    }
  }
  if (allFull || (wipe && ++gravityHue==0)) {
    memset(gravityFilled,0,sizeof(gravityFilled));
    memset(gravityTravel,0,sizeof(gravityTravel));
    gravityHue+=29;
  }
  calibratedShow();
}
static void renderMeteor(int speed) {
  if (!ledState) return;
  const uint32_t frameMs=(uint32_t)map(constrain(speed,1,100),1,100,130,43);
  if (millis()-lastEffectFrameMs < frameMs) return;
  lastEffectFrameMs=millis();
  for (uint16_t i=0;i<activeLedCount;i++)
    strip.setPixelColor(i,fadeColor(strip.getPixelColor(i),175));
  if (!meteorActive && meteorExplosion==0) {
    meteorWall=random(physicalWallCount());meteorTravel=0;meteorHue=random(256);meteorActive=true;
  }
  const uint16_t length=physicalWallLength(meteorWall);
  const uint16_t start=physicalWallStart(meteorWall);
  if (meteorActive && length>0) {
    const uint32_t head=Wheel(meteorHue);
    for (uint8_t j=0;j<7;j++) if (meteorTravel>=j && meteorTravel-j<length) {
      uint16_t pos=(start+meteorTravel-j)%activeLedCount;
      strip.setPixelColor(pos,scaledColor(head,255-j*30));
    }
    meteorTravel+=(uint16_t)map(constrain(speed,1,100),1,100,1,4);
    if (meteorTravel>=length) {meteorActive=false;meteorExplosion=11;}
  }
  if (meteorExplosion>0) {
    const uint16_t corner=(start+length)%activeLedCount;
    uint8_t radius=12-meteorExplosion;
    for (int d=-radius*3;d<=radius*3;d++) {
      const uint16_t pos=(corner+activeLedCount+d)%activeLedCount;
      const uint8_t glow=(uint8_t)(255UL*(meteorExplosion)/12/(1+abs(d)));
      strip.setPixelColor(pos,scaledColor(Wheel(meteorHue+50),glow));
    }
    meteorExplosion--;
  }
  calibratedShow();
}
static void renderWeather() {
  if (!ledState) return;
  const uint32_t now = millis();
  if (now - lastEffectFrameMs < 90) return;
  lastEffectFrameMs = now;
  if (!weatherCodeReceived) {
    // No forecast yet: show a neutral dim standby, not fake clear weather.
    strip.fill(scaledColor(strip.Color(2, 3, 8), 255), 0, activeLedCount);
    calibratedShow();
    return;
  }
  const bool day = weatherDayReceived ? tabletWeatherDay :
      (rtc.now().hour() >= 6 && rtc.now().hour() < 19);
  const uint8_t code = tabletWeatherCode;
  const bool snow = (code >= 71 && code <= 77) || (code >= 85 && code <= 86);
  const bool rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82);
  const bool storm = code >= 95;
  const bool windy = tabletWindKmh > 45 && !snow && !rain && !storm;
  const bool clouds = (code >= 2 && code <= 3) || code == 45 || code == 48;
  const bool clearNight = !day && code <= 1 && !windy;
  // Clear-day dawn. The tablet sends 0..100 through the scheduled sunrise
  // window; 255 means disabled. Stale packets cannot force a fake sunrise.
  const bool sunriseActive = code <= 1 && sunriseLevel <= 100 &&
    (uint32_t)(millis() - sunrisePacketMs) < 120000UL;
  const uint32_t blueNight = strip.Color(2, 8, 40);
  const uint32_t baseSky = day ? strip.Color(95, 119, 147) : blueNight;

  for (uint16_t i = 0; i < activeLedCount; ++i) {
    uint32_t pixel = baseSky;
    if (clearNight) {
      // Stars are subtle, randomly located and eased in/out rather than flashing.
      const uint8_t age = weatherStarAge[i];
      if (age > 0) {
        const uint8_t glow = age <= 24 ? age : (uint8_t)(48 - age);
        pixel = strip.Color(2 + glow, 8 + glow * 2, 40 + glow);
        weatherStarAge[i] = age >= 48 ? 0 : age + 1;
      }
    } else if (clouds || windy) {
      // Gray-white cloud banks drift over the blue night sky with soft edges.
      // Avoid floating-point sin() across 1,165 LEDs each frame.
      const uint16_t span = windy ? 120 : 230;
      const uint16_t phase = (i + now / (windy ? 65 : 250)) % span;
      const uint16_t width = windy ? 55 : 105;
      const uint8_t triangle = phase < width
          ? (uint8_t)(phase < width / 2 ? phase : width - phase) : 0;
      const uint8_t fog = (uint16_t)triangle * (windy ? 17 : 15) / (width / 2);
      pixel = day ? strip.Color(90 + fog, 103 + fog, 123 + fog)
                  : strip.Color(2 + fog, 8 + fog, 40 + fog);
    } else if (rain || snow || storm) {
      if (weatherLife[i] > 0) --weatherLife[i];
      const uint8_t life = weatherLife[i];
      if (life > 0) {
        const uint32_t dot = snow ? strip.Color(210, 224, 245) : strip.Color(90, 167, 255);
        pixel = fadeColor(dot, (uint8_t)min(255, (int)life * 24));
      } else {
        pixel = day ? strip.Color(38, 58, 75) : strip.Color(2, 3, 18);
      }
    } else if (day && code <= 1) {
      pixel = strip.Color(190, 119, 17);
    }
    if (sunriseActive) {
      // A gentle dawn that follows the actual local sunrise supplied by Open-Meteo.
      // Across the strip, a warm horizon rises toward pastel daylight. No blocking delays.
      const uint8_t height = (uint32_t)i * 100U / max((uint16_t)1, activeLedCount);
      const int16_t warmth = (int16_t)sunriseLevel + 20 - height;
      const uint8_t mix = (uint8_t)constrain(warmth * 3, 0, 100);
      uint8_t red = (uint32_t)(2 * (100-mix) + 220 * mix) / 100;
      uint8_t green = (uint32_t)(8 * (100-mix) + 112 * mix) / 100;
      uint8_t blue = (uint32_t)(40 * (100-mix) + 96 * mix) / 100;
      pixel = strip.Color(red, green, blue);
    }
    strip.setPixelColor(i, scaledColor(pixel, 255));
  }
  if (clearNight) {
    // Seed a few new stars per frame; old ones continue their slow fades.
    for (uint8_t n = 0; n < 3; ++n) {
      if (random(4) == 0) {
        const uint16_t pos = random(activeLedCount);
        if (weatherStarAge[pos] == 0) weatherStarAge[pos] = 1;
      }
    }
  }
  if (rain || snow || storm) {
    for (uint16_t j = 0; j < max(1, (int)activeLedCount / (snow ? 170 : 95)); ++j)
      weatherLife[random(activeLedCount)] = snow ? 11 : 7;
    if (storm && random(32) == 0)
      strip.fill(scaledColor(strip.Color(145, 155, 209), 160), 0, activeLedCount);
  }
  calibratedShow();
}
// Nonblocking renderers. Each mode sends at most one WS2815 frame per tick.
static uint8_t glintAge[LEDCOUNT] = {};
static String glintMode;

static uint32_t lastGlintMs = 0;
static void renderStars(uint32_t base, int spawn, int decay, bool glitter) {
  if (!ledState) return;
  const uint32_t now = millis();
  if ((uint32_t)(now-lastGlintMs) < 50UL) return;
  lastGlintMs=now;
  if (effectResetPending || glintMode != currentModeName) {
    effectResetPending = false;
    memset(glintAge, 0, sizeof(glintAge));
    glintMode=currentModeName;
  }
  const int span=map(constrain(decay,1,100),1,100,9,96); // full in/out lifespan in frames
  // Glitter stays half-bright. Use a denser set of shimmer points than Twinkle
  // so the increase to full brightness is obvious, even on long LED strips.
  const uint32_t basePixel=glitter ? scaledColor(base,128) : 0;
  const uint8_t spawnCount=glitter
      ? (uint8_t)constrain((int)(activeLedCount/160),1,12)
      : (uint8_t)constrain((int)(activeLedCount/400),1,4);
  for (uint8_t k=0;k<spawnCount;k++) {
    if (random(1000)<constrain(spawn,0,100)*5) {
      uint16_t at=random(activeLedCount);
      if (!glintAge[at]) glintAge[at]=1;
    }
  }
  const uint32_t fullPixel=scaledColor(base,255);
  const uint8_t br=(basePixel>>16)&255, bg=(basePixel>>8)&255, bb=basePixel&255;
  const uint8_t fr=(fullPixel>>16)&255, fg=(fullPixel>>8)&255, fb=fullPixel&255;
  for (uint16_t i=0;i<activeLedCount;i++) {
    uint8_t age=glintAge[i];
    uint8_t glow=0;
    if (age) {
      int peak=max(1,span/2);
      glow=(uint8_t)(255UL*min((int)age,span-(int)age)/peak);
      glintAge[i]=(age>=span)?0:(uint8_t)(age+1);
    }
    if (glitter) {
      // 50% background, with individually animated full-color glitter glints.
      strip.setPixelColor(i,strip.Color(br+(fr-br)*glow/255,
                                       bg+(fg-bg)*glow/255,
                                       bb+(fb-bb)*glow/255));
    } else strip.setPixelColor(i,scaledColor(base,glow));
  }
  calibratedShow();
}

struct SoapBubble { int16_t center; uint8_t age; uint8_t duration; uint8_t radius; };
static SoapBubble bubbles[10] = {};
static uint32_t bubbleFrameMs=0;
static void renderPop(uint32_t color,int spawn,int speed,int size) {
  if (!ledState) return;
  uint32_t now=millis();
  if (effectResetPending) { memset(bubbles,0,sizeof(bubbles)); effectResetPending=false; bubbleFrameMs=0; }
  if ((uint32_t)(now-bubbleFrameMs)<50UL) return;
  bubbleFrameMs=now;
  const int duration=map(constrain(speed,1,100),1,100,80,12);
  if (random(1000)<constrain(spawn,0,100)*3) {
    for (auto &b:bubbles) if (!b.age) {
      b.center=random(activeLedCount); b.age=1;
      b.duration=(uint8_t)duration;
      b.radius=(uint8_t)map(constrain(size,1,100),1,100,1,12);
      break;
    }
  }
  strip.clear();
  for (auto &b:bubbles) {
    if (!b.age) continue;
    const bool popped=b.age>=b.duration;
    const int radius=popped ? b.radius : max(1,(int)b.radius*b.age/b.duration);
    const uint8_t glow=popped ? (uint8_t)max(0,255-((int)b.age-b.duration)*90) :
      (uint8_t)(60+((int)b.age*140)/b.duration);
    for (int delta=-radius;delta<=radius;delta++) {
      int ix=b.center+delta;
      if (ix<0 || ix>=activeLedCount) continue;
      // Bright ring right before the pop; decay in two frames thereafter.
      uint8_t strength=(uint8_t)(glow*(radius+1-abs(delta))/(radius+1));
      strip.setPixelColor(ix,scaledColor(color,strength));
    }
    if (++b.age>b.duration+2) b.age=0;
  }
  calibratedShow();
}

// In a closed room, physical LED 0 follows the final LED. Bars can enter from
// either direction at a corner and are rendered in the physical wire order.
// PhaserBar is defined in LEDWall_ConfigTypes.h before Arduino-generated prototypes.
static PhaserBar phaserBars[6] = {};
static String phaserMode;
static uint32_t lastPhaserMs=0, phaserSpawnMs=0;
static uint32_t phaserFlashUntil=0;
static uint16_t phaserFlashPos=0;
static uint8_t previousPhaserCorner=255;
static bool alternatePhaserDirection=false;

static int32_t loopLed(int32_t index) {
  if (activeLedCount == 0) return 0;
  int32_t result=index % activeLedCount;
  return result<0 ? result+activeLedCount : result;
}
static uint8_t phaserCornerCount() {
  return savedRoomCornerCount >= 4 ? savedRoomCornerCount : 4;
}
static uint16_t phaserCornerLed(uint8_t corner) {
  const uint8_t count=phaserCornerCount();
  return savedRoomCornerCount >= 4
      ? savedRoomCorners[corner % count].led % activeLedCount
      : (uint32_t)(corner % count) * activeLedCount / count;
}
static uint16_t choosePhaserOrigin(bool randomized) {
  const uint8_t count=phaserCornerCount();
  uint8_t corner=(northSegment+1)%count;
  if (randomized) {
    // Choose among *all* mapped corners, never the same corner twice in a row.
    corner=(uint8_t)random(count);
    if (count>1 && corner==previousPhaserCorner)
      corner=(corner+1+(uint8_t)random(count-1))%count;
  }
  previousPhaserCorner=corner;
  return phaserCornerLed(corner);
}
static uint8_t variedPhaserPace(int speed) {
  // Variation is per bar, not every animation frame. A +/-15 slider-value
  // variation makes collisions occur at different physical LED positions.
  const int adjusted=constrain(speed+(int)random(-15,16),1,100);
  return (uint8_t)map(adjusted,1,100,1,32);
}
static void spawnBar(int32_t start,int8_t direction,int length,int pace) {
  for (auto &b:phaserBars) if (!b.active) {
    b.head=start; b.direction=direction; b.length=(uint8_t)length;
    b.pace=(uint8_t)pace; b.traveled=(uint16_t)length; b.active=true;
    return;
  }
}
static void resetPhasers() {
  memset(phaserBars,0,sizeof(phaserBars));
  phaserSpawnMs=0; phaserFlashUntil=0; phaserMode=currentModeName;
  previousPhaserCorner=255; alternatePhaserDirection=false;
}
static uint8_t visibleBarLength(const PhaserBar& b) {
  return (uint8_t)min((uint16_t)b.length,b.traveled);
}
static bool barsOverlap(const PhaserBar& a,const PhaserBar& b,uint16_t& led) {
  if (!a.active || !b.active || activeLedCount==0) return false;
  // <=65 pixels per bar; checking the swept motion in substeps below prevents
  // fast-moving heads from tunnelling through each other between BLE frames.
  const uint8_t na=visibleBarLength(a), nb=visibleBarLength(b);
  for (int ia=0;ia<na;ia++) {
    const uint16_t at=(uint16_t)loopLed(a.head-a.direction*ia);
    // Distance along B's trailing direction: O(length), not O(length^2).
    const int32_t fromB=b.direction>0 ? loopLed(b.head-at) : loopLed(at-b.head);
    if (fromB<nb) {led=at;return true;}
  }
  return false;
}
static void renderPhaserFrame(uint32_t first,uint32_t second) {
  strip.clear();
  for (uint8_t k=0;k<6;k++) {
    const PhaserBar& bar=phaserBars[k];
    if (!bar.active) continue;
    const uint8_t shown=visibleBarLength(bar);
    for (int d=0;d<shown;d++) {
      int32_t led=bar.head-bar.direction*d;
      if (phaserMode=="Alternating Phaser") led=loopLed(led);
      if (led<0 || led>=activeLedCount) continue;
      const uint8_t intensity=(uint8_t)max(45,255-(int)d*180/max(1,(int)bar.length));
      strip.setPixelColor((uint16_t)led,scaledColor((k%2==0)?first:second,intensity));
    }
  }
  if ((int32_t)(phaserFlashUntil-millis())>0) {
    // White collision flash fades down, rather than holding its original color.
    const uint8_t life=(uint8_t)constrain((int)((phaserFlashUntil-millis())*255UL/260UL),0,255);
    for (int d=-6;d<=6;d++) {
      uint16_t led=(uint16_t)loopLed((int32_t)phaserFlashPos+d);
      strip.setPixelColor(led,scaledColor(strip.Color(255,255,255),
          (uint8_t)((uint16_t)life*max(0,255-abs(d)*35)/255)));
    }
  }
  calibratedShow();
}
static void renderPhaser(uint32_t color,int speed,int length,int pattern) {
  if (!ledState || activeLedCount==0) return;
  const uint32_t now=millis();
  if ((uint32_t)(now-lastPhaserMs)<50UL) return;
  lastPhaserMs=now;
  if (effectResetPending || phaserMode!=currentModeName) {
    resetPhasers(); effectResetPending=false;
  }
  const int pace=map(constrain(speed,1,100),1,100,1,38);
  const int len=map(constrain(length,1,100),1,100,2,70);
  bool active=false;
  for (auto &b:phaserBars) if (b.active) active=true;
  if (pattern==0) {
    if (!active && (uint32_t)(now-phaserSpawnMs)>380UL) {
      spawnBar(-len,1,len,pace); phaserSpawnMs=now;
    }
  } else if ((uint32_t)(now-phaserSpawnMs)>(uint32_t)random(180,1600)) {
    const bool fromLeft=random(2)!=0;
    spawnBar(fromLeft?-len:activeLedCount+len,fromLeft?1:-1,
       max(2,min(70,len+(int)random(-len/2,len/2+1))),
       max(1,pace+(int)random(-pace/3,pace/3+1)));
    phaserSpawnMs=now;
  }
  for (auto &b:phaserBars) if (b.active) {
    b.head+=(int)b.direction*b.pace;
    if ((b.direction>0 && b.head-b.length>=activeLedCount) ||
        (b.direction<0 && b.head+b.length<0)) b.active=false;
  }
  renderPhaserFrame(color,color);
}
static void renderAlternatingPhaser(uint32_t colorA,uint32_t colorB,int speed,int length,
                                   int spawnStyle,int collision) {
  if (!ledState || activeLedCount==0) return;
  const uint32_t now=millis();
  if ((uint32_t)(now-lastPhaserMs)<50UL) return;
  lastPhaserMs=now;
  if (effectResetPending || phaserMode!=currentModeName) {
    resetPhasers(); effectResetPending=false;
  }
  const int len=map(constrain(length,1,100),1,100,2,65);
  const bool hasPair=phaserBars[0].active || phaserBars[1].active;
  const bool flashing=(int32_t)(phaserFlashUntil-now)>0;
  if (!hasPair && !flashing && (uint32_t)(now-phaserSpawnMs) >= 600UL) {
    const uint16_t corner=choosePhaserOrigin(spawnStyle==2);
    const uint8_t cw=variedPhaserPace(speed),ccw=variedPhaserPace(speed);
    // Both bars originate at the *same* corner. Opposite directions ensure
    // their paths converge on the far side rather than following each other.
    // Growing the visible length from zero prevents a false collision at spawn.
    if (spawnStyle==0) {
      const uint8_t team=alternatePhaserDirection ? 1 : 0;
      phaserBars[team]={corner,(int8_t)(team==0?1:-1),(uint8_t)len,
                        (uint8_t)(team==0?cw:ccw),0,true};
      alternatePhaserDirection=!alternatePhaserDirection;
    } else {
      phaserBars[0]={corner,1,(uint8_t)len,cw,0,true};
      phaserBars[1]={corner,-1,(uint8_t)len,ccw,0,true};
    }
    phaserSpawnMs=now;
  }
  // Substep in single LED increments so fast opposing bars cannot pass
  // through one another without triggering a collision.
  const int steps=max(phaserBars[0].active?(int)phaserBars[0].pace:0,
                      phaserBars[1].active?(int)phaserBars[1].pace:0);
  for (int step=0;step<steps;step++) {
    for (uint8_t i=0;i<2;i++) {
      PhaserBar& b=phaserBars[i];
      if (!b.active || step>=b.pace) continue;
      b.head=loopLed(b.head+b.direction);
      if (b.traveled<activeLedCount+65) b.traveled++;
    }
    uint16_t impact=0;
    if (collision && barsOverlap(phaserBars[0],phaserBars[1],impact)) {
      phaserFlashPos=impact; phaserFlashUntil=now+260UL;
      phaserBars[0].active=false; phaserBars[1].active=false;
      break;
    }
  }
  for (uint8_t i=0;i<2;i++)
    if (phaserBars[i].active && phaserBars[i].traveled>=activeLedCount+len)
      phaserBars[i].active=false;
  renderPhaserFrame(colorA,colorB);
}

static void renderCylon(uint32_t primary,uint32_t secondary,int speed,int requestedLength) {
  if (!ledState || activeLedCount==0) return;
  const uint32_t now=millis();
  const uint32_t frameMs=(uint32_t)map(constrain(speed,1,100),1,100,175,45);
  if ((uint32_t)(now-lastEffectFrameMs)<frameMs) return;
  lastEffectFrameMs=now;
  const uint16_t width=min((uint16_t)map(constrain(requestedLength,1,100),1,100,1,70),activeLedCount);
  const uint16_t lastLeft=activeLedCount-width;
  if (cylonHead>lastLeft) cylonHead=lastLeft; // e.g. after changing Length
  if (secondary==0) secondary=primary; // SColor not selected -> Color in both directions
  strip.clear();
  // cylonHead is the *left edge* of the entirely visible bar, not its tip.
  // Never let any part of it leave the strip at either end.
  for (uint16_t j=0;j<width;j++) {
    const uint16_t distanceBehind=cylonReturning ? j : (width-1-j);
    const uint8_t glow=(uint8_t)max(25,255-(int)distanceBehind*210/max(1,(int)width-1));
    strip.setPixelColor(cylonHead+j,scaledColor(cylonReturning?secondary:primary,glow));
  }
  calibratedShow();
  if (!cylonReturning) {
    if (cylonHead>=lastLeft) cylonReturning=true;
    else cylonHead++;
  } else {
    if (cylonHead==0) cylonReturning=false;
    else cylonHead--;
  }
}

// Ripple: bounded nonblocking wave events, with constructive and destructive
// interference in a circular LED room. Positive crests add; negative troughs
// cancel them. Each wave expands clockwise and counterclockwise.
struct RippleWave { uint16_t origin; uint16_t radius; uint16_t age; uint8_t amplitude; bool active; };
static RippleWave rippleWaves[12] = {};
static uint32_t lastRippleFrameMs=0,nextRippleSpawnMs=0;
static void renderRipple(uint32_t color,int frequency,int speed) {
  if (!ledState || activeLedCount==0) return;
  const uint32_t now=millis();
  if (effectResetPending) {
    memset(rippleWaves,0,sizeof(rippleWaves));
    lastRippleFrameMs=0; nextRippleSpawnMs=now; effectResetPending=false;
  }
  if ((uint32_t)(now-lastRippleFrameMs)<50UL) return;
  lastRippleFrameMs=now;
  const uint8_t movement=(uint8_t)map(constrain(speed,1,100),1,100,1,8);
  const uint32_t interval=(uint32_t)map(constrain(frequency,1,100),1,100,6500,260);
  if ((int32_t)(now-nextRippleSpawnMs)>=0) {
    for (auto &wave:rippleWaves) if (!wave.active) {
      wave={ (uint16_t)random(activeLedCount),0,0,(uint8_t)random(180,256),true };
      break;
    }
    nextRippleSpawnMs=now+max(150UL,interval*(uint32_t)random(75,126)/100UL);
  }
  const int band=7;
  strip.clear();
  for (uint16_t led=0;led<activeLedCount;led++) {
    int32_t signal=0;
    for (const auto &w:rippleWaves) {
      if (!w.active) continue;
      const int separation=abs((int)led-(int)w.origin);
      const int distance=min(separation,(int)activeLedCount-separation);
      const int offset=distance-(int)w.radius;
      const int maxLife=max(20,(int)activeLedCount/(2*(int)movement)+16);
      const int strength=(int)w.amplitude*max(0,maxLife-(int)w.age)/maxLife;
      if (abs(offset)<=band) {
        signal+=strength*(band-abs(offset))/band;
      } else if (offset< -band && offset>=-3*band) {
        // Dark trough behind the bright crest creates cancellation on overlap.
        const int trough=band-abs(offset+2*band);
        signal-=strength*max(0,trough)/(band*2);
      }
    }
    if (signal>0) strip.setPixelColor(led,scaledColor(color,(uint8_t)min(255,signal)));
  }
  for (auto &wave:rippleWaves) if (wave.active) {
    wave.radius+=movement;
    wave.age++;
    if (wave.radius>(activeLedCount/2+3*band) || wave.age>300) wave.active=false;
  }
  calibratedShow();
}

void executeCurrentMode() {
  if (!ledState) return;
  for (int i = 0; i < numModes; i++) {
    if (ledModes[i].name == currentModeName) {
      unsigned int r = 0, g = 0, b = 0;
      unsigned int sr = 0, sg = 0, sb = 0;
      unsigned long speedParam = 0;
      unsigned long frequencyParam = 0;
      unsigned long divisionParam = 0;

      for (int j = 0; j < ledModes[i].numParams; j++) {
        if (ledModes[i].paramNames[j] == "Color") {
          r = ledModes[i].paramValuesR[j];  // Use the stored r value
          g = ledModes[i].paramValuesG[j];  // Use the stored g value
          b = ledModes[i].paramValuesB[j];  // Use the stored b value
        } else if (ledModes[i].paramNames[j] == "SColor") {
          sr = ledModes[i].paramValuesR[j];
          sg = ledModes[i].paramValuesG[j];
          sb = ledModes[i].paramValuesB[j];
        } else if (ledModes[i].paramNames[j] == "Speed") {
          speedParam = ledModes[i].paramValuesOther[j].toInt();  // Convert to integer
        } else if (ledModes[i].paramNames[j] == "Frequency") {
          frequencyParam = ledModes[i].paramValuesOther[j].toInt();
        } else if (ledModes[i].paramNames[j] == "Division") {
          divisionParam = ledModes[i].paramValuesOther[j].toInt();
        }
      }

      // Call the corresponding function
      if (currentModeName == "Audio reactive") {
        // 1,165 WS2815 pixels take ~35ms to transmit. 45ms is a practical upper
        // frame rate without saturating BLE and blocking other controller tasks.
        if (cMillis - lastAudioFrameMs >= 45) {
          lastAudioFrameMs = cMillis;
          if (cMillis - lastAudioPacketMs > 1200UL) tabletAudioLevel = 0;
          const int sensitivity = constrain(ledModes[i].paramValuesOther[1].toInt(), 1, 100);
          const int reaction = constrain(ledModes[i].paramValuesOther[2].toInt(), 0, 2);
          uint8_t level = constrain((uint16_t)tabletAudioLevel * sensitivity / 50, 0, 100);
          static uint8_t envelope = 0;
          static uint8_t oldLevel = 0;
          static uint8_t pulseHue = 0;
          if (level > envelope) envelope = level;
          else envelope = envelope > 5 ? envelope - 5 : 0;
          if (reaction == 2 && level > oldLevel + 12 && level > 20) pulseHue += 35;
          oldLevel = level;
          uint8_t br = ledState ? envelope : 0;
          uint8_t red = ((uint32_t)r * stripBright * br) / (255UL * 100UL);
          uint8_t green = ((uint32_t)g * stripBright * br) / (255UL * 100UL);
          uint8_t blue = ((uint32_t)b * stripBright * br) / (255UL * 100UL);
          if (reaction == 2) {
            uint32_t hue = Wheel(pulseHue);
            red = (((hue >> 16) & 255) * stripBright * br) / (255UL * 100UL);
            green = (((hue >> 8) & 255) * stripBright * br) / (255UL * 100UL);
            blue = ((hue & 255) * stripBright * br) / (255UL * 100UL);
          }
          strip.clear();
          if (reaction == 0) {
            uint16_t active = ((uint32_t)activeLedCount * br) / 100;
            strip.fill(strip.Color(red, green, blue), 0, active);
          } else strip.fill(strip.Color(red, green, blue), 0, activeLedCount);
          calibratedShow();
        }
      } else if (currentModeName == "Color" && previousModeName != currentModeName) {
        Serial.print("Primary Color RGB: ");
        Serial.print("Red: ");
        Serial.print(r);
        Serial.print(" Green: ");
        Serial.print(g);
        Serial.print(" Blue: ");
        Serial.println(b);
        colorMode(r, g, b);
        aOn = true;

        return;
      } else if (currentModeName == "Rainbow") {
        if (aOn == false) {
          pMillis = -1000;
          aOn = true;
        }
        rainbowCycle(20);
      } else if (currentModeName == "Alternating colors") {
        if (aOn == false) {
          aOn = true;
          altState = false;
          color = false;
          strip.fill(strip.Color(0, 0, 0), 0, activeLedCount);
          pMillis = -1000;
        }
        alternatingColors(r, g, b, sr, sg, sb, speedParam);
      } else if (currentModeName == "Fade") {
        if (aOn == false) {
          aOn = true;
          pMillis = -1000;
        }
        fade(speedParam);
      } else if (currentModeName == "Pulse") {
        if (aOn == false) {
          aOn = true;
          pMillis = -1000;
          pixChosen = 0;
          for (int i = 0; i < activeLedCount; i++) {
            setLedFlag(i, 0);
          }
        }
        pulse(r, g, b, sr, sg, sb, speedParam);
      } else if (currentModeName == "Breathe") {
        if (aOn == false) {
          aOn = true;
          brightness = stripBright;
          pMillis = -1000;
        }
        breathe(r, g, b, speedParam);
      } else if (currentModeName == "Paint") {
        if (aOn == false) {
          aOn = true;
          pMillis = -1000;
          for (uint16_t i = 0; i < activeLedCount; i++) {
            rStates[i] = 0;
            gStates[i] = 0;
            bStates[i] = 0;
          }
          strip.fill(strip.Color(0, 0, 0), 0, activeLedCount);
          calibratedShow();
        }
        paint(speedParam);
      } else if (currentModeName == "Strobe") {
        if (aOn == false) {
          aOn = true;
          pMillis = -1000;
        }
        strobe(r, g, b, speedParam);
      } else if (currentModeName == "Time") {
        if (aOn == false) {
          aOn = true;
          pMillis = -1000;
        }
        tClock(true);
      } else if (currentModeName == "Cylon") {
        if (!aOn) { aOn = true; cylonHead=0; cylonReturning=false; lastEffectFrameMs=0; }
        renderCylon(strip.Color(r,g,b),strip.Color(sr,sg,sb),speedParam,currentSetting("Length",20));
      } else if (currentModeName == "Phaser") {
        renderPhaser(strip.Color(r,g,b), speedParam, currentSetting("Length",22),
                     currentSetting("Pattern",0));
      } else if (currentModeName == "Alternating Phaser") {
        renderAlternatingPhaser(strip.Color(r,g,b), (sr||sg||sb) ? strip.Color(sr,sg,sb) : strip.Color(r,g,b),
            currentSetting("Speed",70), currentSetting("Length",20),
            currentSetting("Spawn",1), currentSetting("Collision",1));
      } else if (currentModeName == "Weather") {
        renderWeather();
      } else if (currentModeName == "Police Lights") {
        if (aOn == false) {
          aOn = true;
          pMillis = -1000;
          strip.fill(strip.Color(0, 0, 0), 0, activeLedCount);
          calibratedShow();
          aStep = 0;
          altState = false;
        }
        pLights(speedParam);
      } else if (currentModeName == "Fire") {
        if (aOn == false) {
          aOn = true;
          pMillis = -1000;
          strip.fill(strip.Color(0, 0, 0), 0, activeLedCount);
          calibratedShow();
          aStep = 0;
        }
        memset(ledStatus, 0, sizeof(ledStatus));
        barDirection = false;
        setBarSize = 0;
        fire(speedParam);
      } else if (currentModeName == "Twinkle") {
        renderStars(strip.Color(r,g,b), currentSetting("Spawn",35), currentSetting("Decay",55), false);
      } else if (currentModeName == "Sparkle") {
        renderStars(strip.Color(r,g,b), currentSetting("Spawn",45), currentSetting("Decay",60), true);
      } else if (currentModeName == "Ripple") {
        renderRipple(strip.Color(r,g,b),currentSetting("Frequency",45),currentSetting("Speed",55));
      } else if (currentModeName == "Running Lights") {
        if (aOn == false) {
          aOn = true;
          pMillis = -1000;
          strip.fill(strip.Color(0, 0, 0), 0, activeLedCount);
          calibratedShow();
          aStep = 0;
        }
        memset(ledStatus, 0, sizeof(ledStatus));
        rLights(r, g, b, speedParam, divisionParam);
      } else if (currentModeName == "Theatre Chase") {
        if (aOn == false) {
          aOn = true;
          pMillis = -1000;
          strip.fill(strip.Color(0, 0, 0), 0, activeLedCount);
          calibratedShow();
          aStep = 1;
        }
        memset(ledStatus, 0, sizeof(ledStatus));
        barDirection = false;
        setBarSize = 0;
        tChase(r, g, b, speedParam);
      } else if (currentModeName == "Meteor") {
        renderMeteor(speedParam);
      } else if (currentModeName == "Gravity Fill" || currentModeName == "Gravity Wipe") {
        const bool wipe=currentModeName=="Gravity Wipe";
        auto numberAt=[&](const char* name,int defaultValue)->int {
          for (int j=0;j<ledModes[i].numParams;j++) if (ledModes[i].paramNames[j]==name)
            return ledModes[i].paramValuesOther[j].toInt();
          return defaultValue;
        };
        int pattern=constrain(numberAt("Pattern",0),0,2);
        int direction=constrain(numberAt("Direction",0),0,2);
        int speed=constrain(numberAt("Speed",55),1,100);
        int bounce=constrain(numberAt("Bounce",1),0,1);
        int palette=constrain(numberAt("Palette",1),0,1);
        int fade=constrain(numberAt("Fade",25),0,100);
        uint32_t solid=strip.Color(90,120,255);
        for(int j=0;j<ledModes[i].numParams;j++) if(ledModes[i].paramNames[j]=="Color")
          solid=strip.Color(ledModes[i].paramValuesR[j],ledModes[i].paramValuesG[j],ledModes[i].paramValuesB[j]);
        renderGravity(wipe,pattern,direction,speed,bounce,solid,palette,fade);
      } else if (currentModeName == "Pop") {
        renderPop(strip.Color(r,g,b),currentSetting("Spawn",40),
                  currentSetting("Speed",60),currentSetting("Size",35));
      } else {
      }
      return;  // Exit after matching the mode
    }
  }
}

void setBrightness(int brightness) {
  // Logic to set the brightness of the LED, e.g., using PWM
  buffStripBright = map(brightness, 0, 100, 0, 255);
  previousModeName = "";
}

void cccd_callback(uint16_t conn_handle, BLECharacteristic* chr, uint16_t cccd_value) {
  if (chr == &parameterResponseCharacteristic && (cccd_value & BLE_CCCD_NOTIFY_VALUE)) {
    const uint16_t old = replyConnection; replyConnection = conn_handle;
    sendStateRequest("Core");
    sendStateRequest("Params");
    replyConnection = old;
  }
  // Display the raw request packet
  Serial.print("CCCD Updated: ");
  Serial.println(cccd_value);
  if (chr == &ledModesCharacteristic && (cccd_value & BLE_CCCD_NOTIFY_VALUE)) {
    sendLEDModeList();
  }
}

// Function to parse the RGB values from a string in the format "r,g,b"
void parseRGB(const String& rgbString, unsigned int& r, unsigned int& g, unsigned int& b) {
  int firstComma = rgbString.indexOf(',');
  int secondComma = rgbString.indexOf(',', firstComma + 1);

  r = rgbString.substring(0, firstComma).toInt();                // Extract and convert to int
  g = rgbString.substring(firstComma + 1, secondComma).toInt();  // Extract and convert to int
  b = rgbString.substring(secondComma + 1).toInt();              // Extract and convert to int
}

void startAdv(void) {
  Bluefruit.Advertising.clearData();

  Bluefruit.Advertising.addFlags(BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE);
  Bluefruit.Advertising.addTxPower();

  // Add the custom service UUID to the advertisement
  Bluefruit.Advertising.addService(customService);

  // // Add UART service UUID if needed
  // Bluefruit.Advertising.addService(bleuart);

  // Add the device name to the scan response
  Bluefruit.ScanResponse.addName();

  // Start advertising
  Bluefruit.Advertising.restartOnDisconnect(true);
  Bluefruit.Advertising.setInterval(32, 244);  // Advertising interval range in ms
  Bluefruit.Advertising.setFastTimeout(30);    // Fast mode timeout in seconds
  Bluefruit.Advertising.start(0);              // 0 = Don't stop advertising after a set time
}

void connect_callback(uint16_t conn_handle) {
  (void)conn_handle;
  Serial.println("Connected-ish");
  BLEConnection* connection = Bluefruit.Connection(conn_handle);
  char central_name[32] = { 0 };
  if (!connection || !connection->connected()) {
    Serial.println("Invalid BLE connection callback handle");
    return;
  }
  if (connection_count < MAX_PRPH_CONNECTION) connection_count++;
  for (int i=0; i<MAX_PRPH_CONNECTION; ++i) if (sessionHandles[i] == BLE_CONN_HANDLE_INVALID) {
    sessionHandles[i] = conn_handle; sessionAuthorized[i] = false;
    badPinCount[i] = 0; pinLockoutUntil[i] = 0; break;
  }
  connection->getPeerName(central_name, sizeof(central_name));
  Serial.print("Connected to ");
  Serial.println(central_name);
  // The mode list is already readable; notify only after CCCD is enabled.

  // Check if the device is valid and the name is available
  if (connection && connection->connected()) {
    // Access device name safely
    // Provide arguments to getPeerName()
    connection->getPeerName(central_name, sizeof(central_name));
    const char* deviceName = central_name;
    Serial.print("Device name: ");
    Serial.println(deviceName);
    if (cConnected == false) {
      Serial.println("yesconnect");
      Serial.println('\n');
      inRamp = false;
      cConnected = true;
      // Reconnecting must not override the commanded On/Off state.
      if (timeoutlight == true) {
        timeoutlight = false;
        Serial.println("Timeout Light True");
        ledMode = 0;
        outputBlackoutPending = true;
      }
    }
  } else {
    Serial.println("Device information not available yet.");
  }
  if (connection_count < MAX_PRPH_CONNECTION) {
    Serial.println("Keep advertising");
    Bluefruit.Advertising.start(0);
  }
}

void disconnect_callback(uint16_t conn_handle, uint8_t reason) {
  (void)conn_handle;
  (void)reason;
  Serial.println();
  Serial.print("Disconnected, reason = 0x");
  Serial.println(reason, HEX);
  if (connection_count > 0) connection_count--;
  const int slot = authSlot(conn_handle);
  if (slot >= 0) {
    sessionHandles[slot] = BLE_CONN_HANDLE_INVALID; sessionAuthorized[slot] = false;
    badPinCount[slot] = 0; pinLockoutUntil[slot] = 0;
  }
  cConnected = connection_count > 0;
  if (mapPreviewActive && mapHeldWall >= 0 && mapHoldOwner == conn_handle) {
    endRoomPreview(); // The pressed tablet disappeared before ACTION_UP.
  }
  if (!cConnected && mapPreviewActive) {
    endRoomPreview();
    roomDraftInProgress = false;
  }
  if (connection_count < MAX_PRPH_CONNECTION) Bluefruit.Advertising.start(0);  // More clients allowed
}

void RTCMillis() {
  count++;
  if (count >= 113) {
    count = 0;
    sBarPos++;
  }
}

void cResync() {
  static uint32_t lastClockReadMs = 0;
  static bool initialClockRead = true;
  if (!initialClockRead && (uint32_t)(millis() - lastClockReadMs) < 200UL) return;
  initialClockRead = false;
  lastClockReadMs = millis();
  DateTime now = rtc.now();
  minute = now.minute();
  if (minute != pMinute) {
    pMinute = minute;
    sBarPos = hourMap[0];
  }
  hour = (now.hour() + DST) % 24;
  second = now.second();
}

void timeout() {
  if (cConnected == false && timeoutlight == false) {
    Serial.println("Timeout Triggered");
    ledMode = 11;
    color1[0] = 255;
    color1[1] = 0;
    color1[2] = 0;
    for (uint16_t i = 0; i < activeLedCount; i++) {
      if (ledNum < beamSize) {
        if (ledON == false) {
          beamPos[i] = 0;
        } else {
          beamPos[i] = 1;
        }
        ledNum++;
      } else if (ledNum >= beamSize) {
        ledON = !ledON;
        ledNum = 0;
      }
    }
    ledState = true;
    aOn = true;
    timeoutlight = true;
    Serial.println("Timeout");
    Serial.println('\n');
  }
  if (cConnected == false && timeoutlight == true) {
    Serial.println("Timeout Triggered Again");
    timeoutMode(255, 0, 0, 5);
  }
}

void rampBright() {
  if (inRamp == true && rampStep < aMBright) {
    if ((cMillis - rMillis) >= 100) {
      stripBright = rampStep;
      rampStep++;
      rMillis = cMillis;
    }
  }
}

void colorMode(unsigned int r, unsigned int g, unsigned int b) {
  if (currentModeName != previousModeName) {
    // Scale each color by the brightness factor and ensure they stay within 0-255
    unsigned int br = constrain((r * stripBright) / 255, 0, 255);
    unsigned int bg = constrain((g * stripBright) / 255, 0, 255);
    unsigned int bb = constrain((b * stripBright) / 255, 0, 255);

    // Update LED strip color
    strip.fill(strip.Color(br, bg, bb), 0, activeLedCount);
    Serial.print("Brightness Red Val: ");
    Serial.print(br);
    Serial.print(" Brightness Green Val: ");
    Serial.print(bg);
    Serial.print(" Brightness Blue Val: ");
    Serial.println(bb);

    calibratedShow();
    previousModeName = currentModeName;
  }
}

// Fill the dots one after the other with a color
void colorWipe(uint32_t c, uint8_t freq) {
  uint16_t wait;
  wait = (1000UL / max(1UL, (unsigned long)freq)) / 2;
  for (uint16_t i = 0; i < strip.numPixels(); i++) {
    strip.setPixelColor(i, c);
    calibratedShow();
    delay(wait);
  }
}

// Slightly different, this makes the rainbow equally distributed throughout
void rainbowCycle(unsigned long freq) {
  uint16_t wait;
  wait = (1000UL / max(1UL, (unsigned long)freq)) / 2;
  uint16_t i;
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    pMillis = cMillis;
    if (aStep < 256) {
      for (i = 0; i < strip.numPixels(); i++) {
        strip.setPixelColor(i, Wheel(((i * 256 / strip.numPixels()) + aStep) & 255));
      }
      calibratedShow();
      aStep++;
    }
  }
  if (aStep >= 256) {
    aStep = 0;
  }
}

// Input a value 0 to 255 to get a color value.
// The colours are a transition r - g - b - back to r.
uint32_t Wheel(byte WheelPos) {
  WheelPos = 255 - WheelPos;
  if (WheelPos < 85) {
    return strip.Color(stripBright * (255 - WheelPos * 3) / 255, 0, stripBright * (WheelPos * 3) / 255);
  }
  if (WheelPos < 170) {
    WheelPos -= 85;
    return strip.Color(0, stripBright * (WheelPos * 3) / 255, stripBright * (255 - WheelPos * 3) / 255);
  }
  WheelPos -= 170;
  return strip.Color(stripBright * (WheelPos * 3) / 255, stripBright * (255 - WheelPos * 3) / 255, 0);
}

// Smooth continuous RGB color-wheel fade; no integer RGB truncation.
void fade(unsigned long speed) {
  if (!ledState) return;
  static uint8_t hue = 0;
  if (effectResetPending) { hue=0; effectResetPending=false; lastEffectFrameMs=0; }
  const uint32_t interval = (uint32_t)map(constrain((int)speed,1,100),1,100,150,38);
  if ((uint32_t)(cMillis-lastEffectFrameMs) < interval) return;
  lastEffectFrameMs = cMillis;
  hue += (uint8_t)map(constrain((int)speed,1,100),1,100,1,6);
  strip.fill(Wheel(hue),0,activeLedCount);
  calibratedShow();
}

void breathe(unsigned int r, unsigned int g, unsigned int b, unsigned long freq) {
  long cwait;
  cwait = max(1UL, ((1000UL / max(1UL, freq)) / 2UL) *
                 (255UL / max(1UL, (unsigned long)stripBright)));
  if (brightness < stripBright && prevBrightness != brightness && (cMillis - pMillis >= cwait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    prevBrightness = brightness;
    strip.fill(strip.Color(constrain((brightness * r) / 255, 0, 255),
                           constrain((brightness * g) / 255, 0, 255),
                           constrain((brightness * b) / 255, 0, 255)),
               0, activeLedCount);

    calibratedShow();
    if (goingUp == true) {
      brightness++;
    } else if (goingUp == false) {
      brightness--;
    }
    if (brightness >= stripBright) {
      goingUp = false;
    }
    if (brightness <= 0) {
      goingUp = true;
    }
    pMillis = cMillis;
  }
  if (brightness >= stripBright && (cMillis - pMillis >= (1000UL / max(1UL, 2UL * (unsigned long)(brightness - stripBright))) && (aOn == true) && (ledState == true)) && (freq > 0)) {
    strip.fill(strip.Color(constrain((brightness * r) / 255, 0, 255),
                           constrain((brightness * g) / 255, 0, 255),
                           constrain((brightness * b) / 255, 0, 255)),
               0, activeLedCount);
    calibratedShow();
    if (brightness == stripBright) {
      prevBrightness = brightness;
    }
    goingUp = false;
    if (goingUp == false) {
      brightness--;
    }
    pMillis = cMillis;
  }
}

void strobe(unsigned int r, unsigned int g, unsigned int b, unsigned long freq) {
  uint16_t wait;
  wait = (1000UL / max(1UL, (unsigned long)freq)) / 2;
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    if (strobeOn == false) {
      strip.fill(strip.Color(constrain((stripBright * r) / 255, 0, 255),
                             constrain((stripBright * g) / 255, 0, 255),
                             constrain((stripBright * b) / 255, 0, 255)),
                 0, activeLedCount);
      strobeOn = true;
    } else {
      strip.fill(strip.Color(0, 0, 0), 0, activeLedCount);
      strobeOn = false;
    }
    calibratedShow();
    pMillis = cMillis;
  }
}

void alternatingColors(unsigned int r, unsigned int g, unsigned int b, unsigned int sr, unsigned int sg, unsigned int sb, unsigned long freq) {
  uint16_t scaledFreq;
  scaledFreq = map(freq, 0, 100, 0, 60);
  uint16_t wait;
  wait = (1000UL / max(1UL, (unsigned long)scaledFreq)) / 2;
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    if ((ledDiv % 2) == 0) {
      if (altState == true) {
        for (int i = 0; i <= (ledDiv - 1); i++) {
          if (color == false) {
            strip.fill(strip.Color(constrain((stripBright * r) / 255, 0, 255),
                                   constrain((stripBright * g) / 255, 0, 255),
                                   constrain((stripBright * b) / 255, 0, 255)),
                       (((activeLedCount / ledDiv) + 1) * i), (activeLedCount / ledDiv) * (i + 1));
            color = true;
          } else {
            strip.fill(strip.Color(constrain((stripBright * sr) / 255, 0, 255),
                                   constrain((stripBright * sg) / 255, 0, 255),
                                   constrain((stripBright * sb) / 255, 0, 255)),
                       (((activeLedCount / ledDiv) + 1) * i), (activeLedCount / ledDiv) * (i + 1));
            color = false;
          }
        }
        calibratedShow();
        altState = false;
      } else {
        for (int j = 0; j <= (ledDiv - 1); j++) {
          if (color == false) {
            strip.fill(strip.Color(constrain((stripBright * sr) / 255, 0, 255),
                                   constrain((stripBright * sg) / 255, 0, 255),
                                   constrain((stripBright * sb) / 255, 0, 255)),
                       (((activeLedCount / ledDiv) + 1) * j), (activeLedCount / ledDiv) * (j + 1));
            color = true;
          } else {
            strip.fill(strip.Color(constrain((stripBright * r) / 255, 0, 255),
                                   constrain((stripBright * g) / 255, 0, 255),
                                   constrain((stripBright * b) / 255, 0, 255)),
                       (((activeLedCount / ledDiv) + 1) * j), (activeLedCount / ledDiv) * (j + 1));
            color = false;
          }
        }
        calibratedShow();
        altState = true;
      }
    } else if ((ledDiv % 2)) {
      if (altState == true) {
        for (int i = 0; i <= (ledDiv - 1); i++) {
          if (color == false) {
            strip.fill(strip.Color(constrain((stripBright * r) / 255, 0, 255),
                                   constrain((stripBright * g) / 255, 0, 255),
                                   constrain((stripBright * b) / 255, 0, 255)),
                       (((activeLedCount / ledDiv) + 1) * i), (activeLedCount / ledDiv) * (i + 1));
            color = true;
          } else {
            strip.fill(strip.Color(constrain((stripBright * sr) / 255, 0, 255),
                                   constrain((stripBright * sg) / 255, 0, 255),
                                   constrain((stripBright * sb) / 255, 0, 255)),
                       (((activeLedCount / ledDiv) + 1) * i), (activeLedCount / ledDiv) * (i + 1));

            color = false;
          }
        }
        calibratedShow();
        altState = true;
      } else {
        for (int j = 0; j <= (ledDiv - 1); j++) {
          if (color == false) {
            strip.fill(strip.Color(constrain((stripBright * sr) / 255, 0, 255),
                                   constrain((stripBright * sg) / 255, 0, 255),
                                   constrain((stripBright * sb) / 255, 0, 255)),
                       (((activeLedCount / ledDiv) + 1) * j), (activeLedCount / ledDiv) * (j + 1));
            color = true;
          } else {
            strip.fill(strip.Color(constrain((stripBright * r) / 255, 0, 255),
                                   constrain((stripBright * g) / 255, 0, 255),
                                   constrain((stripBright * b) / 255, 0, 255)),
                       (((activeLedCount / ledDiv) + 1) * j), (activeLedCount / ledDiv) * (j + 1));
            color = false;
          }
        }
        calibratedShow();
        altState = false;
      }
    }

    pMillis = cMillis;
  }
}

void pulse(unsigned int r, unsigned int g, unsigned int b, unsigned int sr, unsigned int sg, unsigned int sb, unsigned long freq) {
  uint16_t wait;
  wait = (1000UL / max(1UL, (unsigned long)freq));
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    while (pixChosen < 5) {
      if (pixChosen == 1) {

        int dir = (random(0, 1000) / 2);
        if ((dir % 2) == 0) {
          pulseBar1[0] = 0;
        } else {
          pulseBar1[0] = 1;
        }
        pulseBar1[1] = random(2, 10);
        pulseBar1[2] = (stripBright * (r / 255));
        pulseBar1[3] = (stripBright * (g / 255));
        pulseBar1[4] = (stripBright * (b / 255));
        pulseBar1[5] = 72;
        pulseBar1[6] = random(0, 8);
        pulseBar1[7] = 0;
      }
      if (pixChosen == 2) {
        pulseBar2[0] = random(0, 1);
        pulseBar2[1] = random(1, 6);
        pulseBar2[2] = (stripBright * (r / 255));
        pulseBar2[3] = (stripBright * (g / 255));
        pulseBar2[4] = (stripBright * (b / 255));
        pulseBar2[5] = 72;
        pulseBar2[6] = random(0, 8);
        pulseBar2[7] = 0;
      }
      if (pixChosen == 3) {
        pulseBar3[0] = random(0, 1);
        pulseBar3[1] = random(1, 6);
        pulseBar3[2] = (stripBright * (r / 255));
        pulseBar3[3] = (stripBright * (g / 255));
        pulseBar3[4] = (stripBright * (b / 255));
        pulseBar3[5] = 72;
        pulseBar3[6] = random(0, 8);
        pulseBar3[7] = 0;
      }
      if (pixChosen == 4) {
        pulseBar4[0] = random(0, 1);
        pulseBar4[1] = random(1, 6);
        pulseBar4[2] = (stripBright * (r / 255));
        pulseBar4[3] = (stripBright * (g / 255));
        pulseBar4[4] = (stripBright * (b / 255));
        pulseBar4[5] = 72;
        pulseBar4[6] = random(0, 8);
        pulseBar4[7] = 0;
      }
      if (pixChosen == 5) {
        pulseBar5[0] = random(0, 1);
        pulseBar5[1] = random(1, 6);
        pulseBar5[2] = (stripBright * (r / 255));
        pulseBar5[3] = (stripBright * (g / 255));
        pulseBar5[4] = (stripBright * (b / 255));
        pulseBar5[5] = 72;
        pulseBar5[6] = random(0, 8);
        pulseBar5[7] = 0;
      } else {
      }
      pixChosen++;
    }
    if (pixChosen >= 5) {
      if (pulseBar1[7] == pulseBar1[6]) {
        if (pulseBar1[5] == 0 || pulseBar1[5] == activeLedCount) {
          if (pulseBar1[0] == 0) {
            pulseBar1[5] = pulseBar1[5] + pulseBar1[1] + 1;
            pulseBar1[0] = 1;
          } else {
            pulseBar1[5] = pulseBar1[5] - pulseBar1[1] - 1;
            pulseBar1[0] = 0;
          }
        }

        setLedFlag(int(pulseBar1[5]), 1);
        if (pulseBar1[0] == 1) {
          setLedFlag(int(pulseBar1[5]) - int(pulseBar1[1]), 0);
          pulseBar1[5]++;
        } else {
          setLedFlag(int(pulseBar1[5]) + int(pulseBar1[1]), 0);
          pulseBar1[5]--;
        }
        pulseBar1[7] = 0;
      } else {
        pulseBar1[7]++;
      }
      if (pulseBar2[7] == pulseBar2[6]) {
        if (pulseBar2[5] == 0 || pulseBar2[5] == activeLedCount) {
          if (pulseBar2[0] == 0) {
            pulseBar2[5] = pulseBar2[5] + pulseBar2[1] + 1;
            pulseBar2[0] = 1;
          } else {
            pulseBar2[5] = pulseBar2[5] - pulseBar2[1] - 1;
            pulseBar2[0] = 0;
          }
        }

        setLedFlag(int(pulseBar2[5]), 1);
        if (pulseBar2[0] == 1) {
          setLedFlag(int(pulseBar2[5]) - int(pulseBar2[1]), 0);
          pulseBar2[5]++;
        } else {
          setLedFlag(int(pulseBar2[5]) + int(pulseBar2[1]), 0);
          pulseBar2[5]--;
        }
        pulseBar2[7] = 0;
      } else {
        pulseBar2[7]++;
      }
      if (pulseBar3[7] == pulseBar3[6]) {
        if (pulseBar3[5] == 0 || pulseBar3[5] == activeLedCount) {
          if (pulseBar3[0] == 0) {
            pulseBar3[5] = pulseBar3[5] + pulseBar3[1] + 1;
            pulseBar3[0] = 1;
          } else {
            pulseBar3[5] = pulseBar3[5] - pulseBar3[1] - 1;
            pulseBar3[0] = 0;
          }
        }

        setLedFlag(int(pulseBar3[5]), 1);
        if (pulseBar3[0] == 1) {
          setLedFlag(int(pulseBar3[5]) - int(pulseBar3[1]), 0);
          pulseBar3[5]++;
        } else {
          setLedFlag(int(pulseBar3[5]) + int(pulseBar3[1]), 0);
          pulseBar3[5]--;
        }
        pulseBar3[7] = 0;
      } else {
        pulseBar3[7]++;
      }
      if (pulseBar4[7] == pulseBar4[6]) {
        if (pulseBar4[5] == 0 || pulseBar4[5] == activeLedCount) {
          if (pulseBar4[0] == 0) {
            pulseBar4[5] = pulseBar4[5] + pulseBar4[1] + 1;
            pulseBar4[0] = 1;
          } else {
            pulseBar4[5] = pulseBar4[5] - pulseBar4[1] - 1;
            pulseBar4[0] = 0;
          }
        }

        setLedFlag(int(pulseBar4[5]), 1);
        if (pulseBar4[0] == 1) {
          setLedFlag(int(pulseBar4[5]) - int(pulseBar4[1]), 0);
          pulseBar4[5]++;
        } else {
          setLedFlag(int(pulseBar4[5]) + int(pulseBar4[1]), 0);
          pulseBar4[5]--;
        }
        pulseBar4[7] = 0;
      } else {
        pulseBar4[7]++;
      }
      if (pulseBar5[7] == pulseBar5[6]) {
        if (pulseBar5[5] == 0 || pulseBar5[5] == activeLedCount) {
          if (pulseBar5[0] == 0) {
            pulseBar5[5] = pulseBar5[5] + pulseBar5[1] + 1;
            pulseBar5[0] = 1;
          } else {
            pulseBar5[5] = pulseBar5[5] - pulseBar5[1] - 1;
            pulseBar5[0] = 0;
          }
        }

        setLedFlag(int(pulseBar5[5]), 1);
        if (pulseBar5[0] == 1) {
          setLedFlag(int(pulseBar5[5]) - int(pulseBar5[1]), 0);
          pulseBar5[5]++;
        } else {
          setLedFlag(int(pulseBar5[5]) + int(pulseBar5[1]), 0);
          pulseBar5[5]--;
        }
        pulseBar5[7] = 0;
      } else {
        pulseBar5[7]++;
      }
    }
    for (uint16_t i = 0; i < activeLedCount; i++) {
      if (ledFlag(i) == 1) {
        strip.setPixelColor(i, (stripBright * (r / 255)), (stripBright * (g / 255)), (stripBright * (b / 255)) / 10);
      } else {
        strip.setPixelColor(i, ((stripBright * (sr / 255)) / 10), ((stripBright * (sg / 255)) / 10), ((stripBright * (sb / 255)) / 10));
      }
    }
    calibratedShow();
    pMillis = cMillis;
  }
}

void pop(unsigned int r, unsigned int g, unsigned int b, unsigned long speed) {
  unsigned long freq = map(speed, 1, 100, 300, 1);
  if ((cMillis - pMillis) >= 10 && (aOn == true) && (ledState == true)) {
    if (random(freq) == 1) {
      uint16_t pix = random(activeLedCount);
      if (rStates[pix] < 1 && gStates[pix] < 1 && bStates[pix] < 1 && (speed > 0)) {
        rStates[pix] = (constrain((stripBright * r) / 255, 0, 255));
        gStates[pix] = (constrain((stripBright * g) / 255, 0, 255));
        bStates[pix] = (constrain((stripBright * b) / 255, 0, 255));
      }
    }
    for (uint16_t i = 0; i < activeLedCount; i++) {
      if (rStates[i] > 1 || gStates[i] > 1 || bStates[i] > 1) {
        strip.setPixelColor(i, rStates[i], gStates[i], bStates[i]);

        if (popHang[i] >= 200) {
          if (rStates[i] > 1) {
            rStates[i] = rStates[i] * 0.99;
          } else {
            rStates[i] = 0;
          }

          if (gStates[i] > 1) {
            gStates[i] = gStates[i] * 0.99;
          } else {
            gStates[i] = 0;
          }

          if (bStates[i] > 1) {
            bStates[i] = bStates[i] * 0.99;
          } else {
            bStates[i] = 0;
          }
        } else if (popHang[i] < 200) {
          popHang[i]++;
        }
      } else {
        strip.setPixelColor(i, ((stripBright * (r / 255)) / 10), ((stripBright * (g / 255)) / 10), ((stripBright * (b / 255)) / 10));
      }
    }
    calibratedShow();
    pMillis = cMillis;
  }
}

void paint(unsigned long freq) {
  uint16_t wait = (1000UL / max(1UL, (unsigned long)freq)) / 2;
  uint16_t pix;
  if (((cMillis - pMillis) >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    if (random(75) == 1) {
      pix = random(activeLedCount);
      if ((rStates[pix] != nextrgb[0]) || (gStates[pix] != nextrgb[1]) || (bStates[pix] != nextrgb[2])) {
        rStates[pix] = nextrgb[0];
        gStates[pix] = nextrgb[1];
        bStates[pix] = nextrgb[2];
        strip.setPixelColor(pix, rStates[pix], gStates[pix], bStates[pix]);
        calibratedShow();
        Serial.println("Chosen");
        pixChosen++;
        Serial.print("Pixels Left: ");
        Serial.println(activeLedCount - pixChosen);
      }
    }
    if (pixChosen >= (activeLedCount - 50)) {
      Serial.println("Already Set");

      uint16_t colorOption = random(7);
      while (colorOption == pColorOption) {
        colorOption = random(7);
      }
      pColorOption = colorOption;
      for (uint16_t i = 0; i < activeLedCount; i++) {
        rStates[i] = 0;
        gStates[i] = 0;
        bStates[i] = 0;
      }
      Serial.print("Chosen Option: ");
      Serial.println(colorOption);
      pixChosen = 0;
      strip.fill(strip.Color(nextrgb[0], nextrgb[1], nextrgb[2]), 0, activeLedCount);
      calibratedShow();

      if (colorOption == 0) {
        nextrgb[0] = 255;
        nextrgb[1] = 0;
        nextrgb[2] = 0;
      }
      if (colorOption == 1) {
        nextrgb[0] = 255;
        nextrgb[1] = 165;
        nextrgb[2] = 0;
      }
      if (colorOption == 2) {
        nextrgb[0] = 255;
        nextrgb[1] = 255;
        nextrgb[2] = 0;
      }
      if (colorOption == 3) {
        nextrgb[0] = 0;
        nextrgb[1] = 255;
        nextrgb[2] = 0;
      }
      if (colorOption == 4) {
        nextrgb[0] = 0;
        nextrgb[1] = 0;
        nextrgb[2] = 255;
      }
      if (colorOption == 5) {
        nextrgb[0] = 255;
        nextrgb[1] = 0;
        nextrgb[2] = 255;
      }
      if (colorOption == 6) {
        nextrgb[0] = 255;
        nextrgb[1] = 102;
        nextrgb[2] = 178;
      }
      if (colorOption == 7) {
        nextrgb[0] = 102;
        nextrgb[1] = 255;
        nextrgb[2] = 255;
      } else {
      }
    }
    pMillis = cMillis;
  }
}
void cylon(unsigned int r, unsigned int g, unsigned int b, unsigned int sr, unsigned int sg, unsigned int sb, unsigned long freq) {
  uint16_t mappedFreq = map(freq, 0, 100, 0, 1000);
  uint16_t wait = (1000 / max(1, (int)mappedFreq));
  if ((barDirection == false) && (ledFlag(aStep) == 0) && (setBarSize <= barSize) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(constrain((stripBright * r) / 255, 0, 255), constrain((stripBright * g) / 255, 0, 255), constrain((stripBright * b) / 255, 0, 255)));
    calibratedShow();
    setLedFlag(aStep, 1);
    setBarSize++;
    aStep++;
    pMillis = cMillis;
  }
  if ((barDirection == false) && (aStep < activeLedCount && ledFlag(aStep) == 0) && (setBarSize >= barSize) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(constrain((stripBright * r) / 255, 0, 255), constrain((stripBright * g) / 255, 0, 255), constrain((stripBright * b) / 255, 0, 255)));
    strip.setPixelColor((aStep - barSize - 1), strip.Color(0, 0, 0));
    setLedFlag(aStep - barSize - 1, 0);
    calibratedShow();
    setLedFlag(aStep, 1);
    if (aStep == activeLedCount) {
      barDirection = true;
      aStep = (aStep - barSize - 1);
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
  if ((barDirection == true) && (ledFlag(aStep) == 0) && (ledFlag(aStep + 1) == 1) && (setBarSize >= barSize) && (aStep >= 0) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(constrain((stripBright * sr) / 255, 0, 255), constrain((stripBright * sg) / 255, 0, 255), constrain((stripBright * sb) / 255, 0, 255)));
    strip.setPixelColor((aStep + barSize + 1), strip.Color(0, 0, 0));
    setLedFlag(aStep + barSize + 1, 0);
    calibratedShow();
    setLedFlag(aStep, 1);
    if (aStep == 0) {
      barDirection = false;
      aStep = (aStep + barSize + 1);
    } else {
      aStep--;
    }
    pMillis = cMillis;
  }
}

void phaser(unsigned int r, unsigned int g, unsigned int b, unsigned long freq) {
  uint16_t wait = (1000 / max(1UL, freq));
  if ((barDirection == false) && (ledFlag(aStep) == 0) && (setBarSize <= barSize) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(constrain((stripBright * r) / 255, 0, 255), constrain((stripBright * g) / 255, 0, 255), constrain((stripBright * b) / 255, 0, 255)));
    calibratedShow();
    setLedFlag(aStep, 1);
    setBarSize++;
    aStep++;
    pMillis = cMillis;
  }
  if ((barDirection == false) && (aStep < activeLedCount && ledFlag(aStep) == 0) && (setBarSize >= barSize) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(constrain((stripBright * r) / 255, 0, 255), constrain((stripBright * g) / 255, 0, 255), constrain((stripBright * b) / 255, 0, 255)));
    strip.setPixelColor((aStep - barSize - 1), strip.Color(0, 0, 0));
    setLedFlag(aStep - barSize - 1, 0);
    calibratedShow();
    setLedFlag(aStep, 1);
    if (aStep == activeLedCount) {
      barDirection = true;
      aStep = (aStep - barSize);
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
  if ((barDirection == true) && (aStep < activeLedCount && ledFlag(aStep) == 1) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (freq > 0)) {
    strip.setPixelColor(aStep, strip.Color(0, 0, 0));
    calibratedShow();
    setBarSize--;
    setLedFlag(aStep, 0);
    if (aStep == activeLedCount) {
      barDirection = false;
      aStep = 0;
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
}

void aPhaser(unsigned int r, unsigned int g, unsigned int b, unsigned int sr, unsigned int sg, unsigned int sb) {
  uint16_t wait = 1000;
  if ((barDirection == false) && (ledFlag(aStep) == 0) && (setBarSize <= barSize) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 0)) {
    strip.setPixelColor(aStep, strip.Color(constrain((stripBright * r) / 255, 0, 255), constrain((stripBright * g) / 255, 0, 255), constrain((stripBright * b) / 255, 0, 255)));
    calibratedShow();
    setLedFlag(aStep, 1);
    setBarSize++;
    aStep++;
    pMillis = cMillis;
  }
  if ((barDirection == false) && (aStep < activeLedCount && ledFlag(aStep) == 0) && (setBarSize >= barSize) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 0)) {
    strip.setPixelColor(aStep, strip.Color(constrain((stripBright * r) / 255, 0, 255), constrain((stripBright * g) / 255, 0, 255), constrain((stripBright * b) / 255, 0, 255)));
    strip.setPixelColor((aStep - barSize - 1), strip.Color(0, 0, 0));
    setLedFlag(aStep - barSize - 1, 0);
    calibratedShow();
    setLedFlag(aStep, 1);
    if (aStep == activeLedCount) {
      barDirection = true;
      aStep = (aStep - barSize);
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
  if ((barDirection == true) && (aStep < activeLedCount && ledFlag(aStep) == 1) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 0)) {
    strip.setPixelColor(aStep, strip.Color(0, 0, 0));
    calibratedShow();
    setBarSize--;
    setLedFlag(aStep, 0);
    if (aStep == activeLedCount) {
      phaserNum = 1;
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
  if ((barDirection == true) && (ledFlag(aStep) == 0) && (setBarSize <= barSize) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 1)) {
    strip.setPixelColor(aStep, strip.Color(constrain((stripBright * sr) / 255, 0, 255), constrain((stripBright * sg) / 255, 0, 255), constrain((stripBright * sb) / 255, 0, 255)));
    calibratedShow();
    setLedFlag(aStep, 1);
    setBarSize++;
    aStep--;
    pMillis = cMillis;
  }
  if ((barDirection == true) && (ledFlag(aStep) == 0) && (setBarSize >= barSize) && (aStep >= 0) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 1)) {
    strip.setPixelColor(aStep, strip.Color(constrain((stripBright * sr) / 255, 0, 255), constrain((stripBright * sg) / 255, 0, 255), constrain((stripBright * sb) / 255, 0, 255)));
    strip.setPixelColor((aStep + barSize + 1), strip.Color(0, 0, 0));
    setLedFlag(aStep + barSize + 1, 0);
    calibratedShow();
    setLedFlag(aStep, 1);
    if (aStep == 0) {
      barDirection = false;
      aStep = (aStep + barSize);
    } else {
      aStep--;
    }
    pMillis = cMillis;
  }
  if ((barDirection == false) && (ledFlag(aStep) == 1) && (aStep >= 0) && ((cMillis - pMillis) >= (wait)) && (aOn == true) && (ledState == true) && (phaserNum == 1)) {
    strip.setPixelColor(aStep, strip.Color(0, 0, 0));
    calibratedShow();
    setBarSize--;
    setLedFlag(aStep, 0);
    if (aStep == 0) {
      phaserNum = 0;
    } else {
      aStep--;
    }
    pMillis = cMillis;
  }
}

void pLights(unsigned long freq) {
  uint16_t wait;
  wait = (1000UL / max(1UL, (unsigned long)freq)) / 2;
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (altState == false) && (freq <= 10)) {
    strip.fill(strip.Color(255, 0, 0), (activeLedCount / 2), activeLedCount);
    strip.fill(strip.Color(0, 0, 0), 0, (activeLedCount / 2));
    calibratedShow();
    altState = true;
    pMillis = cMillis;
  }
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (altState == true) && (freq <= 10)) {
    strip.fill(strip.Color(0, 0, 255), 0, (activeLedCount / 2));
    strip.fill(strip.Color(0, 0, 0), (activeLedCount / 2), activeLedCount);
    calibratedShow();
    altState = false;
    pMillis = cMillis;
  }
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (altState == false) && (freq > 10)) {
    if ((aStep == 0) || (aStep == 2) || (aStep == 4) || (aStep == 6) || (aStep == 8)) {
      strip.fill(strip.Color(255, 0, 0), (activeLedCount / 2), activeLedCount);
      calibratedShow();
    }

    if ((aStep == 1) || (aStep == 3) || (aStep == 5) || (aStep == 7) || (aStep == 9)) {
      strip.fill(strip.Color(0, 0, 0), (activeLedCount / 2), activeLedCount);
      calibratedShow();
    }
    if (aStep >= 9) {
      altState = true;
    } else {
      aStep++;
    }
    pMillis = cMillis;
  }
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (altState == true) && (freq > 10)) {
    if ((aStep == 0) || (aStep == 2) || (aStep == 4) || (aStep == 6) || (aStep == 8)) {
      strip.fill(strip.Color(0, 0, 255), 0, (activeLedCount / 2));
      calibratedShow();
    }
    if ((aStep == 1) || (aStep == 3) || (aStep == 5) || (aStep == 7) || (aStep == 9)) {
      strip.fill(strip.Color(0, 0, 0), 0, (activeLedCount / 2));
      calibratedShow();
    }
    if (aStep <= 0) {
      altState = false;
    } else {
      aStep--;
    }
    pMillis = cMillis;
  }
}

void tChase(unsigned int r, unsigned int g, unsigned int b, unsigned long freq) {
  uint16_t wait;
  int dotSpacing = 12;
  wait = (1000UL / max(1UL, (unsigned long)freq));
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    if (aStep < dotSpacing) {
      aStep++;
    } else if (aStep >= dotSpacing) {
      aStep = 1;
    }
    for (int i = 0; i < activeLedCount; i++) {
      if ((i + aStep) % dotSpacing == 0) {
        strip.setPixelColor(i, strip.Color(constrain((stripBright * r) / 255, 0, 255), constrain((stripBright * g) / 255, 0, 255), constrain((stripBright * b) / 255, 0, 255)));
      } else {
        strip.setPixelColor(i, strip.Color(0, 0, 0));
      }
    }
    calibratedShow();
    pMillis = cMillis;
  }
}

void rLights(unsigned int r, unsigned int g, unsigned int b, unsigned long freq, unsigned long div) {
  uint16_t wait;
  int barSize = 3;
  int spacingSize = 12;
  int index = 0;
  wait = (1000UL / max(1UL, (unsigned long)freq));
  int offsetNum = 0;
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    if (aStep < spacingSize) {
      aStep++;
    } else if (aStep >= spacingSize) {
      aStep = 0;
    }
    index = 0;
    strip.fill(strip.Color(0, 0, 0), 0, activeLedCount);
    for (int i = 0; i < activeLedCount && (i + aStep) < activeLedCount; i++) {
      if ((index <= (barSize - 1)) && (index <= spacingSize)) {
        strip.setPixelColor(i + aStep, strip.Color(constrain((stripBright * r) / 255, 0, 255), constrain((stripBright * g) / 255, 0, 255), constrain((stripBright * b) / 255, 0, 255)));
        index++;
      } else if ((index >= barSize) && (index <= (spacingSize + 1))) {
        strip.setPixelColor(i + aStep, strip.Color(0, 0, 0));
        index++;
      }
      if ((index > barSize) && (index > spacingSize)) {
        index = 0;
      }
    }
    calibratedShow();
    pMillis = cMillis;
  }
}

void fire(unsigned long freq) {
  uint16_t wait;
  int barSize = 3;
  int spacingSize = 12;
  int index = 0;
  wait = (1000UL / max(1UL, (unsigned long)freq));
  int offsetNum = 0;
  if ((cMillis - pMillis >= random(150, 275)) && (aOn == true) && (ledState == true)) {
    for (int i = 0; i < activeLedCount; i++) {
      int flicker = random(0, 150);
      int r1 = 255 - flicker;
      int g1 = 150 - flicker;
      int b1 = 40 - flicker;
      if (g1 < 0) g1 = 0;
      if (r1 < 0) r1 = 0;
      if (b1 < 0) b1 = 0;
      strip.setPixelColor(i, r1, g1, b1);
    }
    calibratedShow();
    pMillis = cMillis;
  }
}

void tClock(bool tUpdate) {
  const int hBar = 20;
  const int mBar = 6;
  const int sBar = 12;
  const int sBarTrail = 3;


  if (!tUpdate || !aOn || !ledState) {
    return;
  }

  if (stripBright >= 30) {
    handBright = (255 / 255) * stripBright;
    mHandBright = (255 / 255) * stripBright / 4;
    backBright = (255 / 255) * stripBright / 4;
  } else {
    handBright = 60;
    mHandBright = 15;
    backBright = (255 / 255) * stripBright / 4;
  }

  if (clockPathSize > 0 && savedRoomCornerCount >= 4) {
    // Clock effects use ONLY non-flattened LEDs. Compressed jogs remain background.
    static int lastSecond = -1;
    static uint32_t secondBeganMs = 0;
    if (second != lastSecond) { lastSecond = second; secondBeganMs = cMillis; }
    const double fraction = min(0.999, (double)(cMillis - secondBeganMs) / 1000.0);
    const double smoothSecond = (double)second + fraction;
    const uint16_t secondIndex = clockPathIndex(smoothSecond);
    strip.fill(strip.Color(backBright, 0, backBright), 0, activeLedCount);
    const uint8_t hour12 = hour % 12;
    const uint16_t hourIndex = clockPathIndex(hour12 * 5.0);
    const uint16_t minuteIndex = clockPathIndex((double)minute);
    for (int j = -10; j < 10; ++j)
      strip.setPixelColor(clockPath[(hourIndex + clockPathSize + j) % clockPathSize], strip.Color(handBright, 0, 0));
    for (int j = -3; j < 3; ++j)
      strip.setPixelColor(clockPath[(minuteIndex + clockPathSize + j) % clockPathSize], strip.Color(handBright, handBright, 0));
    // 60 face dots. Hour quarters are brighter.
    for (int tick = 0; tick < 60; ++tick) {
      const uint16_t physical = minuteMap[tick];
      if (tick % 15 == 0) strip.setPixelColor(physical, strip.Color(handBright, handBright, handBright));
      else if (tick % 5 == 0) strip.setPixelColor(physical, strip.Color(0, handBright / 2, handBright / 2));
      else strip.setPixelColor(physical, strip.Color(0, 0, mHandBright));
    }
    for (int j = -6; j < 6; ++j) {
      const int pos = (secondIndex + clockPathSize + j) % clockPathSize;
      strip.setPixelColor(clockPath[pos], strip.Color(0, j < -3 ? handBright / 2 : handBright, 0));
    }
    calibratedShow();
    return;
  }
  int elapsedsec = (cMillis - tMillis) / 1000;
  int cHour;
  if (hour >= 12) {
    cHour = hour - 12;
  } else {
    cHour = hour;
  }
  if (sBarPos - sBar / 2 >= activeLedCount) {
    sBarPos = sBar / 2;
  }
  for (int i = 0; i < activeLedCount; i++) {
    if ((i <= hourMap[cHour] + (hBar / 2) && i >= hourMap[cHour] - (hBar / 2)) && (i > minuteMap[minute] + (mBar / 2) || i < minuteMap[minute] - (mBar / 2))) {
      strip.setPixelColor(i, strip.Color(handBright, 0, 0));
    } else if ((i > hourMap[cHour] + (hBar / 2) || i < hourMap[cHour] - (hBar / 2)) && (i <= minuteMap[minute] + (mBar / 2) && i >= minuteMap[minute] - (mBar / 2))) {
      strip.setPixelColor(i, strip.Color(handBright, handBright, 0));
    } else if ((i <= hourMap[cHour] + (hBar / 2) && i >= hourMap[cHour] - (hBar / 2)) && (i <= minuteMap[minute] + (mBar / 2) && i >= minuteMap[minute] - (mBar / 2))) {
      strip.setPixelColor(i, strip.Color(handBright, handBright, handBright));
    } else {
      strip.setPixelColor(i, strip.Color(backBright, 0, backBright));
    }
  }
  // Custom layouts use the actual wall tick order, including reversed walls.
  // The legacy mapping retains its original smooth seconds sweep.
  const int secondCenter = (customWallMapEnabled || savedRoomCornerCount >= 4) ? minuteMap[second % 60] : sBarPos;
  for (int j = -sBar / 2; j < sBar / 2; j++) {
    int pixelIndex = (secondCenter + j + activeLedCount) % activeLedCount;
    if (j < -sBar / 2 + sBarTrail) {
      strip.setPixelColor(pixelIndex, strip.Color(0, handBright / 2, 0));
    } else {
      strip.setPixelColor(pixelIndex, strip.Color(0, handBright, 0));
    }
  }
  for (int l = 0; l < sizeof(minuteMap) / sizeof(minuteMap[0]); l++) {
    int m = minuteMap[l];
    bool isInHourMap = false;
    for (int n = 0; n < sizeof(hourMap) / sizeof(hourMap[0]); n++) {
      int k = hourMap[n];
      if (m == k) {
        isInHourMap = true;
        break;
      } else if (n % 3 == 0) {
        strip.setPixelColor(k, strip.Color(handBright, handBright, handBright));
      }
    }
    if (isInHourMap && l != 0 && l != 15 && l != 30 && l != 45) {
      strip.setPixelColor(m, strip.Color(0, handBright / 2, handBright / 2));
    } else if (!isInHourMap) {
      strip.setPixelColor(m, strip.Color(0, 0, mHandBright));
    }
  }
  calibratedShow();
}
void twinkle(unsigned int r, unsigned int g, unsigned int b, unsigned long speed) {
  unsigned long freq = map(speed, 1, 100, 300, 1);
  if ((cMillis - pMillis) >= 20 && (aOn == true) && (ledState == true)) {
    if (random(freq) == 1) {
      uint16_t pix = random(activeLedCount);
      if ((ledFlag(pix) == 0) && (speed > 0)) {
        rStates[pix] = r;
        gStates[pix] = g;
        bStates[pix] = b;
        setLedFlag(pix, 1);
        setPopHang[pix] = random(0, 20);
      }
    }
    for (int i = 0; i < activeLedCount; i++) {
      if ((ledFlag(i) >= 100) && (popHang[i] <= setPopHang[i])) {
        popHang[i]++;
      }
      if ((ledFlag(i) > 0) && (ledFlag(i) <= 100)) {
        int correctedbrightness = map(ledFlag(i), 1, 100, 1, 255);
        strip.setPixelColor(i, stripBright * (((rStates[i] / 255) * correctedbrightness) / 255), stripBright * (((gStates[i] / 255) * correctedbrightness) / 255), stripBright * (((bStates[i] / 255) * correctedbrightness)) / 255);
        setLedFlag(i, ledFlag(i) + 1);
      }
      if ((ledFlag(i) > 100) && (ledFlag(i) < 200) && (popHang[i] >= setPopHang[i])) {
        int correctedbrightness = map(ledFlag(i), 101, 200, 255, 1);
        strip.setPixelColor(i, stripBright * (((rStates[i] / 255) * correctedbrightness) / 255), stripBright * (((gStates[i] / 255) * correctedbrightness) / 255), stripBright * (((bStates[i] / 255) * correctedbrightness)) / 255);
        setLedFlag(i, ledFlag(i) + 1);
      }
      if ((ledFlag(i) >= 200)) {
        strip.setPixelColor(i, 0, 0, 0);
        setLedFlag(i, 0);
        popHang[i] = 0;
        setPopHang[i] = 0;
        rStates[i] = 0;
        gStates[i] = 0;
        bStates[i] = 0;
      }
    }
    calibratedShow();
    pMillis = cMillis;
  }
}

void sparkle(unsigned int r, unsigned int g, unsigned int b, unsigned long freq) {
  uint16_t wait;
  int dotSpacing = 12;
  wait = (1000UL / max(1UL, (unsigned long)freq));
  if ((cMillis - pMillis >= wait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    for (int i = 0; i < activeLedCount; i++) {
      if (i % dotSpacing == 0) {
        if ((ledFlag(i) == setPopHang[i])) {
          popHang[i] = setPopHang[i];
          uint8_t attempts = 0;
          do {
            setPopHang[i] = random(0, 100);
          } while (++attempts < 12 &&
              (setPopHang[i] >= popHang[i] - 40) &&
              (setPopHang[i] <= popHang[i] + 40));
          if (setPopHang[i] >= popHang[i] - 40 && setPopHang[i] <= popHang[i] + 40)
            setPopHang[i] = popHang[i] < 50 ? 99 : 0;
        }

        if ((ledFlag(i) > setPopHang[i])) {
          setLedFlag(i, ledFlag(i) - 1);
          int correctedbrightness = map(ledFlag(i), 0, 100, 0, 255);
          strip.setPixelColor(i, stripBright * (((r / 255) * correctedbrightness) / 255), stripBright * (((g / 255) * correctedbrightness) / 255), stripBright * (((b / 255) * correctedbrightness)) / 255);
        }
        if ((ledFlag(i) < setPopHang[i])) {
          setLedFlag(i, ledFlag(i) + 1);
          int correctedbrightness = map(ledFlag(i), 0, 100, 0, 255);
          strip.setPixelColor(i, stripBright * (((r / 255) * correctedbrightness) / 255), stripBright * (((g / 255) * correctedbrightness) / 255), stripBright * (((b / 255) * correctedbrightness)) / 255);
        }
      }
    }
    calibratedShow(); // A single WS2815 transmission per frame.
    pMillis = cMillis;
  }
}

void timeoutMode(unsigned int r, unsigned int g, unsigned int b, unsigned long freq) {
  long cwait;
  cwait = ((1000UL / max(1UL, (unsigned long)freq)) / 2);
  if (prevBrightness != brightness && (cMillis - pMillis >= cwait) && (aOn == true) && (ledState == true) && (freq > 0)) {
    Serial.println("timeoutMode Triggered");
    prevBrightness = brightness;
    for (int i = 0; i < activeLedCount; i++) {
      if (beamPos[i] == 1) {
        strip.setPixelColor(i, brightness * (r / 255), brightness * (g / 255), brightness * (b / 255));
        //     strip.setPixelColor(i,255,0,0);
      }
      if (beamPos[i] == 0) {
        strip.setPixelColor(i, 0, 0, 0);
      }
    }
    calibratedShow();
    if (goingUp == true) {
      brightness++;
    } else if (goingUp == false) {
      brightness--;
    }
    if (brightness >= stripBright) {
      goingUp = false;
    }
    if (brightness <= 0) {
      goingUp = true;
    }
    if (aStep < beamSize) {
      for (int i = 1; i < activeLedCount - 1; i++) {
        if (beamPos[i] == 0 && beamPos[i + 1] == 1) {
          beamPos[i] = 1;
        }
        if (beamPos[i] == 1 && beamPos[i + 1] == 0) {
          beamPos[i] = 0;
        }
      }
      if (beamPos[beamSize] == 0 && beamPos[activeLedCount - beamSize] == 0) {
        beamPos[activeLedCount - 1] = 1;
      }
      if (beamPos[activeLedCount - beamSize] == 1) {
        beamPos[activeLedCount - 1] = 0;
      }

      aStep++;
      if (aStep >= beamSize) {
        aStep = 0;
      }
    }
    pMillis = cMillis;
  }
}